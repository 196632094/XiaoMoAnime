#!/bin/bash
set -e

# 打开详细日志
set -x

echo "=== ENTRYPOINT START ==="
echo "Current directory: $(pwd)"

# 设置 pip 镜像源 - 优先阿里云，失败再用清华
pip config set global.index-url https://mirrors.aliyun.com/pypi/simple || \
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple

# 1. 下载 ZIP
if [ ! -z "$ZIP_URL" ]; then
    echo "Found ZIP_URL: $ZIP_URL"
    echo "Downloading source code..."
    
    # 增加 -f 参数，如果 404/500 则失败
    curl -f -L -o source.zip "$ZIP_URL" || {
        echo "Error: Failed to download zip from $ZIP_URL"
        exit 1
    }
    
    echo "Extracting source code..."
    unzip -o source.zip
    rm source.zip
    
    # 检查是否解压出了嵌套文件夹
    if [ ! -f "app.py" ]; then
        echo "app.py not found in root, searching..."
        SUB_DIR=$(find . -maxdepth 2 -name "app.py" -exec dirname {} \;)
        if [ ! -z "$SUB_DIR" ] && [ "$SUB_DIR" != "." ]; then
            echo "Found app in $SUB_DIR, moving files..."
            cp -rf "$SUB_DIR"/* .
            rm -rf "$SUB_DIR"
        fi
    fi
fi

# 2. 安装依赖
echo "Installing requirements..."
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt
else
    echo "Warning: requirements.txt not found. Listing files:"
    ls -R
fi

# 3. 启动应用
echo "Starting application..."
mkdir -p logs

# 检查 Flask 应用入口
if [ -f "app.py" ]; then
    # 使用 python -u (unbuffered) 确保日志实时输出
    exec python -u app.py
else
    echo "Error: app.py still not found! Application cannot start."
    ls -la
    # 保持容器运行以便调试
    echo "Sleeping infinitely for debug..."
    sleep infinity
fi
