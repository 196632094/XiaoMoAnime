import requests
from bs4 import BeautifulSoup
import re
import json
import os
import time
import threading
from urllib.parse import urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import base64

class YhdmSource:
    def __init__(self, log_callback=None, progress_callback=None):
        self.base_url = "https://www.dmdan8.com"
        self.search_url = "https://www.dmdan8.com/search/-------------.html?wd={keyword}"
        
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
        self.log_callback = log_callback
        self.progress_callback = progress_callback
        
        self.download_folder = "downloads"
        self.log_folder = "logs"
        self.max_threads = 8 
        self.download_history_file = os.path.join(self.log_folder, "download_history.json")
        
        if not os.path.exists(self.download_folder):
            os.makedirs(self.download_folder)
        if not os.path.exists(self.log_folder):
            os.makedirs(self.log_folder)
            
        self.download_history = self.load_download_history()

    def log(self, message):
        print(message)
        if self.log_callback:
            self.log_callback(message)

    def load_download_history(self):
        if os.path.exists(self.download_history_file):
            try:
                with open(self.download_history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
        
    def save_download_history(self):
        with open(self.download_history_file, 'w', encoding='utf-8') as f:
            json.dump(self.download_history, f, ensure_ascii=False, indent=2)

    def is_downloaded(self, anime_name, episode_name):
        key = f"{anime_name}||{episode_name}"
        if key not in self.download_history:
            return False
            
        record = self.download_history[key]
        if 'path' in record and os.path.exists(record['path']):
            return True
            
        del self.download_history[key]
        self.save_download_history()
        return False

    def search_anime(self, keyword):
        self.log(f"正在搜索(YHDM): {keyword}")
        url = self.search_url.format(keyword=keyword)
        
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            results = []
            
            items = soup.select(".stui-pannel-box .stui-vodlist__media h3 a")
            
            if not items:
                items = soup.select(".search-box .thumb-menu > a")
            
            for item in items:
                title = item.get_text().strip()
                link = item.get('href')
                if not link.startswith('http'):
                    link = urljoin(self.base_url, link)
                
                cover = ""
                parent = item.find_parent("li")
                if parent:
                    img = parent.select_one("img")
                    if img: cover = img.get("data-original") or img.get("src")
                
                results.append({
                    "name": title,
                    "url": link,
                    "source": "yhdm",
                    "cover": cover
                })
            
            return results
        except Exception as e:
            self.log(f"搜索失败: {e}")
            return []

    def get_episodes(self, anime_url):
        try:
            self.log(f"获取剧集列表: {anime_url}")
            response = self.session.get(anime_url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            source_container = soup.select_one(".stui-pannel-box:has(h3.title:-soup-contains('播放地址'))")
            if not source_container:
                source_container = soup.select_one(".stui-pannel-box")
            
            if not source_container:
                return []
                
            channel_names = [a.get_text().strip() for a in source_container.select(".nav-tabs li a")]
            episode_container = source_container.select_one(".tab-content")
            
            if not episode_container:
                return []
                
            episode_lists = episode_container.select(".tab-pane")
            
            sources = []
            all_episodes = []
            
            for i, list_div in enumerate(episode_lists):
                if i >= len(channel_names): break
                
                name = channel_names[i]
                source_episodes = []
                
                for item in list_div.select("a"):
                    ep_name = item.get_text().strip()
                    ep_url = item.get('href')
                    
                    if ep_url:
                        if not ep_url.startswith('http'):
                            ep_url = urljoin(self.base_url, ep_url)
                            
                        match = re.search(r"第\s*(?P<ep>.+)\s*[话集]", ep_name)
                        ep_num = match.group("ep") if match else ep_name
                        
                        ep_data = {
                            'name': ep_name,
                            'original_name': ep_name,
                            'url': ep_url,
                            'episode': ep_num,
                            'source_name': name
                        }
                        source_episodes.append(ep_data)
                
                if source_episodes:
                    sources.append({
                        "name": name,
                        "episodes": source_episodes
                    })
                    if i == 0:
                        all_episodes = source_episodes
            
            return {
                'episodes': all_episodes,
                'sources': sources
            }
            
        except Exception as e:
            self.log(f"获取剧集失败: {e}")
            return []

    def decrypt_video_url(self, encrypted_str, bt_token):
        # Key found from reversing play.js (constant for now)
        key_string = "57A891D97E332A9D"
        key = key_string.encode('utf-8')
        iv = bt_token.encode('utf-8')
        
        try:
            cipher = AES.new(key, AES.MODE_CBC, iv)
            # encrypted_str is Base64 encoded
            encrypted_bytes = base64.b64decode(encrypted_str)
            decrypted_bytes = unpad(cipher.decrypt(encrypted_bytes), AES.block_size)
            return decrypted_bytes.decode('utf-8')
        except Exception as e:
            self.log(f"解密失败: {e}")
            return None

    def get_video_url(self, episode_url):
        try:
            self.log(f"正在解析(Requests): {episode_url}")
            resp = self.session.get(episode_url, timeout=10)
            resp.raise_for_status()
            
            # Extract player_aaaa
            match = re.search(r'player_aaaa={.*?}', resp.text)
            if match:
                try:
                    json_str = match.group(0).replace('player_aaaa=', '')
                    player_data = json.loads(json_str)
                    url_encoded = player_data.get('url')
                    
                    if url_encoded:
                        # Construct iframe URL
                        iframe_url = f"https://danmu.yhdmjx.com/m3u8.php?url={url_encoded}"
                        self.log(f"Fetching iframe: {iframe_url}")
                        
                        # Fetch iframe with Referer
                        iframe_resp = self.session.get(iframe_url, headers={"Referer": episode_url}, timeout=10)
                        if iframe_resp.status_code == 200:
                            # Extract bt_token
                            bt_token_match = re.search(r'var bt_token = "(.*?)";', iframe_resp.text)
                            # Extract encrypted info
                            video_info_match = re.search(r'getVideoInfo\("(.*?)"\)', iframe_resp.text)
                            
                            if bt_token_match and video_info_match:
                                bt_token = bt_token_match.group(1)
                                encrypted_info = video_info_match.group(1)
                                
                                decrypted_url = self.decrypt_video_url(encrypted_info, bt_token)
                                if decrypted_url:
                                    self.log(f"解析成功: {decrypted_url}")
                                    return decrypted_url
                except Exception as e:
                    self.log(f"Requests解析出错: {e}")
            
            self.log("Requests解析失败，尝试Selenium fallback...")
            
            chrome_options = Options()
            chrome_options.add_argument("--headless")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--ignore-certificate-errors")
            chrome_options.add_argument("--log-level=3")
            chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
            
            driver = webdriver.Chrome(options=chrome_options)
            try:
                driver.get(episode_url)
                
                try:
                    playleft_iframe = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.XPATH, '//*[@id="playleft"]/iframe'))
                    )
                    driver.switch_to.frame(playleft_iframe)
                    video_element = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.TAG_NAME, 'video'))
                    )
                    video_url = video_element.get_attribute('src')
                    if video_url: return video_url.strip()
                except:
                    pass
                
                try:
                    driver.switch_to.default_content()
                    video_element = driver.find_element(By.TAG_NAME, 'video')
                    video_url = video_element.get_attribute('src')
                    if video_url: return video_url.strip()
                except:
                    pass
                    
                script = """
                var videos = document.querySelectorAll('video');
                if (videos.length > 0) { return videos[0].src; }
                return null;
                """
                video_url = driver.execute_script(script)
                if video_url: return video_url
                
            finally:
                driver.quit()
                
        except Exception as e:
            self.log(f"解析失败: {e}")
            return None
        
        return None

    def download_m3u8_with_task_control(self, video_url, anime_name, episode_name, task=None):
        anime_folder = os.path.join(self.download_folder, re.sub(r'[\\/*?:"<>|]', '', anime_name))
        os.makedirs(anime_folder, exist_ok=True)
        
        safe_episode_name = re.sub(r'[\\/*?:"<>|]', '', episode_name)
        output_path = os.path.join(anime_folder, f"{safe_episode_name}.mp4")
        temp_file = output_path + ".tmp"
        
        if self.is_downloaded(anime_name, episode_name):
            if task: task.progress = 100
            return output_path
            
        if os.path.exists(output_path):
            if task: task.progress = 100
            return output_path
            
        try:
            head_resp = self.session.head(video_url, timeout=10)
            total_size = int(head_resp.headers.get('Content-Length', 0))
            
            if total_size == 0:
                return self._download_single_stream(video_url, output_path, task)
                
            if task:
                task.total = total_size
                task.message = f"开始下载 (大小: {total_size/1024/1024:.2f}MB)"
                
            num_threads = self.max_threads
            chunk_size = total_size // num_threads
            ranges = []
            for i in range(num_threads):
                start = i * chunk_size
                end = (i + 1) * chunk_size - 1 if i < num_threads - 1 else total_size - 1
                ranges.append((start, end))
                
            with open(temp_file, 'wb') as f:
                f.seek(total_size - 1)
                f.write(b'\0')
                
            downloaded_bytes = 0
            lock = threading.Lock()
            
            def download_chunk(start, end):
                nonlocal downloaded_bytes
                headers = self.headers.copy()
                headers['Range'] = f'bytes={start}-{end}'
                
                try:
                    resp = self.session.get(video_url, headers=headers, stream=True, timeout=30)
                    resp.raise_for_status()
                    
                    with open(temp_file, 'r+b') as f:
                        f.seek(start)
                        for chunk in resp.iter_content(chunk_size=8192):
                            if task and task.stop_event.is_set(): return False
                            if task: task.pause_event.wait()
                            
                            if chunk:
                                f.write(chunk)
                                with lock:
                                    downloaded_bytes += len(chunk)
                                    if task:
                                        task.update_bytes(len(chunk))
                                        task.progress = int((downloaded_bytes / total_size) * 100)
                    return True
                except Exception as e:
                    return False

            with ThreadPoolExecutor(max_workers=num_threads) as executor:
                futures = [executor.submit(download_chunk, s, e) for s, e in ranges]
                results = [f.result() for f in as_completed(futures)]
                
            if not all(results) or (task and task.stop_event.is_set()):
                if os.path.exists(temp_file): os.remove(temp_file)
                return None
                
            os.rename(temp_file, output_path)
            
            self.download_history[f"{anime_name}||{episode_name}"] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            
            if task: task.progress = 100
            return output_path
            
        except Exception as e:
            self.log(f"下载失败: {e}")
            if os.path.exists(temp_file): os.remove(temp_file)
            return None

    def _download_single_stream(self, video_url, output_path, task):
        try:
            resp = self.session.get(video_url, stream=True, timeout=30)
            with open(output_path, 'wb') as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    if task and task.stop_event.is_set():
                        # Close file implicitly by breaking/returning (but we need to delete it)
                        break
                        
                    if chunk:
                        f.write(chunk)
                        if task: task.update_bytes(len(chunk))
            
            if task and task.stop_event.is_set():
                if os.path.exists(output_path):
                    try: os.remove(output_path)
                    except: pass
                return None
            
            self.download_history[f"{os.path.basename(os.path.dirname(output_path))}||{os.path.basename(output_path).replace('.mp4','')}"] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            return output_path
        except: return None

if __name__ == "__main__":
    source = YhdmSource()
    res = source.search_anime("进击")
    print(res)
