import requests
import urllib3

urllib3.disable_warnings()

url = "https://player.danmuzf.vip/danmuku/?nk=53442"
# Also try the comment ID
url2 = "https://player.danmuzf.vip/danmuku/?nk=52909"

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Referer": "https://m.ezdmw.site/Index/video/53442.html"
}

print(f"Testing {url} with Referer")
try:
    resp = requests.get(url, headers=headers, verify=False)
    print(f"Status: {resp.status_code}")
    print(resp.text[:500])
    if "<video" in resp.text:
        print("Found video tag!")
    else:
        print("No video tag.")
except Exception as e:
    print(f"Error: {e}")

print("-" * 20)

print(f"Testing {url2} with Referer")
try:
    resp = requests.get(url2, headers=headers, verify=False)
    print(f"Status: {resp.status_code}")
    print(resp.text[:500])
    if "<video" in resp.text:
        print("Found video tag!")
    else:
        print("No video tag.")
except Exception as e:
    print(f"Error: {e}")
