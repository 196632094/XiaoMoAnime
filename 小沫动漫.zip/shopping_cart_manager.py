import json
import os
import time

class ShoppingCartManager:
    def __init__(self, file_path="shopping_cart.json"):
        self.file_path = file_path
        self.items = [] # List of {anime_name, url, added_at, episodes: []}
        self.load()

    def load(self):
        if os.path.exists(self.file_path):
            try:
                with open(self.file_path, 'r', encoding='utf-8') as f:
                    self.items = json.load(f)
            except Exception as e:
                print(f"Failed to load shopping cart: {e}")
                self.items = []

    def save(self):
        try:
            with open(self.file_path, 'w', encoding='utf-8') as f:
                json.dump(self.items, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Failed to save shopping cart: {e}")

    def add_anime(self, anime_name, url, episodes=None, source='girigiri', cover=''):
        # Check if already exists
        for item in self.items:
            if item['anime_name'] == anime_name:
                # Update source just in case
                if 'source' not in item:
                    item['source'] = source
                
                # Update cover if provided
                if cover:
                    item['cover'] = cover
                
                # Update episodes if provided
                if episodes:
                    current_eps = {e['name']: e for e in item.get('episodes', [])}
                    for ep in episodes:
                        current_eps[ep['name']] = ep
                    item['episodes'] = list(current_eps.values())
                    self.save()
                return True 
        
        self.items.append({
            'anime_name': anime_name,
            'url': url,
            'episodes': episodes or [],
            'added_at': time.time(),
            'source': source,
            'cover': cover
        })
        self.save()
        return True

    def remove_episode(self, anime_name, episode_name):
        for item in self.items:
            if item['anime_name'] == anime_name:
                item['episodes'] = [ep for ep in item['episodes'] if ep['name'] != episode_name]
                if not item['episodes']:
                    # If no episodes left, remove anime? Or keep empty container?
                    # User asked to remove specific episode. If all gone, maybe remove anime?
                    # Let's keep anime container for now, user can remove anime explicitly.
                    pass 
                self.save()
                return True
        return False

    def remove_anime(self, anime_name):
        initial_len = len(self.items)
        self.items = [item for item in self.items if item['anime_name'] != anime_name]
        if len(self.items) < initial_len:
            self.save()
            return True
        return False

    def get_all(self):
        return sorted(self.items, key=lambda x: x['added_at'], reverse=True)

    def update_episodes(self, anime_name, episodes):
        for item in self.items:
            if item['anime_name'] == anime_name:
                item['episodes'] = episodes
                self.save()
                return True
        return False
