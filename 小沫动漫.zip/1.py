import os
import requests
import re
import json
import m3u8
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from concurrent.futures import ThreadPoolExecutor
from Crypto.Cipher import AES

class FanTuanSpider:
    def __init__(self):
        self.base_url = "https://acgfta.com"
        self.search_url = f"{self.base_url}/search.html?wd="
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Referer": self.base_url,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2"
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)

    def search(self, keyword):
        """搜索番剧"""
        url = self.search_url + requests.utils.quote(keyword)
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            results = []
            items = soup.select('body > main > div > div.mt-2-5 > div > div > div > a')
            for item in items:
                title = item.get('title', '').strip() or item.text.strip()
                href = item.get('href', '')
                if href:
                    href = urljoin(self.base_url, href)
                    results.append({
                        'title': title,
                        'url': href
                    })
            return results
        except Exception as e:
            print(f"搜索失败: {e}")
            return []

    def get_episodes(self, detail_url):
        """获取剧集列表"""
        try:
            print(f"正在获取剧集列表: {detail_url}")
            response = self.session.get(detail_url, timeout=10)
            response.raise_for_status()
            response.encoding = 'utf-8' # Ensure UTF-8
            soup = BeautifulSoup(response.text, 'html.parser')
            
            episodes = []
            selectors = [
                '.module-play-list-content a',
                '.scroll-content a',
                '#线路一 > a',
                '.anime-episode a',
                '.episode-list a',
                '.playlist a',
                'a[href*="episode"]',
                'a[href*="/play/"]'
            ]
            
            for selector in selectors:
                items = soup.select(selector)
                if items:
                    current_episodes = []
                    for item in items:
                        ep_name = item.text.strip()
                        ep_url = item.get('href', '')
                        if ep_url:
                            ep_url = urljoin(self.base_url, ep_url)
                            # Filter out non-play links if using generic selector
                            if selector == 'a[href*="/play/"]' and 'vod' not in ep_url and 'play' not in ep_url:
                                continue
                                
                            current_episodes.append({
                                'name': ep_name,
                                'url': ep_url
                            })
                    
                    if current_episodes:
                        episodes = current_episodes
                        print(f"使用选择器 '{selector}' 找到 {len(episodes)} 集")
                        break
            
            if not episodes:
                print("⚠️ 未找到任何剧集，尝试调试...")
                # Try to find any list of links
                all_links = soup.select('.module-list a, .content a') 
                print(f"页面包含 {len(all_links)} 个潜在链接")
                
            return episodes
        except Exception as e:
            print(f"获取剧集失败: {e}")
            return []

    def get_video_url(self, episode_url):
        """解析视频真实地址"""
        try:
            print(f"正在解析: {episode_url}")
            response = self.session.get(episode_url, timeout=10)
            response.raise_for_status()
            
            # 调试用：保存页面内容
            self._debug_save_page(response.text)
            
            # 方法1：从iframe中提取
            iframe_url = self._extract_from_iframe(response.text)
            if iframe_url:
                return iframe_url
                
            # 方法2：从JavaScript变量中提取
            js_url = self._extract_from_javascript(response.text)
            if js_url:
                return js_url
                
            # 方法3：从JSON数据中提取
            json_url = self._extract_from_json(response.text)
            if json_url:
                return json_url
                
            # 方法4：通用视频地址匹配
            return self._extract_universal(response.text)
            
        except Exception as e:
            print(f"解析视频地址失败: {e}")
            return None

    def download_video(self, video_url, filename):
        """下载视频(支持m3u8)"""
        if video_url and video_url.endswith('.m3u8'):
            downloader = M3U8Downloader(self.session)
            return downloader.download_m3u8(video_url, filename)
        else:
            # 原有普通视频下载逻辑
            try:
                os.makedirs('downloads', exist_ok=True)
                filepath = os.path.join('downloads', filename)
                
                print(f"开始下载: {filename}")
                headers = {
                    **self.headers,
                    "Accept-Encoding": "identity",
                    "Range": "bytes=0-"
                }
                
                with self.session.get(video_url, headers=headers, stream=True, timeout=30) as r:
                    r.raise_for_status()
                    total_size = int(r.headers.get('content-length', 0))
                    downloaded = 0
                    
                    with open(filepath, 'wb') as f:
                        for chunk in r.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                                downloaded += len(chunk)
                                if total_size > 0:
                                    percent = downloaded / total_size * 100
                                    print(f"\r下载进度: {percent:.1f}%", end='', flush=True)
                    print("\n下载完成!")
                return filepath
            except Exception as e:
                print(f"\n下载失败: {e}")
                return None

    def _extract_from_iframe(self, html):
        """从iframe中提取视频地址"""
        iframe_pattern = re.compile(r'<iframe[^>]+src="([^"]+)"')
        iframe_matches = iframe_pattern.findall(html)
        for iframe_url in iframe_matches:
            if any(x in iframe_url for x in ['m3u8', 'mp4', 'mkv', 'flv', 'video', 'play']):
                return iframe_url
            try:
                print(f"发现嵌套iframe，正在深入解析: {iframe_url}")
                nested_response = self.session.get(iframe_url, timeout=10)
                nested_response.raise_for_status()
                return self._extract_from_javascript(nested_response.text) or \
                       self._extract_from_json(nested_response.text) or \
                       self._extract_universal(nested_response.text)
            except:
                continue
        return None
        
    def _extract_from_javascript(self, html):
        """从JavaScript变量中提取视频地址"""
        patterns = [
            r'var\s+video_url\s*=\s*["\']([^"\']+)["\']',
            r'player\.setup $[^)]*url["\']?\s*:\s*["\']([^"\']+)',
            r'video_url\s*=\s*["\']([^"\']+)["\']',
            r'src:\s*["\']([^"\']+)["\']'
        ]
        for pattern in patterns:
            matches = re.compile(pattern).findall(html)
            if matches:
                return matches[0]
        return None
        
    def _extract_from_json(self, html):
        """从JSON数据中提取视频地址"""
        try:
            json_pattern = re.compile(r'\{.*?(?:url|src|video_url).*?\}', re.DOTALL)
            json_matches = json_pattern.findall(html)
            for match in json_matches:
                try:
                    data = json.loads(match)
                    for key in ['url', 'src', 'video_url', 'videoUrl', 'video']:
                        if key in data and isinstance(data[key], str) and \
                           any(x in data[key] for x in ['http', 'm3u8', 'mp4']):
                            return data[key]
                except:
                    continue
        except:
            pass
        return None
        
    def _extract_universal(self, html):
        """通用视频地址匹配"""
        patterns = [
            r'(http[s]?://[^\s<>"\']+\.m3u8[^\s<>"\']*)',
            r'(http[s]?://[^\s<>"\']+\.(?:mp4|mkv|flv)[^\s<>"\']*)',
            r'(http[s]?://[^\s<>"\']+/[^\s<>"\']*?(?:video|play|stream)[^\s<>"\']*)'
        ]
        for pattern in patterns:
            matches = re.compile(pattern).findall(html)
            if matches:
                return matches[0]
        return None
        
    def _debug_save_page(self, html):
        """调试用：保存页面内容"""
        os.makedirs('debug', exist_ok=True)
        with open('debug/last_page.html', 'w', encoding='utf-8') as f:
            f.write(html)
        print("已保存页面内容到 debug/last_page.html")

class M3U8Downloader:
    def __init__(self, session):
        self.session = session
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': 'https://acgfta.com/'
        }
        
    def download_m3u8(self, m3u8_url, output_filename):
        """下载并合并m3u8视频"""
        try:
            print(f"开始处理m3u8视频: {m3u8_url}")
            
            # 1. 下载m3u8主文件
            m3u8_content = self._download_content(m3u8_url)
            if not m3u8_content:
                return False
                
            # 调试：保存m3u8内容
            os.makedirs('debug', exist_ok=True)
            with open('debug/m3u8_content.m3u8', 'w', encoding='utf-8') as f:
                f.write(m3u8_content)
                
            # 2. 解析m3u8内容
            base_uri = os.path.dirname(m3u8_url) + '/'
            m3u8_obj = m3u8.loads(m3u8_content, uri=base_uri)
            
            # 处理主m3u8文件
            if m3u8_obj.playlists:
                playlist = m3u8_obj.playlists[0]
                m3u8_url = urljoin(base_uri, playlist.uri)
                m3u8_content = self._download_content(m3u8_url)
                if not m3u8_content:
                    return False
                m3u8_obj = m3u8.loads(m3u8_content, uri=base_uri)
                
            # 3. 创建临时目录
            temp_dir = 'temp_ts_files'
            os.makedirs(temp_dir, exist_ok=True)
            
            # 4. 下载所有ts片段
            ts_urls = [urljoin(base_uri, segment.uri) for segment in m3u8_obj.segments]
            key = self._get_decryption_key(m3u8_obj)
            
            print(f"共发现 {len(ts_urls)} 个视频片段...")
            
            # 多线程下载
            with ThreadPoolExecutor(max_workers=5) as executor:
                list(executor.map(lambda x: self._download_ts(x[0], x[1], temp_dir, key, ts_urls), enumerate(ts_urls)))
            
            # 检查是否所有ts片段都已下载
            if not self._check_ts_files(temp_dir, len(ts_urls)):
                print("ts片段下载不完整，无法合并。")
                self._cleanup(temp_dir)
                return False
            
            # 5. 合并ts文件
            self._merge_ts_files(temp_dir, output_filename)
            
            # 6. 清理临时文件
            self._cleanup(temp_dir)
            
            print(f"视频已成功保存为: {output_filename}")
            return True
            
        except Exception as e:
            print(f"下载m3u8视频失败: {e}")
            return False
            
    def _download_content(self, url):
        """下载内容"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
                'Referer': 'https://acgfta.com/'
            }
            response = self.session.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            return response.text
        except Exception as e:
            print(f"下载内容失败: {url} - {e}")
            return None
            
    def _get_decryption_key(self, m3u8_obj):
        """获取解密密钥(如果有加密)"""
        if not m3u8_obj.keys or not m3u8_obj.keys[0]:
            return None
            
        key_uri = m3u8_obj.keys[0].uri
        if not key_uri:
            return None
            
        try:
            key_url = urljoin(m3u8_obj.base_uri, key_uri)
            key = self.session.get(key_url).content
            return key
        except Exception as e:
            print(f"获取密钥失败: {key_url} - {e}")
            return None
            
    def _download_ts(self, index, ts_url, temp_dir, key, ts_urls):
        """下载单个ts片段"""
        try:
            ts_filename = os.path.join(temp_dir, f"{index:05d}.ts")
            
            # 如果文件已存在且大小合理，跳过下载
            if os.path.exists(ts_filename) and os.path.getsize(ts_filename) > 1024:
                return
                
            content = self.session.get(ts_url, timeout=30).content
            
            # 如果需要解密
            if key:
                # 简单IV生成（实际应用中可能需要从m3u8中获取IV）
                iv = bytes([index % 256] * 16)
                cipher = AES.new(key, AES.MODE_CBC, iv=iv)
                content = cipher.decrypt(content)
                
            with open(ts_filename, 'wb') as f:
                f.write(content)
                
            print(f"已下载片段 {index + 1}/{len(ts_urls)}", end='\r', flush=True)
        except Exception as e:
            print(f"下载片段失败: {ts_url} - {e}")
            
    def _merge_ts_files(self, temp_dir, output_filename):
        """合并所有ts文件"""
        os.makedirs('downloads', exist_ok=True)
        output_path = os.path.join('downloads', output_filename)
        
        with open(output_path, 'wb') as outfile:
            for ts_file in sorted(os.listdir(temp_dir)):
                if ts_file.endswith('.ts'):
                    ts_path = os.path.join(temp_dir, ts_file)
                    with open(ts_path, 'rb') as infile:
                        outfile.write(infile.read())
                        
    def _check_ts_files(self, temp_dir, expected_count):
        """检查ts片段是否完整"""
        ts_files = [f for f in os.listdir(temp_dir) if f.endswith('.ts')]
        return len(ts_files) == expected_count
        
    def _cleanup(self, temp_dir):
        """清理临时文件"""
        for file in os.listdir(temp_dir):
            os.remove(os.path.join(temp_dir, file))
        os.rmdir(temp_dir)

def main():
    print("饭团动漫下载器 完整版 v3.0")
    spider = FanTuanSpider()
    
    while True:
        # 1. 搜索时搜索番剧
        keyword = input("\n请输入要搜索的番剧名称: ").strip()
        if not keyword:
            print("请输入有效的搜索关键词")
            continue
            
        print("\n正在搜索...")
        results = spider.search(keyword)
        
        if not results:
            print("未找到相关番剧")
            continue
            
        print("\n搜索结果:")
        for i, item in enumerate(results, 1):
            print(f"{i}. {item['title']}")
        
        # 2. 选择番剧
        while True:
            try:
                choice = input("\n请选择番剧(输入序号): ").strip()
                if not choice:
                    print("请选择有效的序号")
                    continue
                    
                choice = int(choice) - 1
                if 0 <= choice < len(results):
                    selected = results[choice]
                    break
                else:
                    print("序号超出范围，请重新输入")
            except ValueError:
                print("请输入数字序号")
        
        # 3. 获取剧集
        print(f"\n正在获取 {selected['title']} 的剧集列表...")
        episodes = spider.get_episodes(selected['url'])
        if not episodes:
            print("未找到剧集")
            continue
            
        print("\n剧集列表:")
        print("0. 全部下载")
        for i, ep in enumerate(episodes, 1):
            print(f"{i}. {ep['name']}")
        
        # 4. 选择剧集
        while True:
            try:
                ep_choice = input("\n请选择剧集(输入序号): ").strip()
                if not ep_choice:
                    print("请选择有效的序号")
                    continue
                    
                ep_choice = int(ep_choice)
                if ep_choice == 0:
                    # 下载全部剧集
                    for i, ep in enumerate(episodes):
                        selected_ep = episodes[i]
                        print(f"\n正在解析 {selected_ep['name']} 的视频地址...")
                        video_url = spider.get_video_url(selected_ep['url'])
                        if not video_url:
                            print("无法解析视频地址，请检查debug/last_page.html")
                            continue
                            
                        print(f"\n视频地址: {video_url}")
                        
                        # 下载视频
                        filename = f"{selected['title']}_{selected_ep['name']}.mp4"
                        filename = re.sub(r'[\\/*?:"<>|]', '', filename)
                        spider.download_video(video_url, filename)
                    break
                elif 1 <= ep_choice <= len(episodes):
                    selected_ep = episodes[ep_choice - 1]
                    print(f"\n正在解析 {selected_ep['name']} 的视频地址...")
                    video_url = spider.get_video_url(selected_ep['url'])
                    if not video_url:
                        print("无法解析视频地址，请检查debug/last_page.html")
                        continue
                        
                    print(f"\n视频地址: {video_url}")
                    
                    # 下载视频
                    filename = f"{selected['title']}_{selected_ep['name']}.mp4"
                    filename = re.sub(r'[\\/*?:"<>|]', '', filename)
                    spider.download_video(video_url, filename)
                    break
                else:
                    print("序号超出范围，请重新输入")
            except ValueError:
                print("请输入数字序号")

if __name__ == "__main__":
    main()
