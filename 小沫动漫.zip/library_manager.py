import os
import shutil
import time
import re
import hashlib
import collections

class LibraryManager:
    def __init__(self, settings_manager):
        self.settings = settings_manager
        self._rename_lock = False
        self._rename_progress = {
            'running': False,
            'total': 0,
            'processed': 0,
            'renamed': 0,
            'skipped': 0,
            'failed': 0,
            'message': ''
        }
        self._download_history_file = os.path.join("logs", "download_history.json")

    def get_download_folder(self):
        return self.settings.get("download_folder", "downloads")

    def get_anime_list(self):
        base_path = self.get_download_folder()
        if not os.path.exists(base_path):
            return []
        
        anime_list = []
        try:
            for entry in os.scandir(base_path):
                if entry.is_dir() and entry.name != "temp":
                    # Get stats
                    stat = entry.stat()
                    # Calculate directory size
                    size = 0
                    for root, dirs, files in os.walk(entry.path):
                        for f in files:
                            try:
                                size += os.path.getsize(os.path.join(root, f))
                            except: pass
                            
                    anime_list.append({
                        'name': entry.name,
                        'path': entry.path,
                        'mtime': stat.st_mtime,
                        'ctime': stat.st_ctime,
                        'size': size
                    })
            
            # Sort by mtime descending (newest first)
            anime_list.sort(key=lambda x: x['mtime'], reverse=True)
            return anime_list
        except Exception as e:
            print(f"Error scanning library: {e}")
            return []

    def get_storage_stats(self):
        base_path = self.get_download_folder()
        if not os.path.exists(base_path):
            os.makedirs(base_path)
            
        total_used = 0
        try:
            for root, dirs, files in os.walk(base_path):
                for f in files:
                    try:
                        total_used += os.path.getsize(os.path.join(root, f))
                    except: pass
        except: pass
        
        # Disk usage
        try:
            import shutil
            disk_usage = shutil.disk_usage(base_path)
            free_space = disk_usage.free
            total_disk = disk_usage.total
        except:
            free_space = 0
            total_disk = 0
            
        return {
            'library_used': total_used,
            'disk_free': free_space,
            'disk_total': total_disk
        }

    def get_episodes(self, anime_name):
        base_path = self.get_download_folder()
        anime_path = os.path.join(base_path, anime_name)
        
        if not os.path.exists(anime_path):
            return []
        
        episodes = []
        try:
            for root, dirs, files in os.walk(anime_path):
                for f in files:
                    if not f.lower().endswith(('.mp4', '.mkv', '.avi')):
                        continue
                    p = os.path.join(root, f)
                    stat = os.stat(p)
                    rel_name = os.path.relpath(p, anime_path).replace("\\", "/")
                    episodes.append({
                        'name': rel_name,
                        'path': p,
                        'size': stat.st_size,
                        'mtime': stat.st_mtime
                    })
            
            # Sort by name usually, or mtime
            # Standard naming "第x集" might sort weirdly alphabetically, but let's try simple sort first
            # Or sort by mtime
            episodes.sort(key=lambda x: x['name'])
            return episodes
        except Exception as e:
            print(f"Error scanning episodes: {e}")
            return []

    def delete_anime(self, anime_name):
        base_path = self.get_download_folder()
        anime_path = os.path.join(base_path, anime_name)
        
        try:
            if os.path.exists(anime_path):
                shutil.rmtree(anime_path)
                return True
            return False
        except Exception as e:
            print(f"Error deleting anime: {e}")
            return False

    def batch_delete_anime(self, anime_names):
        """批量删除番剧"""
        results = {'success': [], 'failed': []}
        for name in anime_names:
            if self.delete_anime(name):
                results['success'].append(name)
            else:
                results['failed'].append(name)
        return results

    def delete_episode(self, anime_name, episode_name):
        base_path = self.get_download_folder()
        safe_rel = (episode_name or "").replace("/", os.sep).replace("\\", os.sep)
        episode_path = os.path.join(base_path, anime_name, safe_rel)
        
        try:
            if os.path.exists(episode_path):
                os.remove(episode_path)
                return True
            return False
        except Exception as e:
            print(f"Error deleting episode: {e}")
            return False

    def _load_download_history(self):
        if os.path.exists(self._download_history_file):
            try:
                import json
                with open(self._download_history_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return data if isinstance(data, dict) else {}
            except:
                return {}
        return {}

    def _save_download_history(self, history: dict):
        try:
            import json
            os.makedirs(os.path.dirname(self._download_history_file), exist_ok=True)
            with open(self._download_history_file, "w", encoding="utf-8") as f:
                json.dump(history, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Failed to save download history: {e}")

    def _cleanup_empty_dirs(self, base_path: str):
        for root, dirs, files in os.walk(base_path, topdown=False):
            if os.path.abspath(root) == os.path.abspath(base_path):
                continue
            if os.path.basename(root) == "temp":
                continue
            try:
                if not os.listdir(root):
                    os.rmdir(root)
            except:
                pass

    def _iter_media_files(self, base_path: str):
        if not base_path or not os.path.exists(base_path):
            return
        for root, dirs, files in os.walk(base_path):
            if os.path.basename(root) == "temp":
                continue
            for f in files:
                if not f.lower().endswith(('.mp4', '.mkv', '.avi')):
                    continue
                yield os.path.join(root, f)

    def _guess_anime_episode(self, base_path: str, file_path: str):
        try:
            rel = os.path.relpath(file_path, base_path).replace("\\", "/")
        except:
            return None
        parts = [p for p in rel.split("/") if p]
        if not parts:
            return None
        if parts[0].lower() == "temp":
            return None

        filename = parts[-1]
        stem, _ext = os.path.splitext(filename)

        show_folder = parts[0] if len(parts) >= 2 else ""
        if not show_folder:
            show_folder = "未分类"
        m = re.match(r'^(.*)\s*\((19\d{2}|20\d{2})\)\s*$', show_folder)
        show_name = (m.group(1) if m else show_folder).strip() or show_folder

        sxe = re.search(r'\bS(\d{1,2})E(\d{1,4})\b', stem, flags=re.IGNORECASE)
        if sxe:
            ep_num = int(sxe.group(2))
            title = ""
            if " - " in stem:
                tail = stem.split(" - ")[-1].strip()
                if tail and not re.search(r'\bS\d{1,2}E\d{1,4}\b', tail, flags=re.IGNORECASE):
                    title = tail
            episode_name = f"第{ep_num}集 {title}".strip() if title else f"第{ep_num}集"
            return show_name, episode_name

        ep_stem = stem.strip() or "Unknown"
        return show_name, ep_stem

    def _backfill_history_from_files(self, history: dict, base_path: str):
        from naming_rules import history_key
        if not isinstance(history, dict):
            history = {}
        for p in self._iter_media_files(base_path):
            guessed = self._guess_anime_episode(base_path, p)
            if not guessed:
                continue
            anime_name, episode_name = guessed
            k = history_key(anime_name, episode_name)
            if k in history:
                continue
            history[k] = {
                "path": p,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
        return history

    def get_rename_preview(self, scheme: str):
        from naming_rules import build_download_path
        base = self.get_download_folder()
        history = self._load_download_history()
        history = self._backfill_history_from_files(history, base)
        items = []
        default_season = 1
        for k, record in history.items():
            try:
                if not isinstance(record, dict):
                    continue
                src_path = record.get("path")
                if not src_path or not os.path.exists(src_path):
                    continue
                anime_name = k.split("||", 1)[0] if "||" in k else ""
                episode_key = k.split("||", 1)[1] if "||" in k else ""
                ext = os.path.splitext(src_path)[1].lstrip(".") or "mp4"
                dst_path, _ = build_download_path(
                    base, anime_name, episode_key,
                    scheme=scheme, ext=ext, default_season=default_season
                )
                items.append({
                    "key": k,
                    "current": os.path.relpath(src_path, base).replace("\\", "/"),
                    "target": os.path.relpath(dst_path, base).replace("\\", "/"),
                    "exists_target": os.path.exists(dst_path)
                })
            except Exception as e:
                items.append({"key": k, "error": str(e)})
        return {"count": len(items), "items": items}

    def start_rename(self, scheme: str):
        if self._rename_lock or self._rename_progress.get('running'):
            return {'status': 'error', 'message': '已有重命名任务进行中'}
        self._rename_lock = True
        
        # Set running immediately to prevent polling race condition
        self._rename_progress.update({
            'running': True,
            'total': 0,
            'processed': 0,
            'renamed': 0,
            'skipped': 0,
            'failed': 0,
            'message': '正在扫描文件...'
        })
        
        try:
            import threading
            def worker():
                try:
                    from naming_rules import build_download_path, ensure_parent_dir
                    base = self.get_download_folder()
                    history = self._load_download_history()
                    history = self._backfill_history_from_files(history, base)
                    entries = [(k, v) for k, v in history.items() if isinstance(v, dict) and v.get("path")]
                    entries = [(k, v) for k, v in entries if os.path.exists(v.get("path"))]
                    
                    self._rename_progress.update({
                        'total': len(entries),
                        'message': '开始重命名'
                    })
                    
                    default_season = 1
                    for k, record in entries:
                        try:
                            src_path = record.get("path")
                            anime_name = k.split("||", 1)[0] if "||" in k else ""
                            episode_key = k.split("||", 1)[1] if "||" in k else ""
                            ext = os.path.splitext(src_path)[1].lstrip(".") or "mp4"
                            new_path, _ = build_download_path(
                                base, anime_name, episode_key,
                                scheme=scheme, ext=ext, default_season=default_season
                            )
                            if os.path.abspath(new_path) == os.path.abspath(src_path):
                                self._rename_progress['skipped'] += 1
                            else:
                                ensure_parent_dir(new_path)
                                if os.path.exists(new_path):
                                    self._rename_progress['skipped'] += 1
                                else:
                                    os.rename(src_path, new_path)
                                    record["path"] = new_path
                                    self._rename_progress['renamed'] += 1
                            self._rename_progress['processed'] += 1
                            self._rename_progress['message'] = f"进行中 {self._rename_progress['processed']}/{self._rename_progress['total']}"
                        except Exception as e:
                            self._rename_progress['failed'] += 1
                            self._rename_progress['processed'] += 1
                            self._rename_progress['message'] = f"错误: {str(e)}"
                            
                    self._save_download_history(history)
                    self._cleanup_empty_dirs(base)
                    self._rename_progress['message'] = "已完成"
                    
                except Exception as e:
                    self._rename_progress['message'] = f"任务失败: {str(e)}"
                finally:
                    self._rename_progress['running'] = False
                    self._rename_lock = False
                    
            threading.Thread(target=worker, daemon=True).start()
            return {'status': 'started'}
        except Exception as e:
            self._rename_lock = False
            self._rename_progress['running'] = False
            return {'status': 'error', 'message': str(e)}

    def get_rename_status(self):
        return dict(self._rename_progress)

    def _calculate_partial_hash(self, file_path):
        """计算文件部分哈希（头尾+大小），用于快速比对"""
        try:
            size = os.path.getsize(file_path)
            if size < 8192:
                # 小文件全量哈希
                with open(file_path, 'rb') as f:
                    return hashlib.md5(f.read()).hexdigest()
            
            with open(file_path, 'rb') as f:
                head = f.read(4096)
                f.seek(-4096, 2)
                tail = f.read(4096)
                
            hasher = hashlib.md5()
            hasher.update(head)
            hasher.update(tail)
            hasher.update(str(size).encode('utf-8'))
            return hasher.hexdigest()
        except:
            return None

    def find_duplicates(self):
        """查找重复文件和重复标题"""
        base_path = self.get_download_folder()
        if not os.path.exists(base_path):
            return {'files': [], 'titles': []}

        # 1. 扫描所有视频文件
        all_files = list(self._iter_media_files(base_path))
        
        # 2. 文件查重 (基于大小 + 部分哈希)
        size_map = collections.defaultdict(list)
        for p in all_files:
            try:
                size = os.path.getsize(p)
                size_map[size].append(p)
            except: pass
            
        duplicate_files = []
        # 只处理大小相同且数量 > 1 的组
        for size, paths in size_map.items():
            if len(paths) < 2: continue
            
            # 进一步计算哈希
            hash_map = collections.defaultdict(list)
            for p in paths:
                h = self._calculate_partial_hash(p)
                if h: hash_map[h].append(p)
                
            for h, p_list in hash_map.items():
                if len(p_list) > 1:
                    duplicate_files.append({
                        'hash': h,
                        'size': size,
                        'count': len(p_list),
                        'paths': [os.path.relpath(p, base_path).replace('\\', '/') for p in p_list]
                    })

        # 3. 标题查重 (基于解析后的番剧名和集数)
        # 结构: anime_name -> episode_name -> [paths]
        anime_ep_map = collections.defaultdict(lambda: collections.defaultdict(list))
        
        for p in all_files:
            guessed = self._guess_anime_episode(base_path, p)
            if not guessed: continue
            
            anime_name, episode_name = guessed
            anime_ep_map[anime_name][episode_name].append(p)
            
        duplicate_titles = []
        for anime, episodes in anime_ep_map.items():
            for ep_name, paths in episodes.items():
                if len(paths) > 1:
                    # 如果这些路径完全相同（其实就是文件查重），这里可能也会重复列出？
                    # 标题查重应该包含文件查重的结果吗？
                    # 如果两个文件完全一样，它们肯定标题也一样。
                    # 如果两个文件不一样（大小不同），但标题解析出来一样，这才是我们要找的“标题重复但文件不同”。
                    # 但用户说“标题，视频，匹配重复的”，分开列出比较好。
                    
                    duplicate_titles.append({
                        'anime': anime,
                        'episode': ep_name,
                        'count': len(paths),
                        'paths': [os.path.relpath(p, base_path).replace('\\', '/') for p in paths]
                    })
                    
        return {
            'files': duplicate_files,
            'titles': duplicate_titles
        }
