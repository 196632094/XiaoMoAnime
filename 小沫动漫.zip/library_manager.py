import os
import shutil
import time

class LibraryManager:
    def __init__(self, settings_manager):
        self.settings = settings_manager

    def get_download_folder(self):
        return self.settings.get("download_folder", "downloads")

    def get_anime_list(self):
        base_path = self.get_download_folder()
        if not os.path.exists(base_path):
            return []
        
        anime_list = []
        try:
            for entry in os.scandir(base_path):
                if entry.is_dir() and entry.name != "temp":
                    # Get stats
                    stat = entry.stat()
                    # Calculate directory size
                    size = 0
                    for root, dirs, files in os.walk(entry.path):
                        for f in files:
                            try:
                                size += os.path.getsize(os.path.join(root, f))
                            except: pass
                            
                    anime_list.append({
                        'name': entry.name,
                        'path': entry.path,
                        'mtime': stat.st_mtime,
                        'ctime': stat.st_ctime,
                        'size': size
                    })
            
            # Sort by mtime descending (newest first)
            anime_list.sort(key=lambda x: x['mtime'], reverse=True)
            return anime_list
        except Exception as e:
            print(f"Error scanning library: {e}")
            return []

    def get_storage_stats(self):
        base_path = self.get_download_folder()
        if not os.path.exists(base_path):
            os.makedirs(base_path)
            
        total_used = 0
        try:
            for root, dirs, files in os.walk(base_path):
                for f in files:
                    try:
                        total_used += os.path.getsize(os.path.join(root, f))
                    except: pass
        except: pass
        
        # Disk usage
        try:
            import shutil
            disk_usage = shutil.disk_usage(base_path)
            free_space = disk_usage.free
            total_disk = disk_usage.total
        except:
            free_space = 0
            total_disk = 0
            
        return {
            'library_used': total_used,
            'disk_free': free_space,
            'disk_total': total_disk
        }

    def get_episodes(self, anime_name):
        base_path = self.get_download_folder()
        anime_path = os.path.join(base_path, anime_name)
        
        if not os.path.exists(anime_path):
            return []
        
        episodes = []
        try:
            for entry in os.scandir(anime_path):
                if entry.is_file() and entry.name.endswith(('.mp4', '.mkv', '.avi')):
                    stat = entry.stat()
                    episodes.append({
                        'name': entry.name,
                        'path': entry.path,
                        'size': stat.st_size,
                        'mtime': stat.st_mtime
                    })
            
            # Sort by name usually, or mtime
            # Standard naming "第x集" might sort weirdly alphabetically, but let's try simple sort first
            # Or sort by mtime
            episodes.sort(key=lambda x: x['name'])
            return episodes
        except Exception as e:
            print(f"Error scanning episodes: {e}")
            return []

    def delete_anime(self, anime_name):
        base_path = self.get_download_folder()
        anime_path = os.path.join(base_path, anime_name)
        
        try:
            if os.path.exists(anime_path):
                shutil.rmtree(anime_path)
                return True
            return False
        except Exception as e:
            print(f"Error deleting anime: {e}")
            return False

    def batch_delete_anime(self, anime_names):
        """批量删除番剧"""
        results = {'success': [], 'failed': []}
        for name in anime_names:
            if self.delete_anime(name):
                results['success'].append(name)
            else:
                results['failed'].append(name)
        return results

    def delete_episode(self, anime_name, episode_name):
        base_path = self.get_download_folder()
        episode_path = os.path.join(base_path, anime_name, episode_name)
        
        try:
            if os.path.exists(episode_path):
                os.remove(episode_path)
                return True
            return False
        except Exception as e:
            print(f"Error deleting episode: {e}")
            return False
