import requests
import re
import json
import os
import time
import threading
from urllib.parse import urljoin, unquote
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed
import m3u8
import shutil
from Crypto.Cipher import AES
import zhconv
from naming_rules import build_download_path, ensure_parent_dir, history_key, possible_legacy_history_keys

class Anime1Source:
    def __init__(self, log_callback=None, progress_callback=None):
        self.base_url = "https://anime1.me"
        self.search_url = "https://anime1.me/?s={keyword}"
        self.api_url = "https://v.anime1.me/api"
        
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": self.base_url,
            "Origin": self.base_url
        }
        
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
        self.log_callback = log_callback
        self.progress_callback = progress_callback
        
        self.download_folder = "downloads"
        self.log_folder = "logs"
        self.max_threads = 10 
        self.download_history_file = os.path.join(self.log_folder, "download_history.json")
        
        if not os.path.exists(self.download_folder):
            os.makedirs(self.download_folder)
        if not os.path.exists(self.log_folder):
            os.makedirs(self.log_folder)
            
        self.download_history = self.load_download_history()

    def log(self, message):
        print(message)
        if self.log_callback:
            self.log_callback(message)

    def load_download_history(self):
        if os.path.exists(self.download_history_file):
            try:
                with open(self.download_history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
        
    def save_download_history(self):
        with open(self.download_history_file, 'w', encoding='utf-8') as f:
            json.dump(self.download_history, f, ensure_ascii=False, indent=2)

    def is_downloaded(self, anime_name, episode_name):
        for key in possible_legacy_history_keys(anime_name, episode_name):
            if key not in self.download_history:
                continue
            record = self.download_history.get(key) or {}
            if isinstance(record, dict) and record.get("path") and os.path.exists(record["path"]):
                return True
            try:
                del self.download_history[key]
            except:
                pass
            self.save_download_history()

        scheme = getattr(self, "naming_scheme", "simple")
        default_season = int(getattr(self, "default_season_number", 1) or 1)
        for ext in ["mp4", "mkv", "avi"]:
            expected, _ = build_download_path(
                self.download_folder, anime_name, episode_name,
                scheme=scheme, ext=ext, default_season=default_season
            )
            if os.path.exists(expected):
                self.download_history[history_key(anime_name, episode_name)] = {
                    "path": expected,
                    "time": time.strftime("%Y-%m-%d %H:%M:%S")
                }
                self.save_download_history()
                return True
        return False

    def search_anime(self, keyword):
        # Convert Simplified to Traditional for searching
        keyword_hant = zhconv.convert(keyword, 'zh-hant')
        self.log(f"正在搜索(Anime1): {keyword} -> {keyword_hant}")
        url = self.search_url.format(keyword=keyword_hant)
        
        try:
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            animes = []
            seen_categories = set()
            
            articles = soup.select("article")
            for article in articles:
                # Try to find category link
                cat_links = article.select(".cat-links a")
                for cat in cat_links:
                    cat_url = cat['href']
                    cat_name = cat.get_text().strip()
                    
                    if cat_url not in seen_categories:
                        seen_categories.add(cat_url)
                        
                        # Convert Traditional to Simplified for display
                        cat_name_hans = zhconv.convert(cat_name, 'zh-hans')
                        
                        # Use a generic cover or try to find one in the article
                        # Anime1 usually doesn't show covers in search list easily unless we parse the post content
                        # We'll try to find the first image in the article
                        cover = ""
                        img = article.select_one("img")
                        if img:
                            cover = img.get("src")
                            
                        animes.append({
                            "name": cat_name_hans,
                            "url": cat_url,
                            "source": "anime1",
                            "cover": cover
                        })
            
            return animes
        except Exception as e:
            self.log(f"搜索失败: {e}")
            return []

    def get_episodes(self, anime_url):
        try:
            self.log(f"获取剧集列表: {anime_url}")
            response = self.session.get(anime_url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Anime1 category page lists episodes (posts)
            # We might need to handle pagination to get ALL episodes
            # For now, let's grab the first page
            
            all_episodes = []
            
            def parse_page(page_soup):
                articles = page_soup.select("article")
                for article in articles:
                    title_elem = article.select_one(".entry-title a")
                    if title_elem:
                        ep_name = title_elem.get_text().strip()
                        # Convert Trad to Simp
                        ep_name_hans = zhconv.convert(ep_name, 'zh-hans')
                        
                        ep_url = title_elem['href']
                        
                        # Extract episode number
                        # Pattern: Anime Name [Episode] or Anime Name - Episode
                        match = re.search(r'\[(\d+(\.\d+)?)\]', ep_name)
                        if not match:
                             match = re.search(r'\s(\d+(\.\d+)?)$', ep_name)
                        
                        ep_num = match.group(1) if match else ep_name_hans
                        
                        all_episodes.append({
                            'name': ep_name_hans,
                            'original_name': ep_name,
                            'url': ep_url,
                            'episode': ep_num,
                            'source_name': 'Anime1'
                        })

            parse_page(soup)
            
            # Check for "Previous" link (older posts)
            # If we want to be thorough, we loop. 
            # Limit to 5 pages for safety/speed for now.
            current_soup = soup
            page_count = 1
            while page_count < 5:
                prev_link = current_soup.select_one(".nav-previous a")
                if prev_link:
                    next_url = prev_link['href']
                    self.log(f"加载更多剧集 (Page {page_count+1}): {next_url}")
                    try:
                        resp = self.session.get(next_url, timeout=10)
                        current_soup = BeautifulSoup(resp.text, 'html.parser')
                        parse_page(current_soup)
                        page_count += 1
                    except:
                        break
                else:
                    break
            
            # Return dict format
            return {
                'episodes': all_episodes,
                'sources': [{
                    'name': 'Anime1',
                    'episodes': all_episodes
                }]
            }
            
        except Exception as e:
            self.log(f"获取剧集失败: {e}")
            return []

    def get_video_url(self, episode_url):
        try:
            self.log(f"正在解析视频地址: {episode_url}")
            # Ensure we have cookies by visiting the page first
            response = self.session.get(episode_url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            video = soup.select_one("video")
            if not video:
                self.log("未找到Video标签")
                return None
                
            data_apireq = video.get("data-apireq")
            if not data_apireq:
                self.log("未找到data-apireq")
                return None
                
            # Post to API
            # Update Referer to be the episode page
            api_headers = self.headers.copy()
            api_headers['Referer'] = "https://anime1.me/"
            api_headers['Content-Type'] = 'application/x-www-form-urlencoded'
            
            payload = f"d={data_apireq}"
            
            # Use session to preserve cookies!
            api_resp = self.session.post(self.api_url, data=payload, headers=api_headers, timeout=10)
            
            if api_resp.status_code != 200:
                self.log(f"API请求失败: {api_resp.status_code}")
                return None
                
            json_data = api_resp.json()
            if 's' in json_data and len(json_data['s']) > 0:
                video_src = json_data['s'][0].get('src')
                if video_src:
                    if video_src.startswith("//"):
                        video_src = "https:" + video_src
                    self.log(f"解析成功: {video_src}")
                    return video_src
            
            self.log("解析JSON失败或无源")
            return None
            
        except Exception as e:
            self.log(f"解析视频失败: {e}")
            return None

    # --- Downloading Logic (Copied/Adapted from OmoFunSource) ---

    def _get_decryption_key(self, m3u8_obj):
        if not m3u8_obj.keys or not m3u8_obj.keys[0]: return None
        key_uri = m3u8_obj.keys[0].uri
        if not key_uri: return None
        try:
            key_url = urljoin(m3u8_obj.base_uri, key_uri)
            return self.session.get(key_url).content
        except: return None

    def _download_content(self, url):
        try:
            return self.session.get(url, timeout=10).text
        except: return None

    def download_m3u8_with_task_control(self, video_url, anime_name, episode_name, task=None):
        # We MUST ensure we have cookies from the session if this is a direct download or m3u8
        # The session should have cookies if get_video_url was called on this instance.
        # But if the task was restarted or in a new thread/process context where session is fresh,
        # we might be missing cookies.
        
        # However, in this architecture, TaskManager calls get_video_url right before download_m3u8_with_task_control
        # on the SAME source instance. So self.session should be populated.
        
        is_m3u8 = '.m3u8' in video_url or 'application/vnd.apple.mpegurl' in video_url
        if not is_m3u8:
            try:
                # Use session!
                head_resp = self.session.head(video_url, timeout=5)
                if 'mpegurl' in head_resp.headers.get('Content-Type', ''):
                    is_m3u8 = True
            except: pass

        if is_m3u8:
            return self._download_m3u8_internal(video_url, anime_name, episode_name, task)
        else:
            return self._download_direct_internal(video_url, anime_name, episode_name, task)

    def _download_m3u8_internal(self, m3u8_url, anime_name, episode_name, task=None):
        anime_folder = os.path.join(self.download_folder, re.sub(r'[\\/*?:"<>|]', '', anime_name))
        os.makedirs(anime_folder, exist_ok=True)
        
        safe_episode_name = re.sub(r'[\\/*?:"<>|]', '', episode_name)
        output_path = os.path.join(anime_folder, f"{safe_episode_name}.mp4")
        
        if self.is_downloaded(anime_name, episode_name):
            if task: task.progress = 100
            return output_path
            
        if os.path.exists(output_path):
            if task: task.progress = 100
            return output_path
        
        try:
            self.log(f"正在获取m3u8播放列表: {m3u8_url}")
            base_uri = os.path.dirname(m3u8_url) + '/'
            content = self._download_content(m3u8_url)
            if not content: return None
            
            m3u8_obj = m3u8.loads(content, uri=base_uri)
            
            if m3u8_obj.playlists:
                playlist = m3u8_obj.playlists[0]
                m3u8_url = urljoin(base_uri, playlist.uri)
                base_uri = os.path.dirname(m3u8_url) + '/'
                content = self._download_content(m3u8_url)
                if not content: return None
                m3u8_obj = m3u8.loads(content, uri=base_uri)
            
            segments = m3u8_obj.segments
            if not segments:
                self.log(f"❌ 无法获取视频分片列表")
                return None
            
            key = self._get_decryption_key(m3u8_obj)
            
            safe_anime_name = re.sub(r'[\\/*?:"<>|\s]', '_', anime_name)
            safe_episode = re.sub(r'[\\/*?:"<>|\s]', '_', safe_episode_name)
            temp_dir = os.path.join(self.download_folder, "temp", f"{safe_anime_name}_{safe_episode}")
            os.makedirs(temp_dir, exist_ok=True)
            
            total_segments = len(segments)
            if task:
                task.total = total_segments
                task.message = f"开始下载 {total_segments} 个分片 (m3u8)"
            
            def download_segment(segment, index):
                if task:
                    task.pause_event.wait()
                    if task.stop_event.is_set(): return False
                
                segment_url = urljoin(base_uri, segment.uri)
                segment_path = os.path.join(temp_dir, f"segment_{index:04d}.ts")
                
                if os.path.exists(segment_path) and os.path.getsize(segment_path) > 1024:
                    return True
                
                for attempt in range(5):
                    if task and task.stop_event.is_set(): return False
                    try:
                        content = self.session.get(segment_url, timeout=30).content
                        if key:
                            iv = bytes([index % 256] * 16)
                            cipher = AES.new(key, AES.MODE_CBC, iv=iv)
                            content = cipher.decrypt(content)
                        
                        with open(segment_path, 'wb') as f:
                            f.write(content)
                            if task: task.update_bytes(len(content))
                        return True
                    except Exception as e:
                        time.sleep(1)
                return False

            downloaded_count = 0
            with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
                futures = {executor.submit(download_segment, segment, i): i for i, segment in enumerate(segments)}
                for future in as_completed(futures):
                    if task and task.stop_event.is_set(): break
                    if future.result():
                        downloaded_count += 1
                    if task:
                        task.progress = int((downloaded_count / total_segments) * 90)
                        task.message = f"下载中: {downloaded_count}/{total_segments}"
            
            if task and task.stop_event.is_set(): return None
            
            if downloaded_count < total_segments:
                self.log(f"❌ 下载不完整: {downloaded_count}/{total_segments}")
                return None
                
            if task: task.message = "正在合并文件..."
            
            try:
                with open(output_path, 'wb') as outfile:
                    for i in range(total_segments):
                        segment_path = os.path.join(temp_dir, f"segment_{i:04d}.ts")
                        if not os.path.exists(segment_path): continue
                        with open(segment_path, 'rb') as infile:
                            outfile.write(infile.read())
            except Exception as e:
                self.log(f"合并失败: {e}")
                return None
            
            try: shutil.rmtree(temp_dir, ignore_errors=True)
            except: pass
            
            self.download_history[history_key(anime_name, episode_name)] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            
            if task: task.progress = 100
            return output_path
            
        except Exception as e:
            self.log(f"M3U8下载失败: {e}")
            return None

    def _download_direct_internal(self, video_url, anime_name, episode_name, task=None):
        scheme = getattr(self, "naming_scheme", "simple")
        default_season = int(getattr(self, "default_season_number", 1) or 1)
        output_path, normalized_episode = build_download_path(
            self.download_folder, anime_name, episode_name,
            scheme=scheme, ext="mp4", default_season=default_season
        )
        ensure_parent_dir(output_path)
        temp_file = output_path + ".tmp"
        
        if self.is_downloaded(anime_name, normalized_episode):
            if task: task.progress = 100
            return output_path
            
        if os.path.exists(output_path):
            if task: task.progress = 100
            return output_path
            
        try:
            # Use session!
            head_resp = self.session.head(video_url, timeout=10)
            total_size = int(head_resp.headers.get('Content-Length', 0))
            
            # If server supports range and we have size, use multi-thread
            accept_ranges = head_resp.headers.get('Accept-Ranges', 'none')
            
            if total_size > 0 and accept_ranges == 'bytes':
                if task:
                    task.total = total_size
                    task.message = f"开始加速下载 (大小: {total_size/1024/1024:.2f}MB)"
                
                num_threads = self.max_threads
                chunk_size = total_size // num_threads
                ranges = []
                for i in range(num_threads):
                    start = i * chunk_size
                    end = (i + 1) * chunk_size - 1 if i < num_threads - 1 else total_size - 1
                    ranges.append((start, end))
                    
                with open(temp_file, 'wb') as f:
                    f.seek(total_size - 1)
                    f.write(b'\0')
                    
                downloaded_bytes = 0
                lock = threading.Lock()
                
                def download_chunk(start, end):
                    nonlocal downloaded_bytes
                    headers = self.headers.copy()
                    headers['Range'] = f'bytes={start}-{end}'
                    # Important: Use session or copy cookies
                    # Since we are in threads, we should be careful with session if it's not thread-safe for cookies?
                    # requests.Session is thread-safe for connection pooling, but cookies?
                    # Generally yes.
                    
                    try:
                        resp = self.session.get(video_url, headers=headers, stream=True, timeout=30)
                        resp.raise_for_status()
                        
                        with open(temp_file, 'r+b') as f:
                            f.seek(start)
                            for chunk in resp.iter_content(chunk_size=8192):
                                if task and task.stop_event.is_set(): return False
                                if task: task.pause_event.wait()
                                
                                if chunk:
                                    f.write(chunk)
                                    with lock:
                                        downloaded_bytes += len(chunk)
                                        if task:
                                            task.update_bytes(len(chunk))
                                            task.progress = int((downloaded_bytes / total_size) * 100)
                        return True
                    except Exception as e:
                        return False

                with ThreadPoolExecutor(max_workers=num_threads) as executor:
                    futures = [executor.submit(download_chunk, s, e) for s, e in ranges]
                    results = [f.result() for f in as_completed(futures)]
                    
                if not all(results) or (task and task.stop_event.is_set()):
                    if os.path.exists(temp_file): os.remove(temp_file)
                    return None
                    
                os.rename(temp_file, output_path)
                
                self.download_history[f"{anime_name}||{episode_name}"] = {
                    "path": output_path,
                    "time": time.strftime("%Y-%m-%d %H:%M:%S")
                }
                self.save_download_history()
                
                if task: task.progress = 100
                return output_path
            
            else:
                # Fallback to single thread
                return self._download_single_stream(video_url, output_path, task)
                
        except Exception as e:
            self.log(f"下载失败: {e}")
            if os.path.exists(temp_file): os.remove(temp_file)
            return None

    def _download_single_stream(self, video_url, output_path, task):
        try:
            # Use session!
            resp = self.session.get(video_url, stream=True, timeout=30)
            
            total_size = int(resp.headers.get('content-length', 0))
            if task: task.total = total_size
            
            downloaded = 0
            
            with open(output_path, 'wb') as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    if task and task.stop_event.is_set():
                        break
                        
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if task: 
                            task.update_bytes(len(chunk))
                            if total_size > 0:
                                task.progress = int((downloaded / total_size) * 100)
            
            if task and task.stop_event.is_set():
                if os.path.exists(output_path): os.remove(output_path)
                return None
                
            self.download_history[f"{task.anime_name}||{task.episode_name}"] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            return output_path
        except Exception as e:
            self.log(f"单线程下载失败: {e}")
            return None
