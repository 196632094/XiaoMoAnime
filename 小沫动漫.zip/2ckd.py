import sys
import re
import requests
from urllib.parse import urljoin, quote
from bs4 import BeautifulSoup

# 禁用SSL警告（某些环境下可能需要）
import warnings
warnings.filterwarnings('ignore')

BASE_URL = 'https://www.2rk.cc'
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

def search_anime(query):
    """搜索动漫，返回结果列表[(title, detail_url)]"""
    url = f'{BASE_URL}/search?w={quote(query)}'
    try:
        resp = requests.get(url, headers=HEADERS, timeout=10)
        resp.raise_for_status()
    except Exception as e:
        print(f'搜索失败: {e}')
        return []
    
    soup = BeautifulSoup(resp.text, 'html.parser')
    results = []
    # 搜索结果的每个条目都有 class="z"
    for article in soup.find_all('article', class_='z'):
        link = article.find('a', href=True)
        if link:
            title = link.get('title') or link.get_text(strip=True)
            detail_url = urljoin(BASE_URL, link['href'])
            results.append((title, detail_url))
    return results

def get_episodes(detail_url):
    """获取动漫的剧集列表，返回[(ep_num, ep_title, ep_url)], anime_id"""
    try:
        resp = requests.get(detail_url, headers=HEADERS, timeout=10)
        resp.raise_for_status()
    except Exception as e:
        print(f'获取详情失败: {e}')
        return [], None
    
    soup = BeautifulSoup(resp.text, 'html.parser')
    
    # 提取 animeId 从页面中的 pageData 对象
    anime_id = None
    script_text = soup.find('script', string=re.compile(r'pageData'))
    if script_text:
        match = re.search(r'animeId["\']:\s*["\']([^"\']+)', script_text.string)
        if match:
            anime_id = match.group(1)
    
    # 如果无法从 pageData 提取，则从 URL 中提取 anime_id
    if not anime_id:
        # 类似 /detail/guimiezhirenzxunlian?id=1 的 URL
        path = requests.utils.urlparse(detail_url).path
        anime_id = path.split('/')[-1] if path else None
    
    # 提取剧集列表
    episodes = []
    ep_list = soup.find('article', class_='af')
    if ep_list:
        for li in ep_list.find_all('li'):
            a = li.find('a', href=True)
            if a:
                ep_url = urljoin(BASE_URL, a['href'])
                ep_title = a.get('title') or a.get_text(strip=True)
                # 从 URL 中提取剧集编号，例如 ?id=2
                ep_num = None
                match = re.search(r'\?id=(\d+)', ep_url)
                if match:
                    ep_num = int(match.group(1))
                episodes.append((ep_num, ep_title, ep_url))
    
    # 按剧集编号排序
    episodes.sort(key=lambda x: x[0] if x[0] is not None else 0)
    return episodes, anime_id

def get_video_url(episode_url):
    """从剧集页面提取视频地址（HLS m3u8）"""
    try:
        resp = requests.get(episode_url, headers=HEADERS, timeout=10)
        resp.raise_for_status()
    except Exception as e:
        print(f'获取剧集页面失败: {e}')
        return None
    
    # 使用正则表达式查找 loadSource 调用
    pattern = r'loadSource\("([^"]+)"\)'
    match = re.search(pattern, resp.text)
    if match:
        return match.group(1)
    
    # 备用模式：查找 .m3u8 链接
    m3u8_pattern = r'https?://[^"\']+\.m3u8[^"\']*'
    matches = re.findall(m3u8_pattern, resp.text)
    if matches:
        return matches[0]
    
    return None

def interactive_mode():
    """完全交互模式"""
    print("=== 2rk.cc 动漫搜索工具 ===")
    print("(输入 q 随时退出程序)\n")
    
    # 1. 输入搜索关键词
    while True:
        query = input("请输入要搜索的动漫名称: ").strip()
        if query.lower() == 'q':
            print("退出程序")
            return
        if query:
            break
        print("搜索关键词不能为空")
    
    print(f"\n正在搜索: {query}")
    results = search_anime(query)
    
    if not results:
        print("未找到相关动漫")
        return
    
    print(f"\n找到 {len(results)} 个结果:")
    for i, (title, url) in enumerate(results, 1):
        print(f"  {i}. {title}")
    
    # 2. 选择动漫
    selected_idx = 0
    if len(results) > 1:
        while True:
            choice = input(f"\n请选择动漫编号 (1-{len(results)}): ").strip()
            if choice.lower() == 'q':
                print("退出程序")
                return
            try:
                selected_idx = int(choice) - 1
                if 0 <= selected_idx < len(results):
                    break
                else:
                    print(f"编号无效，请输入 1-{len(results)} 之间的数字")
            except ValueError:
                print("请输入数字")
    else:
        print("只有一个结果，自动选择")
    
    selected_title, selected_url = results[selected_idx]
    print(f"\n已选择: {selected_title}")
    
    # 3. 获取剧集列表
    print("正在获取剧集信息...")
    episodes, anime_id = get_episodes(selected_url)
    
    if not episodes:
        print("未找到剧集列表")
        return
    
    print(f"\n共找到 {len(episodes)} 个剧集:")
    for ep_num, ep_title, ep_url in episodes:
        print(f"  第{ep_num}话: {ep_title}")
    
    # 4. 选择剧集
    while True:
        print("\n选择剧集:")
        print("  a - 获取所有剧集")
        print("  1,2,3... - 获取指定剧集")
        ep_choice = input("请选择: ").strip()
        
        if ep_choice.lower() == 'q':
            print("退出程序")
            return
        elif ep_choice.lower() == 'a':
            episodes_to_fetch = episodes
            break
        else:
            try:
                ep_num = int(ep_choice)
                target_episode = None
                for ep_num2, ep_title, ep_url in episodes:
                    if ep_num2 == ep_num:
                        target_episode = (ep_num2, ep_title, ep_url)
                        break
                if target_episode:
                    episodes_to_fetch = [target_episode]
                    break
                else:
                    print(f"剧集编号无效，请输入 1-{len(episodes)} 之间的数字")
            except ValueError:
                print("请输入数字或 'a'")
    
    # 5. 提取视频地址
    print("\n正在提取视频地址...")
    for ep_num, ep_title, ep_url in episodes_to_fetch:
        video_url = get_video_url(ep_url)
        if video_url:
            print(f"\n=== 第{ep_num}话 - {ep_title} ===")
            print(f"视频地址: {video_url}")
            # 同时提供不带哈希的通用格式（可能可用）
            if anime_id and re.search(r'/\d+/[a-f0-9]+\.m3u8', video_url):
                generic_url = f'{BASE_URL}/video/{anime_id}/{ep_num}/'
                print(f"通用格式: {generic_url}(哈希).m3u8")
            print()
        else:
            print(f"第{ep_num}话: 无法提取视频地址")
    
    print("\n=== 完成 ===")
    print("视频地址为 HLS (.m3u8) 格式，可使用支持 HLS 的播放器播放")
    print("例如: VLC, MPV, PotPlayer 等")

def main():
    # 处理命令行参数
    if len(sys.argv) == 1:
        # 完全交互模式
        interactive_mode()
    elif len(sys.argv) == 2:
        # 快捷搜索模式: python3 2rk_search.py "动漫名称"
        query = sys.argv[1]
        print(f'搜索动漫: {query}')
        
        results = search_anime(query)
        if not results:
            print('未找到相关动漫')
            sys.exit(1)
        
        print('找到以下动漫:')
        for i, (title, url) in enumerate(results, 1):
            print(f'  {i}. {title}')
        
        # 交互式选择动漫
        while True:
            try:
                choice = input('请选择动漫编号 (输入 q 退出): ').strip()
                if choice.lower() == 'q':
                    sys.exit(0)
                selected_idx = int(choice) - 1
                if 0 <= selected_idx < len(results):
                    break
                else:
                    print('编号无效，请重新输入')
            except ValueError:
                print('请输入数字')
        
        selected_title, selected_url = results[selected_idx]
        print(f'已选择: {selected_title}')
        
        # 获取剧集列表
        episodes, anime_id = get_episodes(selected_url)
        if not episodes:
            print('未找到剧集列表')
            sys.exit(1)
        
        print(f'共找到 {len(episodes)} 个剧集:')
        for ep_num, ep_title, ep_url in episodes:
            print(f'  第{ep_num}话: {ep_title}')
        
        # 交互式选择剧集
        while True:
            try:
                ep_choice = input('请输入要获取视频地址的剧集编号 (输入 a 获取全部，输入 q 退出): ').strip()
                if ep_choice.lower() == 'q':
                    sys.exit(0)
                if ep_choice.lower() == 'a':
                    episodes_to_fetch = episodes
                    break
                else:
                    ep_num = int(ep_choice)
                    target_episode = None
                    for ep_num2, ep_title, ep_url in episodes:
                        if ep_num2 == ep_num:
                            target_episode = (ep_num2, ep_title, ep_url)
                            break
                    if target_episode:
                        episodes_to_fetch = [target_episode]
                        break
                    else:
                        print('剧集编号无效，请重新输入')
            except ValueError:
                print('请输入数字或 a/q')
        
        # 获取视频地址
        print('正在提取视频地址...')
        for ep_num, ep_title, ep_url in episodes_to_fetch:
            video_url = get_video_url(ep_url)
            if video_url:
                print(f'\n第{ep_num}话 - {ep_title}:')
                print(f'  视频地址: {video_url}')
                if anime_id and re.search(r'/\d+/[a-f0-9]+\.m3u8', video_url):
                    generic_url = f'{BASE_URL}/video/{anime_id}/{ep_num}/'
                    print(f'  通用格式: {generic_url}(哈希).m3u8')
            else:
                print(f'\n第{ep_num}话: 无法提取视频地址')
    
    elif len(sys.argv) >= 3:
        # 直接获取模式: python3 2rk_search.py "动漫名称" 剧集编号
        query = sys.argv[1]
        try:
            target_ep_num = int(sys.argv[2])
        except ValueError:
            print('错误：剧集编号必须是数字')
            sys.exit(1)
        
        print(f'搜索动漫: {query}')
        results = search_anime(query)
        if not results:
            print('未找到相关动漫')
            sys.exit(1)
        
        # 自动选择第一个结果
        selected_title, selected_url = results[0]
        print(f'已选择: {selected_title}')
        
        # 获取剧集列表
        episodes, anime_id = get_episodes(selected_url)
        if not episodes:
            print('未找到剧集列表')
            sys.exit(1)
        
        # 查找对应剧集编号
        target_episode = None
        for ep_num, ep_title, ep_url in episodes:
            if ep_num == target_ep_num:
                target_episode = (ep_num, ep_title, ep_url)
                break
        
        if not target_episode:
            print(f'错误：未找到第 {target_ep_num} 话')
            sys.exit(1)
        
        # 获取视频地址
        print('正在提取视频地址...')
        video_url = get_video_url(target_episode[2])
        if video_url:
            print(f'\n第{target_ep_num}话 - {target_episode[1]}:')
            print(f'  视频地址: {video_url}')
            if anime_id and re.search(r'/\d+/[a-f0-9]+\.m3u8', video_url):
                generic_url = f'{BASE_URL}/video/{anime_id}/{target_ep_num}/'
                print(f'  通用格式: {generic_url}(哈希).m3u8')
        else:
            print(f'\n第{target_ep_num}话: 无法提取视频地址')
    
    else:
        print(__doc__)

if __name__ == '__main__':
    main()