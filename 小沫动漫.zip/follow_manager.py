import json
import os
import requests
import time

class FollowManager:
    def __init__(self, data_file="follow_list.json"):
        self.data_file = data_file
        self.follows = []
        self.load_data()

    def load_data(self):
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    self.follows = json.load(f)
            except Exception as e:
                print(f"Failed to load follow list: {e}")
                self.follows = []

    def save_data(self):
        try:
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(self.follows, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"Failed to save follow list: {e}")

    def get_all(self):
        # Return list sorted by added time? Or just list.
        # Let's return reversed list so newest is top if we append
        return self.follows

    def add_anime(self, name):
        name = name.strip()
        if not name: return False
        
        # Check duplicates
        for item in self.follows:
            if item['name'] == name:
                return False
        
        self.follows.append({
            'name': name,
            'added_at': time.time()
        })
        self.save_data()
        return True

    def remove_anime(self, name):
        initial_len = len(self.follows)
        self.follows = [x for x in self.follows if x['name'] != name]
        if len(self.follows) < initial_len:
            self.save_data()
            return True
        return False

    def update_anime(self, old_name, new_name):
        new_name = new_name.strip()
        if not new_name: return False
        
        # Check if new name exists (prevent duplicates)
        for item in self.follows:
            if item['name'] == new_name and new_name != old_name:
                return False

        for item in self.follows:
            if item['name'] == old_name:
                item['name'] = new_name
                self.save_data()
                return True
        return False

    def fetch_remote_list(self, list_type="yuri"):
        urls = {
            "yuri": "https://xxla.iepose.cn/FTP/%E6%95%B0%E6%8D%AE%20@vol1/%E7%95%AA%E5%89%A7/%E7%99%BE%E5%90%88.txt",
            "all": "https://xxla.iepose.cn/FTP/%E6%95%B0%E6%8D%AE%20@vol1/%E7%95%AA%E5%89%A7/%E5%85%A8%E9%83%A8.txt",
            "recommend": "https://xxla.iepose.cn/FTP/%E6%95%B0%E6%8D%AE%20@vol1/%E7%95%AA%E5%89%A7/%E6%8E%A8%E8%8D%90.txt",
            "romance": "https://xxla.iepose.cn/FTP/%E6%95%B0%E6%8D%AE%20@vol1/%E7%95%AA%E5%89%A7/%E6%81%8B%E7%88%B1.txt"
        }
        
        url = urls.get(list_type)
        if not url:
            print(f"Unknown list type: {list_type}")
            return []

        try:
            # Add headers to mimic browser just in case
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            resp = requests.get(url, timeout=15, headers=headers)
            # Try to detect encoding or default to utf-8
            resp.encoding = 'utf-8' 
            
            if resp.status_code == 200:
                content = resp.text
                lines = [line.strip() for line in content.splitlines() if line.strip()]
                # Deduplicate while preserving order
                seen = set()
                unique_lines = []
                for line in lines:
                    if line not in seen:
                        unique_lines.append(line)
                        seen.add(line)
                return unique_lines
            else:
                print(f"Fetch failed with status: {resp.status_code}")
        except Exception as e:
            print(f"Failed to fetch {list_type} list: {e}")
        return []

    def fetch_yuri_list(self):
        return self.fetch_remote_list("yuri")

    def import_remote_list(self, list_type="yuri"):
        lines = self.fetch_remote_list(list_type)
        if not lines:
            return 0
            
        count = 0
        for name in lines:
            if self.add_anime(name):
                count += 1
        return count

    def import_yuri_list(self):
        return self.import_remote_list("yuri")
