import requests
import re
import json
import os
import time
import threading
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed
import m3u8
import shutil
from Crypto.Cipher import AES

class OmoFunSource:
    def __init__(self, log_callback=None, progress_callback=None):
        self.base_url = "https://omofun.icu"
        self.search_url = "https://omofun.icu/vod/search.html?wd={keyword}"
        
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": self.base_url,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Connection": "keep-alive"
        }
        
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
        self.log_callback = log_callback
        self.progress_callback = progress_callback
        
        self.download_folder = "downloads"
        self.log_folder = "logs"
        self.max_threads = 10 # Default
        self.download_history_file = os.path.join(self.log_folder, "download_history.json")
        
        if not os.path.exists(self.download_folder):
            os.makedirs(self.download_folder)
        if not os.path.exists(self.log_folder):
            os.makedirs(self.log_folder)
            
        self.download_history = self.load_download_history()

    def log(self, message):
        print(message)
        if self.log_callback:
            self.log_callback(message)

    def load_download_history(self):
        if os.path.exists(self.download_history_file):
            try:
                with open(self.download_history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
        
    def save_download_history(self):
        with open(self.download_history_file, 'w', encoding='utf-8') as f:
            json.dump(self.download_history, f, ensure_ascii=False, indent=2)

    def is_downloaded(self, anime_name, episode_name):
        key = f"{anime_name}||{episode_name}"
        if key not in self.download_history:
            return False
            
        record = self.download_history[key]
        if os.path.exists(record['path']):
            return True
            
        # File doesn't exist, remove from history
        del self.download_history[key]
        self.save_download_history()
        return False

    def search_anime(self, keyword):
        """搜索番剧"""
        self.log(f"正在搜索: {keyword}")
        url = self.search_url.format(keyword=keyword)
        
        try:
            response = self.session.get(url, timeout=10)
            response.encoding = 'utf-8'
            soup = BeautifulSoup(response.text, 'html.parser')
            
            animes = []
            anime_items = soup.select('.module-poster-item, .module-card-item')
            
            for item in anime_items:
                title_elem = item.select_one('.module-poster-item-title, .module-card-item-title a')
                if title_elem:
                    title = title_elem.get_text(strip=True)
                    href = title_elem.get('href') if title_elem.name == 'a' else item.get('href')
                    
                    if href:
                        full_url = urljoin(self.base_url, href)
                        
                        # Get cover if available
                        img = item.select_one('img')
                        cover = img.get('data-original') if img else ''
                        
                        animes.append({
                            'name': title,
                            'url': full_url,
                            'source': 'omofun',
                            'cover': cover
                        })
            
            return animes
        except Exception as e:
            self.log(f"搜索失败: {e}")
            return []

    def get_episodes(self, anime_url):
        """获取番剧详情及剧集"""
        try:
            self.log(f"获取剧集列表: {anime_url}")
            response = self.session.get(anime_url, timeout=10)
            response.encoding = 'utf-8'
            soup = BeautifulSoup(response.text, 'html.parser')
            
            channel_tabs = soup.select('.module-tab-item.tab-item')
            episode_areas = soup.select('.module-play-list-content.module-play-list-base')
            
            if not episode_areas:
                self.log("未找到剧集区域")
                return []
            
            # Parse all sources
            sources = []
            all_episodes = [] # Default flattened list for compatibility
            
            for i, area in enumerate(episode_areas):
                source_name = "默认线路"
                if i < len(channel_tabs):
                    source_name = channel_tabs[i].get('data-dropdown-value', channel_tabs[i].get_text(strip=True))
                
                source_episodes = []
                episode_links = area.select('a.module-play-list-link')
                
                for link in episode_links:
                    episode_title = link.get_text(strip=True)
                    episode_url = link.get('href')
                    
                    if episode_url:
                        full_url = urljoin(self.base_url, episode_url)
                        
                        ep_match = re.search(r'第\s*(\d+)\s*[话集]', episode_title)
                        ep_num = int(ep_match.group(1)) if ep_match else episode_title
                        
                        ep_data = {
                            'name': episode_title,
                            'original_name': episode_title,
                            'url': full_url,
                            'episode': ep_num,
                            'source_name': source_name # Track which source this belongs to
                        }
                        source_episodes.append(ep_data)
                
                if source_episodes:
                    sources.append({
                        'name': source_name,
                        'episodes': source_episodes
                    })
                    # Add to flattened list only if it's the first source (default)
                    if i == 0:
                        all_episodes = source_episodes

            # Return a structure that contains both flattened list (for backward compat) AND sources info
            # Since app.py expects a list or dict, let's return a dict if we want to support sources
            return {
                'episodes': all_episodes, # Default source episodes
                'sources': sources
            }

        except Exception as e:
            self.log(f"获取详情失败: {e}")
            return []

    def get_video_url(self, episode_url):
        """获取视频地址"""
        try:
            headers = self.headers.copy()
            headers['Referer'] = episode_url
            
            self.log(f"正在解析: {episode_url}")
            response = self.session.get(episode_url, headers=headers, timeout=10)
            response.encoding = 'utf-8'
            
            # 提取player_aaaa对象
            player_match = re.search(r'var\s+player_aaaa\s*=\s*({.*?})\s*;', response.text, re.DOTALL)
            if player_match:
                player_data = player_match.group(1)
                
                # 解析player数据
                # 直接提取URL字段
                url_match = re.search(r'"url"\s*:\s*"([^"]+)"', player_data)
                if url_match:
                    video_url = url_match.group(1)
                    # 清理URL中的反斜杠
                    clean_url = video_url.replace('\\/', '/')
                    self.log(f"✅ 解析成功: {clean_url}")
                    return clean_url
            
            self.log("❌ 未找到有效的视频地址")
            return None
            
        except Exception as e:
            self.log(f"❌ 获取视频地址失败: {e}")
            return None

    def _get_decryption_key(self, m3u8_obj):
        if not m3u8_obj.keys or not m3u8_obj.keys[0]: return None
        key_uri = m3u8_obj.keys[0].uri
        if not key_uri: return None
        try:
            key_url = urljoin(m3u8_obj.base_uri, key_uri)
            return self.session.get(key_url).content
        except: return None

    def _download_content(self, url):
        try:
            return self.session.get(url, timeout=10).text
        except: return None

    def download_m3u8_with_task_control(self, video_url, anime_name, episode_name, task=None):
        """
        下载视频文件 - 支持任务控制
        自动检测是M3U8还是直接文件
        """
        # Check if M3U8
        is_m3u8 = '.m3u8' in video_url or 'application/vnd.apple.mpegurl' in video_url
        if not is_m3u8:
            # Try HEAD request to check content type
            try:
                head_resp = self.session.head(video_url, timeout=5)
                if 'mpegurl' in head_resp.headers.get('Content-Type', ''):
                    is_m3u8 = True
            except: pass

        if is_m3u8:
            return self._download_m3u8_internal(video_url, anime_name, episode_name, task)
        else:
            return self._download_direct_internal(video_url, anime_name, episode_name, task)

    def _download_m3u8_internal(self, m3u8_url, anime_name, episode_name, task=None):
        anime_folder = os.path.join(self.download_folder, re.sub(r'[\\/*?:"<>|]', '', anime_name))
        os.makedirs(anime_folder, exist_ok=True)
        
        safe_episode_name = re.sub(r'[\\/*?:"<>|]', '', episode_name)
        output_path = os.path.join(anime_folder, f"{safe_episode_name}.mp4")
        
        if self.is_downloaded(anime_name, episode_name):
            if task: task.progress = 100
            return output_path
            
        if os.path.exists(output_path):
            if task: task.progress = 100
            return output_path
        
        try:
            self.log(f"正在获取m3u8播放列表: {m3u8_url}")
            base_uri = os.path.dirname(m3u8_url) + '/'
            content = self._download_content(m3u8_url)
            if not content: return None
            
            m3u8_obj = m3u8.loads(content, uri=base_uri)
            
            # Handle master playlist
            if m3u8_obj.playlists:
                playlist = m3u8_obj.playlists[0]
                m3u8_url = urljoin(base_uri, playlist.uri)
                base_uri = os.path.dirname(m3u8_url) + '/'
                content = self._download_content(m3u8_url)
                if not content: return None
                m3u8_obj = m3u8.loads(content, uri=base_uri)
            
            segments = m3u8_obj.segments
            if not segments:
                self.log(f"❌ 无法获取视频分片列表")
                return None
            
            key = self._get_decryption_key(m3u8_obj)
            
            safe_anime_name = re.sub(r'[\\/*?:"<>|\s]', '_', anime_name)
            safe_episode = re.sub(r'[\\/*?:"<>|\s]', '_', safe_episode_name)
            temp_dir = os.path.join(self.download_folder, "temp", f"{safe_anime_name}_{safe_episode}")
            os.makedirs(temp_dir, exist_ok=True)
            
            total_segments = len(segments)
            if task:
                task.total = total_segments
                task.message = f"开始下载 {total_segments} 个分片 (m3u8)"
            
            def download_segment(segment, index):
                if task:
                    task.pause_event.wait()
                    if task.stop_event.is_set(): return False
                
                segment_url = urljoin(base_uri, segment.uri)
                segment_path = os.path.join(temp_dir, f"segment_{index:04d}.ts")
                
                if os.path.exists(segment_path) and os.path.getsize(segment_path) > 1024:
                    return True
                
                for attempt in range(5):
                    if task and task.stop_event.is_set(): return False
                    try:
                        content = self.session.get(segment_url, timeout=30).content
                        if key:
                            iv = bytes([index % 256] * 16)
                            cipher = AES.new(key, AES.MODE_CBC, iv=iv)
                            content = cipher.decrypt(content)
                        
                        with open(segment_path, 'wb') as f:
                            f.write(content)
                            if task: task.update_bytes(len(content))
                        return True
                    except Exception as e:
                        time.sleep(1)
                return False

            downloaded_count = 0
            with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
                futures = {executor.submit(download_segment, segment, i): i for i, segment in enumerate(segments)}
                for future in as_completed(futures):
                    if task and task.stop_event.is_set(): break
                    if future.result():
                        downloaded_count += 1
                    if task:
                        task.progress = int((downloaded_count / total_segments) * 90)
                        task.message = f"下载中: {downloaded_count}/{total_segments}"
            
            if task and task.stop_event.is_set(): return None
            
            if downloaded_count < total_segments:
                self.log(f"❌ 下载不完整: {downloaded_count}/{total_segments}")
                return None
                
            # Merge
            if task: task.message = "正在合并文件..."
            
            try:
                with open(output_path, 'wb') as outfile:
                    for i in range(total_segments):
                        segment_path = os.path.join(temp_dir, f"segment_{i:04d}.ts")
                        if not os.path.exists(segment_path): continue
                        with open(segment_path, 'rb') as infile:
                            outfile.write(infile.read())
            except Exception as e:
                self.log(f"合并失败: {e}")
                return None
            
            try: shutil.rmtree(temp_dir, ignore_errors=True)
            except: pass
            
            self.download_history[f"{anime_name}||{episode_name}"] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            
            if task: task.progress = 100
            return output_path
            
        except Exception as e:
            self.log(f"M3U8下载失败: {e}")
            return None

    def _download_direct_internal(self, video_url, anime_name, episode_name, task=None):
        anime_folder = os.path.join(self.download_folder, re.sub(r'[\\/*?:"<>|]', '', anime_name))
        os.makedirs(anime_folder, exist_ok=True)
        
        safe_episode_name = re.sub(r'[\\/*?:"<>|]', '', episode_name)
        output_path = os.path.join(anime_folder, f"{safe_episode_name}.mp4")
        
        if self.is_downloaded(anime_name, episode_name):
            if task: task.progress = 100
            return output_path
            
        if os.path.exists(output_path):
            if task: task.progress = 100
            return output_path
        
        temp_path = output_path + ".download"
        
        try:
            self.log(f"开始直接下载视频到: {output_path}")
            
            headers = self.headers.copy()
            headers['Accept'] = '*/*'
            headers['Accept-Encoding'] = 'identity'
            
            resume_header = {}
            mode = 'wb'
            existing_size = 0
            
            if os.path.exists(temp_path):
                existing_size = os.path.getsize(temp_path)
                resume_header = {'Range': f'bytes={existing_size}-'}
                mode = 'ab'
            
            headers.update(resume_header)
            
            response = self.session.get(video_url, headers=headers, stream=True, timeout=30)
            
            # 403 Forbidden Retry Logic
            if response.status_code == 403:
                self.log("⚠️ 检测到403禁止访问，尝试移除Referer重试...")
                headers['Referer'] = ''
                response = self.session.get(video_url, headers=headers, stream=True, timeout=30)

            if response.status_code == 416:
                os.rename(temp_path, output_path)
                return output_path

            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            if total_size == 0: pass
            else: total_size += existing_size
            
            if task: 
                task.total = total_size
                task.message = f"正在下载: {anime_name} - {episode_name}"
            
            downloaded_size = existing_size
            
            with open(temp_path, mode) as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if task:
                        task.pause_event.wait()
                        if task.stop_event.is_set(): break
                    
                    if chunk:
                        f.write(chunk)
                        downloaded_size += len(chunk)
                        if task:
                            task.update_bytes(len(chunk))
                            if total_size > 0:
                                task.progress = int((downloaded_size / total_size) * 100)
            
            if task and task.stop_event.is_set():
                if os.path.exists(temp_path):
                    try: os.remove(temp_path)
                    except: pass
                return None
            
            os.rename(temp_path, output_path)
            
            self.download_history[f"{anime_name}||{episode_name}"] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            
            if task: task.progress = 100
            return output_path
            
        except Exception as e:
            self.log(f"直接下载失败: {e}")
            if task: task.message = f"下载出错: {str(e)}"
            return None

if __name__ == "__main__":
    source = OmoFunSource()
    res = source.search_anime("进击")
    print(res)
