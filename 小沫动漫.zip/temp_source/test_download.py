import m3u8
import requests

url = "https://ai.girigirilove.net/zijian/oldanime/2010/07/OniichanhaOshimai/01/playlist.m3u8"
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
    "Referer": "https://bgm.girigirilove.com"
}

try:
    print(f"Loading m3u8 from {url}")
    # m3u8.load can take a URL directly, but it might need headers? 
    # The m3u8 library's load function might not support custom headers easily if passed a URL string directly, 
    # it uses urllib or requests internally but customization varies.
    # Let's try fetching content first.
    
    response = requests.get(url, headers=headers)
    print(f"Response status: {response.status_code}")
    print(f"Response content length: {len(response.text)}")
    
    playlist = m3u8.loads(response.text)
    print("Playlist loaded successfully")
    print(f"Segments: {len(playlist.segments)}")
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
