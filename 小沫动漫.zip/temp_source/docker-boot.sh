#!/bin/bash
set -e

echo "=== BOOT START ==="
echo "Date: $(date)"

# 1. Config Mirrors
echo "Configuring mirrors..."
if [ -f /etc/apt/sources.list.d/debian.sources ]; then
    sed -i 's/deb.debian.org/mirrors.ustc.edu.cn/g' /etc/apt/sources.list.d/debian.sources
elif [ -f /etc/apt/sources.list ]; then
    sed -i 's/deb.debian.org/mirrors.ustc.edu.cn/g' /etc/apt/sources.list
fi
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple

# 2. Install System Deps
echo "Checking system dependencies..."
# Only install if ffmpeg is missing to save time on restart (if container persisted)
if ! command -v ffmpeg &> /dev/null; then
    echo "Installing ffmpeg, etc..."
    apt-get update
    apt-get install -y --no-install-recommends \
        ffmpeg \
        unzip \
        curl \
        git
else
    echo "System dependencies already installed."
fi

# 2.5 Download Source Code (moved from docker-compose)
if [ ! -z "$ZIP_URL" ]; then
    echo "Downloading source from $ZIP_URL..."
    if [ -f "source.zip" ]; then rm source.zip; fi
    curl -f -L -o source.zip "$ZIP_URL" || { echo 'Download failed'; exit 1; }
    unzip -o source.zip
    rm source.zip
fi

# 3. Handle Nested Directory (if zip extracted into subfolder)
if [ ! -f "app.py" ]; then
    echo "Searching for app.py..."
    SUB_DIR=$(find . -maxdepth 2 -name "app.py" -exec dirname {} \;)
    if [ ! -z "$SUB_DIR" ] && [ "$SUB_DIR" != "." ]; then
        echo "Found app in $SUB_DIR, moving to root..."
        cp -rf "$SUB_DIR"/* .
        rm -rf "$SUB_DIR"
    fi
fi

# 4. Install Python Deps
echo "Installing core python dependencies..."
pip install flask

if [ -f "requirements.txt" ]; then
    echo "Installing python requirements..."
    pip install -r requirements.txt
fi

# 5. Restore Configs (if volume mounted)
if [ -d /app/config ]; then
    echo "Restoring configs from volume..."
    for f in settings.json tasks.json shopping_cart.json; do
        if [ -f "/app/config/$f" ]; then
            cp "/app/config/$f" .
            echo "Restored $f"
        fi
    done
fi

# 6. Start App
echo "Starting application..."
mkdir -p logs
exec python -u app.py
