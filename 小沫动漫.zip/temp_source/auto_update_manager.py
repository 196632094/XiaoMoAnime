import json
import os
import time
import threading

class AutoUpdateManager:
    def __init__(self, file_path="auto_update_list.json"):
        self.file_path = file_path
        self.items = [] # List of {anime_name, url, last_checked, status, added_at}
        self.lock = threading.Lock()
        self.load()

    def load(self):
        if os.path.exists(self.file_path):
            try:
                with open(self.file_path, 'r', encoding='utf-8') as f:
                    self.items = json.load(f)
            except Exception as e:
                print(f"Failed to load auto update list: {e}")
                self.items = []

    def save(self):
        try:
            with open(self.file_path, 'w', encoding='utf-8') as f:
                json.dump(self.items, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Failed to save auto update list: {e}")

    def add_anime(self, anime_name, url, source='girigiri', status='waiting', update_info='', cover=''):
        with self.lock:
            for item in self.items:
                if item['anime_name'] == anime_name:
                    # Update existing info if provided
                    if status != 'waiting':
                        item['status'] = status
                    if update_info:
                        item['update_info'] = update_info
                    if cover:
                        item['cover'] = cover
                    self.save()
                    return False
            
            self.items.append({
                'anime_name': anime_name,
                'url': url,
                'last_checked': 0,
                'status': status, # waiting, checking, updated, completed, ongoing, not_aired
                'update_info': update_info,
                'cover': cover,
                'added_at': time.time(),
                'source': source
            })
            self.save()
            return True

    def remove_anime(self, anime_name):
        with self.lock:
            initial_len = len(self.items)
            self.items = [item for item in self.items if item['anime_name'] != anime_name]
            if len(self.items) < initial_len:
                self.save()
                return True
            return False

    def batch_remove_anime(self, anime_names):
        with self.lock:
            initial_len = len(self.items)
            self.items = [item for item in self.items if item['anime_name'] not in anime_names]
            if len(self.items) < initial_len:
                self.save()
                return True
            return False

    def get_all(self):
        with self.lock:
            return sorted(self.items, key=lambda x: x['added_at'], reverse=True)

    def update_item_status(self, anime_name, status, last_checked=None):
        with self.lock:
            for item in self.items:
                if item['anime_name'] == anime_name:
                    item['status'] = status
                    if last_checked:
                        item['last_checked'] = last_checked
                    self.save()
                    return True
            return False
