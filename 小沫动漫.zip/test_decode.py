import base64
import urllib.parse

encoded_url = "xpQbMByA7HWDJH6iUdcHMrg6rCt%2Be%2Faj4cNDcdFoheuuBqmS8fZ5ujqwOtUGuOo0xRQMm%2F1PRDr2b%2FwB89sSOQ%3D%3D"
decoded_url = urllib.parse.unquote(encoded_url)
print(f"URL Decoded: {decoded_url}")

try:
    b64_decoded = base64.b64decode(decoded_url).decode('utf-8')
    print(f"Base64 Decoded: {b64_decoded}")
except Exception as e:
    print(f"Base64 Decode Error: {e}")
    # Try ignoring errors or different encoding
    try:
        b64_decoded_bytes = base64.b64decode(decoded_url)
        print(f"Base64 Decoded Bytes: {b64_decoded_bytes}")
    except:
        pass
