import requests
import re
import os
import json
import time
import shutil
import subprocess
from bs4 import BeautifulSoup
from urllib.parse import urljoin, unquote, quote
from concurrent.futures import ThreadPoolExecutor, as_completed
import m3u8
import threading

class XifanSource:
    def __init__(self, log_callback=None, progress_callback=None):
        self.base_url = "https://dm.xifanacg.com"
        self.search_url = "https://dm.xifanacg.com/search.html?wd={}"
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Referer": self.base_url
        })
        
        self.log_callback = log_callback
        self.progress_callback = progress_callback
        
        self.download_folder = "downloads"
        self.log_folder = "logs"
        self.download_history_file = os.path.join(self.log_folder, "download_history.json")
        self.max_threads = 10
        
        if not os.path.exists(self.download_folder):
            os.makedirs(self.download_folder)
        if not os.path.exists(self.log_folder):
            os.makedirs(self.log_folder)
            
        self.download_history = self.load_download_history()

    def log(self, message):
        print(message)
        if self.log_callback:
            self.log_callback(message)

    def update_progress(self, current, total, desc=""):
        if self.progress_callback:
            self.progress_callback(current, total, desc)

    def load_download_history(self):
        if os.path.exists(self.download_history_file):
            try:
                with open(self.download_history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
        
    def save_download_history(self):
        with open(self.download_history_file, 'w', encoding='utf-8') as f:
            json.dump(self.download_history, f, ensure_ascii=False, indent=2)

    def is_downloaded(self, anime_name, episode_name):
        key = f"{anime_name}||{episode_name}"
        if key not in self.download_history:
            return False
        record = self.download_history[key]
        if 'path' in record and os.path.exists(record['path']):
            return True
        del self.download_history[key]
        self.save_download_history()
        return False

    def search_anime(self, keyword):
        """搜索番剧并返回结果列表"""
        try:
            self.log(f"正在搜索: {keyword}")
            response = self.session.get(self.search_url.format(keyword))
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            results = []
            items = soup.select('.search-list')
            if not items:
                items = soup.select('.public-list-box')

            for item in items:
                title = ""
                detail_path = ""
                
                # 获取标题
                img_elem = item.select_one('.detail-pic img, .public-list-exp img')
                if img_elem and 'alt' in img_elem.attrs:
                    title = img_elem['alt'].strip()
                    title = re.sub(r'封面图$', '', title).strip()
                
                if not title:
                    title_elem = item.select_one('.slide-info-title, .thumb-txt')
                    if title_elem:
                        title = title_elem.text.strip()
                
                if not title:
                    continue
                
                # 获取详情页链接
                link_elem = item.select_one('.detail-info > a, .public-list-exp')
                if link_elem and link_elem.get('href'):
                    detail_path = link_elem['href']
                else:
                    links = item.select('a[href*="/bangumi/"]')
                    if links:
                        detail_path = links[0]['href']
                
                if not detail_path:
                    continue
                
                # 获取图片URL
                cover_url = ""
                # Try multiple selectors for image
                img_elem = item.select_one('.detail-pic img, .public-list-exp img, .thumb img, .picture img, img.lazy')
                
                # If still not found, try any image
                if not img_elem:
                    img_elem = item.select_one('img')

                if img_elem:
                    # Try various lazy load attributes
                    if img_elem.get('data-src'):
                        cover_url = img_elem['data-src']
                    elif img_elem.get('data-original'):
                        cover_url = img_elem['data-original']
                    elif img_elem.get('src'):
                        cover_url = img_elem['src']
                
                # Ensure cover URL is absolute
                if cover_url and not cover_url.startswith('http'):
                    cover_url = urljoin(self.base_url, cover_url)
                
                # Extract status and update info
                status = "unknown"
                update_info = ""
                
                # 1. Try overlay (usually "更新至XX" or "已完结")
                overlay = item.select_one('.public-list-prb, .pic-text, .remarks')
                if overlay:
                    overlay_text = overlay.text.strip()
                    # User case: "预计1.11开播"
                    if "完结" in overlay_text:
                        status = "completed"
                        update_info = "已完结"
                    elif "更新" in overlay_text or "|" in overlay_text: # Handle "07|周五15:30"
                        status = "ongoing"
                        update_info = overlay_text
                    elif "预告" in overlay_text or "未播" in overlay_text or "开播" in overlay_text:
                        status = "not_aired"
                        update_info = overlay_text
                    elif "播放" in overlay_text: # User case: "5297播放" -> Completed
                        status = "completed"
                        update_info = "已完结"

                # 2. Try to find date info in description or subtitle
                # Some templates put date in .public-list-subtitle or .detail-content
                desc_elem = item.select_one('.slide-info-remarks, .detail-content, .public-list-subtitle')
                if desc_elem:
                    desc_text = desc_elem.text.strip()
                    # Check for date patterns like "202x-xx-xx" or "周x更新"
                    if not update_info:
                        if "更新" in desc_text or "周" in desc_text:
                            update_info = desc_text
                            status = "ongoing"
                        elif "播放" in desc_text:
                            status = "completed"
                            update_info = "已完结"
                    
                    # If status is not aired or still unknown, look for specific date
                    # User case: "2026年1月", "2025年10月"
                    if status in ["unknown", "not_aired"] and "202" in desc_text:
                         match = re.search(r'(202\d[年\.\-]\d{1,2}([月\.\-]\d{1,2})?)', desc_text)
                         if match:
                             date_str = match.group(0)
                             # If date is in future, it's not aired. If simple year, might be old.
                             # But user specifically mentioned "2026年1月" and "预计1.11开播"
                             if "开播" in overlay_text if overlay else False:
                                 pass # Already set
                             else:
                                 # Simple heuristic: if it has specific future date
                                 update_info = "开播: " + date_str
                                 # If we didn't detect "ongoing" or "completed" yet, assume not aired if date is 2025/2026
                                 if "2025" in date_str or "2026" in date_str:
                                     # Check if it looks like a full date 2025-10
                                     status = "not_aired"

                # Final check for specific user cases that might have been missed
                if overlay:
                    overlay_text = overlay.text.strip()
                    if "预计" in overlay_text and "开播" in overlay_text:
                        status = "not_aired"
                        update_info = overlay_text
                    if re.search(r'\d+\|', overlay_text): # "07|周五..."
                        status = "ongoing"
                        update_info = overlay_text
                
                # Check desc_text again if status is still unknown
                if status == "unknown" and desc_elem:
                    desc_text = desc_elem.text.strip()
                    if "预计" in desc_text and "开播" in desc_text:
                        status = "not_aired"
                        update_info = desc_text

                # Additional check: if update_info contains "预计" or "202x", prioritize not_aired
                if update_info and ("预计" in update_info or ("202" in update_info and status == "unknown")):
                     # Check if year is >= 2025
                     if "2025" in update_info or "2026" in update_info or "2027" in update_info:
                         status = "not_aired"

                results.append({
                    "name": title,
                    "url": urljoin(self.base_url, detail_path),
                    "cover": cover_url,
                    "source": "xifan",
                    "status": status,
                    "update_info": update_info
                })
            
            return results
            
        except Exception as e:
            self.log(f"搜索失败: {e}")
            return []

    def get_episodes(self, anime_url):
        """获取番剧的线路和剧集"""
        try:
            response = self.session.get(anime_url)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 解析线路
            lines = []
            for i, tab in enumerate(soup.select('.anthology-tab .swiper-slide')):
                line_name = tab.text.strip()
                lines.append({
                    "id": i,
                    "name": line_name,
                    "episodes": []
                })
            
            # 如果没有找到线路tab，可能只有默认线路
            if not lines:
                lines.append({"id": 0, "name": "默认线路", "episodes": []})

            # 解析剧集
            containers = soup.select('.anthology-list-box')
            for i, container in enumerate(containers):
                if i >= len(lines):
                    break
                
                current_line = lines[i]
                for ep in container.select('.anthology-list-play a'):
                    ep_url = urljoin(self.base_url, ep['href'])
                    ep_name = ep.text.strip()
                    current_line["episodes"].append({
                        "name": ep_name,
                        "original_name": ep_name,
                        "url": ep_url
                    })

            # 优先选择 "默认" 或 "高清" 线路，或者第一个有剧集的线路
            selected_line = None
            for line in lines:
                if "默认" in line['name'] and line['episodes']:
                    selected_line = line
                    break
            
            if not selected_line:
                for line in lines:
                    if line['episodes']:
                        selected_line = line
                        break
            
            if selected_line:
                self.log(f"已选择线路: {selected_line['name']}")
                return selected_line['episodes']
            
            return []
            
        except Exception as e:
            self.log(f"获取剧集失败: {e}")
            return []

    def _clean_url(self, url):
        if not url: return None
        # Handle JSON escaped slashes
        url = url.replace('\\/', '/')
        # Handle double backslashes
        url = url.replace('\\\\', '/')
        # Ensure scheme
        url = re.sub(r'^(https?:)/+', r'\1//', url)
        return url.strip()

    def get_video_url(self, episode_url):
        """从播放页提取视频直链"""
        # 尝试提取剧集号，用于后续匹配
        episode_number = 1
        try:
            # 假设URL中有数字，或者我们不依赖它
            pass
        except:
            pass

        for attempt in range(3):
            try:
                response = self.session.get(episode_url)
                response.raise_for_status()
                html_content = response.text
                
                # 方法1：提取 player_aaaa
                match = re.search(r'var player_aaaa\s*=\s*({[\s\S]*?})\s*;', html_content)
                if not match:
                    match = re.search(r'var player_aaaa\s*=\s*({[\s\S]*?})\s*</script>', html_content)
                
                if match:
                    try:
                        json_str = match.group(1)
                        json_str = json_str.replace("'", '"').replace('\n', '')
                        json_str = re.sub(r'(\w+):', r'"\1":', json_str)
                        json_str = re.sub(r',\s*}', '}', json_str)
                        
                        player_data = json.loads(json_str)
                        if 'url' in player_data:
                            video_url = unquote(player_data['url'])
                            video_url = self._clean_url(video_url)
                            self.log(f"成功提取视频地址: {video_url}")
                            return video_url
                    except Exception as e:
                        # 备选正则提取
                        url_match = re.search(r'"url"\s*:\s*"([^"]+\.(?:mp4|m3u8))"', match.group(1))
                        if url_match:
                            video_url = unquote(url_match.group(1))
                            video_url = self._clean_url(video_url)
                            return video_url

                # 方法2：正则匹配 .mp4 或 .m3u8
                mp4_match = re.search(r'(https?://[^\s"\']+?\.mp4)', html_content)
                if mp4_match:
                    video_url = unquote(mp4_match.group(1))
                    return self._clean_url(video_url)
                
                m3u8_match = re.search(r'(https?://[^\s"\']+?\.m3u8)', html_content)
                if m3u8_match:
                    video_url = unquote(m3u8_match.group(1))
                    return self._clean_url(video_url)

                # 方法3：iframe解析
                soup = BeautifulSoup(html_content, 'html.parser')
                iframe = soup.find('iframe')
                if iframe and iframe.get('src'):
                    iframe_src = urljoin(episode_url, iframe['src'])
                    self.log(f"发现iframe: {iframe_src}")
                    # 如果iframe src本身就是视频
                    if '.mp4' in iframe_src or '.m3u8' in iframe_src:
                         # 可能是 url=xxx.mp4
                        url_match = re.search(r'url=([^&"]+)', iframe_src)
                        if url_match:
                            video_url = unquote(url_match.group(1))
                            return self._clean_url(video_url)
                        return self._clean_url(iframe_src)
                    
                    # 请求iframe内容
                    try:
                        iframe_resp = self.session.get(iframe_src, headers={"Referer": episode_url})
                        iframe_html = iframe_resp.text
                        
                        # 再次尝试匹配
                        mp4_match = re.search(r'(https?://[^\s"\']+?\.mp4)', iframe_html)
                        if mp4_match: 
                            video_url = unquote(mp4_match.group(1))
                            return self._clean_url(video_url)
                        
                        m3u8_match = re.search(r'(https?://[^\s"\']+?\.m3u8)', iframe_html)
                        if m3u8_match: 
                            video_url = unquote(m3u8_match.group(1))
                            return self._clean_url(video_url)
                    except:
                        pass

            except Exception as e:
                self.log(f"提取视频链接失败 (尝试 {attempt+1}/3): {e}")
        
        return None

    def download_m3u8_with_task_control(self, url, anime_name, episode_name, task=None):
        """下载视频（支持m3u8和mp4）- 支持任务控制"""
        # Ensure anime_name is not None
        if not anime_name:
            anime_name = "Unknown"
        
        anime_folder = os.path.join(self.download_folder, re.sub(r'[\\/*?:"<>|]', '', anime_name))
        if not os.path.exists(anime_folder):
            os.makedirs(anime_folder)
            
        # 格式化文件名
        ep_match = re.search(r'第\s*(\d+)\s*[话集]', episode_name)
        if ep_match:
            ep_num = int(ep_match.group(1))
            formatted_episode = f"第{ep_num}集"
        else:
            num_match = re.search(r'\d+', episode_name)
            if num_match:
                formatted_episode = f"第{num_match.group()}集"
            else:
                formatted_episode = re.sub(r'[\\/*?:"<>|]', '', episode_name)
        
        output_path = os.path.join(anime_folder, f"{formatted_episode}.mp4")
        
        # 检查是否已存在
        if self.is_downloaded(anime_name, formatted_episode):
            if task: task.progress = 100
            return output_path
            
        if os.path.exists(output_path):
            self.download_history[f"{anime_name}||{formatted_episode}"] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            if task: task.progress = 100
            return output_path

        # 判断是否为MP4直链
        is_mp4 = False
        if '.mp4' in url or 'format=mp4' in url:
            is_mp4 = True
        
        if is_mp4:
            return self._download_mp4_file(url, output_path, task, anime_name, formatted_episode)
        else:
            return self._download_m3u8_segments(url, output_path, task, anime_name, formatted_episode)

    def _download_mp4_file(self, url, output_path, task, anime_name, episode_name):
        safe_url = requests.utils.requote_uri(url)

        # 尝试不同的Referer策略
        referer_strategies = [
            None,           # Use session default
            "REMOVE",       # Remove Referer
            safe_url        # Use URL as Referer (ASCII-safe)
        ]
        
        last_error = None
        
        for ref_strategy in referer_strategies:
            try:
                kwargs = {"stream": True, "timeout": 30}
                current_referer_log = "Default"
                
                if ref_strategy == "REMOVE":
                    kwargs["headers"] = {"Referer": ""}
                    current_referer_log = "None"
                elif ref_strategy is not None:
                    kwargs["headers"] = {"Referer": ref_strategy}
                    current_referer_log = ref_strategy
                    
                self.log(f"开始下载MP4文件: {url} (Referer策略: {current_referer_log})")
                
                response = self.session.get(safe_url, **kwargs)
                response.raise_for_status()
                
                total_size = int(response.headers.get('content-length', 0))
                if task: 
                    task.total = total_size
                    task.message = "正在下载MP4..."
                
                downloaded = 0
                with open(output_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        if task:
                            task.pause_event.wait()
                            if task.stop_event.is_set():
                                break # Exit loop to close file
                        
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            if task:
                                task.update_bytes(len(chunk))
                                if total_size > 0:
                                    task.progress = int((downloaded / total_size) * 100)
                                    task.message = f"下载中: {downloaded/1024/1024:.1f}MB / {total_size/1024/1024:.1f}MB"
                
                # Check stop event again after loop (and file close)
                if task and task.stop_event.is_set():
                    self.log(f"🛑 任务停止，删除未完成文件: {output_path}")
                    try:
                        if os.path.exists(output_path):
                            os.remove(output_path)
                    except Exception as e:
                        self.log(f"⚠️ 删除未完成文件失败: {e}")
                    return None
            
                if total_size > 0 and downloaded < total_size:
                    raise Exception("下载不完整")
                    
                self.log(f"✅ 下载完成: {output_path}")
                self.download_history[f"{anime_name}||{episode_name}"] = {
                    "path": output_path,
                    "time": time.strftime("%Y-%m-%d %H:%M:%S")
                }
                self.save_download_history()
                return output_path
            
            except Exception as e:
                last_error = e
                self.log(f"策略失败 ({current_referer_log}): {e}")
                if os.path.exists(output_path):
                    try:
                        os.remove(output_path)
                    except:
                        pass
                continue

        self.log(f"❌ MP4下载失败 (所有策略): {last_error}")
        return None

    def _download_m3u8_segments(self, m3u8_url, output_path, task, anime_name, episode_name):
        try:
            self.log(f"解析m3u8: {m3u8_url}")
            response = self.session.get(m3u8_url, timeout=30)
            response.raise_for_status()
            
            playlist = m3u8.loads(response.text, uri=m3u8_url)
            if playlist.is_variant:
                # 如果是多码率列表，选择第一个（通常是最高质量）
                m3u8_url = playlist.playlists[0].absolute_uri
                response = self.session.get(m3u8_url, timeout=30)
                playlist = m3u8.loads(response.text, uri=m3u8_url)
                
            segments = playlist.segments
            if not segments:
                self.log("❌ 没有找到视频分片")
                return None
                
            total_segments = len(segments)
            if task:
                task.total = total_segments
                task.message = f"准备下载 {total_segments} 个分片"
            
            safe_name = re.sub(r'[\\/*?:"<>|\s]', '_', anime_name)
            safe_ep = re.sub(r'[\\/*?:"<>|\s]', '_', episode_name)
            temp_dir = os.path.join(self.download_folder, "temp", f"{safe_name}_{safe_ep}")
            os.makedirs(temp_dir, exist_ok=True)
            
            downloaded_count = 0
            
            def download_segment(segment, index):
                if task:
                    task.pause_event.wait()
                    if task.stop_event.is_set(): return False
                
                segment_path = os.path.join(temp_dir, f"segment_{index:04d}.ts")
                if os.path.exists(segment_path) and os.path.getsize(segment_path) > 0:
                    return True
                
                for _ in range(3):
                    if task and task.stop_event.is_set(): return False
                    try:
                        r = self.session.get(segment.absolute_uri, stream=True, timeout=15)
                        if r.status_code == 200:
                            with open(segment_path, 'wb') as f:
                                for chunk in r.iter_content(8192):
                                    f.write(chunk)
                                    if task: task.update_bytes(len(chunk))
                            return True
                    except:
                        time.sleep(1)
                return False

            with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
                futures = {executor.submit(download_segment, seg, i): i for i, seg in enumerate(segments)}
                for future in as_completed(futures):
                    if task and task.stop_event.is_set(): 
                        # Cancel remaining futures
                        for f in futures: f.cancel()
                        break
                    if future.result():
                        downloaded_count += 1
                        if task:
                            task.progress = int((downloaded_count / total_segments) * 90)
                            task.message = f"下载分片: {downloaded_count}/{total_segments}"
            
            if downloaded_count < total_segments and not (task and task.stop_event.is_set()):
                self.log("❌ 分片下载不完整")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return None
                
            if task and task.stop_event.is_set():
                self.log(f"🛑 任务停止，清理临时文件: {temp_dir}")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return None
            
            # 合并
            if task: task.message = "正在合并..."
            segment_list = os.path.join(temp_dir, "file_list.txt")
            with open(segment_list, 'w', encoding='utf-8') as f:
                for i in range(total_segments):
                    f.write(f"file 'segment_{i:04d}.ts'\n")
            
            # 查找ffmpeg
            ffmpeg_cmd = "ffmpeg"
            # 简单检查ffmpeg是否存在，这里假设环境变量中有，或者在当前目录
            
            cmd = [ffmpeg_cmd, "-f", "concat", "-safe", "0", "-i", os.path.abspath(segment_list), "-c", "copy", os.path.abspath(output_path), "-y"]
            subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            
            shutil.rmtree(temp_dir, ignore_errors=True)
            
            self.download_history[f"{anime_name}||{episode_name}"] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            if task: task.progress = 100
            return output_path
            
        except Exception as e:
            self.log(f"❌ M3U8下载失败: {e}")
            return None
