import ctypes
from ctypes import Structure, c_uint64, c_uint32, sizeof, byref
import threading
import time
import platform
import os

# --- Windows API Structures ---
class MEMORYSTATUSEX(Structure):
    _fields_ = [
        ("dwLength", c_uint32),
        ("dwMemoryLoad", c_uint32),
        ("ullTotalPhys", c_uint64),
        ("ullAvailPhys", c_uint64),
        ("ullTotalPageFile", c_uint64),
        ("ullAvailPageFile", c_uint64),
        ("ullTotalVirtual", c_uint64),
        ("ullAvailVirtual", c_uint64),
        ("ullAvailExtendedVirtual", c_uint64),
    ]

class FILETIME(Structure):
    _fields_ = [("dwLowDateTime", c_uint32), ("dwHighDateTime", c_uint32)]

class SystemMonitor:
    def __init__(self):
        self.stats = {
            'cpu_percent': 0,
            'memory_percent': 0,
            'memory_used': 0,
            'memory_total': 0
        }
        
        self.os_type = platform.system().lower()
        
        # Start background thread
        self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.thread.start()
        print(f"SystemMonitor started (Native {self.os_type.capitalize()} API - No psutil).")

    # --- Windows Helpers ---
    def _get_cpu_times_windows(self):
        idle = FILETIME()
        kernel = FILETIME()
        user = FILETIME()
        if ctypes.windll.kernel32.GetSystemTimes(byref(idle), byref(kernel), byref(user)):
            def ft_to_int(ft):
                return (ft.dwHighDateTime << 32) + ft.dwLowDateTime
            return ft_to_int(idle), ft_to_int(kernel), ft_to_int(user)
        return 0, 0, 0

    def _update_stats_windows(self, last_times):
        last_idle, last_kernel, last_user = last_times
        
        # 1. CPU
        curr_idle, curr_kernel, curr_user = self._get_cpu_times_windows()
        
        idle_delta = curr_idle - last_idle
        kernel_delta = curr_kernel - last_kernel
        user_delta = curr_user - last_user
        
        sys_total = kernel_delta + user_delta
        
        cpu_percent = 0
        if sys_total > 0:
            cpu_percent = ((sys_total - idle_delta) / sys_total) * 100.0
        
        cpu_percent = max(0.0, min(100.0, cpu_percent))

        # 2. Memory
        mem = MEMORYSTATUSEX()
        mem.dwLength = sizeof(MEMORYSTATUSEX)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(byref(mem))
        
        self.stats = {
            'cpu_percent': round(cpu_percent, 1),
            'memory_percent': mem.dwMemoryLoad,
            'memory_used': mem.ullTotalPhys - mem.ullAvailPhys,
            'memory_total': mem.ullTotalPhys
        }
        
        return (curr_idle, curr_kernel, curr_user)

    # --- Linux Helpers ---
    def _get_cpu_times_linux(self):
        try:
            with open('/proc/stat', 'r') as f:
                line = f.readline()
                if line.startswith('cpu'):
                    parts = line.split()
                    # user, nice, system, idle, iowait, irq, softirq, steal, guest, guest_nice
                    # We treat idle = idle + iowait
                    # Total = sum of all
                    values = [float(x) for x in parts[1:]]
                    idle_time = values[3] + (values[4] if len(values) > 4 else 0)
                    total_time = sum(values)
                    return idle_time, total_time
        except:
            pass
        return 0, 0

    def _get_memory_linux(self):
        try:
            mem = {}
            with open('/proc/meminfo', 'r') as f:
                for line in f:
                    parts = line.split(':')
                    if len(parts) == 2:
                        key = parts[0].strip()
                        val = int(parts[1].split()[0]) * 1024 # KB to Bytes
                        mem[key] = val
            
            total = mem.get('MemTotal', 0)
            available = mem.get('MemAvailable', mem.get('MemFree', 0)) # Fallback to free if available missing
            used = total - available
            percent = (used / total * 100) if total > 0 else 0
            
            return percent, used, total
        except:
            return 0, 0, 0

    def _update_stats_linux(self, last_times):
        last_idle, last_total = last_times
        
        # 1. CPU
        curr_idle, curr_total = self._get_cpu_times_linux()
        
        total_delta = curr_total - last_total
        idle_delta = curr_idle - last_idle
        
        cpu_percent = 0
        if total_delta > 0:
            cpu_percent = ((total_delta - idle_delta) / total_delta) * 100.0
            
        cpu_percent = max(0.0, min(100.0, cpu_percent))
        
        # 2. Memory
        mem_percent, mem_used, mem_total = self._get_memory_linux()
        
        self.stats = {
            'cpu_percent': round(cpu_percent, 1),
            'memory_percent': round(mem_percent, 1),
            'memory_used': mem_used,
            'memory_total': mem_total
        }
        
        return (curr_idle, curr_total)

    def _monitor_loop(self):
        # Initial State
        last_times = None
        if 'windows' in self.os_type:
            last_times = self._get_cpu_times_windows()
        else:
            last_times = self._get_cpu_times_linux()
        
        while True:
            try:
                time.sleep(1) # Interval
                
                if 'windows' in self.os_type:
                    last_times = self._update_stats_windows(last_times)
                else:
                    last_times = self._update_stats_linux(last_times)
                
            except Exception as e:
                print(f"Monitor loop error: {e}")
                time.sleep(1)

    def get_stats(self):
        return self.stats
