import requests

url = "https://www.dmdan8.com/static/js/playerconfig.js"
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Referer": "https://www.dmdan8.com/play/9203-2-2.html"
}

try:
    print(f"Fetching {url}...")
    resp = requests.get(url, headers=headers, timeout=10)
    if resp.status_code == 200:
        print("Fetch successful.")
        print(f"Length: {len(resp.text)}")
        print(resp.text[:1000])
        with open("playerconfig.js", "w", encoding="utf-8") as f:
            f.write(resp.text)
    else:
        print(f"Fetch failed: {resp.status_code}")

except Exception as e:
    print(f"Error: {e}")
