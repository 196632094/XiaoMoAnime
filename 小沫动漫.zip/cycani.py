import re
import json
import requests
import urllib.parse
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import os
import shutil
import time
import base64
from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess
import m3u8
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class Cycani:
    def __init__(self, log_callback=None, progress_callback=None):
        self.base_url = "https://www.cycani.org"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://www.cycani.org/"
        }
        self.log_callback = log_callback
        self.progress_callback = progress_callback
        self.download_folder = "downloads"
        self.max_threads = 10
        self.session = requests.Session()
        self.session.headers.update(self.headers)

    def _get_headers_for_url(self, url):
        headers = self.headers.copy()
        if "cycmedia.net" in url or "cycanime.com" in url:
             # Important: Referer must have trailing slash
             headers["Referer"] = "https://player.cycanime.com/"
             headers["Origin"] = "https://player.cycanime.com"
        return headers

    def log(self, message):
        if self.log_callback:
            self.log_callback(f"[Cycani] {message}")
        else:
            print(f"[Cycani] {message}")

    def is_downloaded(self, anime_name, episode_name):
        # Basic check
        safe_anime = re.sub(r'[\\/*?:"<>|]', '', anime_name)
        safe_episode = re.sub(r'[\\/*?:"<>|]', '', episode_name)
        path = os.path.join(self.download_folder, safe_anime, f"{safe_episode}.mp4")
        return os.path.exists(path)

    def search_anime(self, keyword):
        try:
            suggest_url = f"{self.base_url}/index.php/ajax/suggest?mid=1&wd={urllib.parse.quote(keyword)}"
            self.log(f"Searching: {suggest_url}")
            
            resp = self.session.get(suggest_url, verify=False)
            data = resp.json()
            
            results = []
            if 'list' in data:
                for item in data['list']:
                    anime_id = item.get('id')
                    name = item.get('name')
                    pic = item.get('pic')
                    
                    if not anime_id or not name:
                        continue
                        
                    url = f"{self.base_url}/bangumi/{anime_id}.html"
                    
                    results.append({
                        "name": name,
                        "url": url,
                        "cover": pic,
                        "source": "cycani",
                        "status": "unknown"
                    })
            
            return results
        except Exception as e:
            self.log(f"Search failed: {e}")
            return []

    def get_episodes(self, url):
        try:
            self.log(f"Getting episodes: {url}")
            resp = self.session.get(url, verify=False)
            
            soup = BeautifulSoup(resp.text, 'html.parser')
            
            episodes = []
            
            # Selector: ul.anthology-list-play a
            playlists = soup.select('ul.anthology-list-play')
            
            if playlists:
                # Use the first playlist for now
                links = playlists[0].select('a')
                for a in links:
                    name = a.get_text(strip=True)
                    href = a.get('href')
                    if not href: continue
                    
                    full_url = urljoin(self.base_url, href)
                    episodes.append({
                        "name": name,
                        "url": full_url
                    })
            else:
                self.log("No playlists found")
            
            return episodes
        except Exception as e:
            self.log(f"Get episodes failed: {e}")
            return []

    def get_video_url(self, episode_url):
        try:
            self.log(f"Resolving video: {episode_url}")
            resp = self.session.get(episode_url, verify=False)
            
            soup = BeautifulSoup(resp.text, 'html.parser')
            scripts = soup.find_all('script')
            data = None
            
            for s in scripts:
                if s.string and 'player_aaaa' in s.string:
                     try:
                         txt = s.string
                         p_start = txt.find('{')
                         p_end = txt.rfind('}')
                         if p_start != -1 and p_end != -1:
                             json_str = txt[p_start:p_end+1]
                             data = json.loads(json_str)
                             break
                     except:
                         pass
            
            if not data:
                self.log("Failed to extract player data")
                return None
                
            video_url = data.get('url')
            encrypt = data.get('encrypt')
            
            if encrypt == 2:
                video_url = base64.b64decode(video_url).decode('utf-8')
                video_url = urllib.parse.unquote(video_url)
            elif encrypt == 1:
                video_url = urllib.parse.unquote(video_url)
                
            self.log(f"Base Video URL: {video_url}")
            
            # If the URL is on cdn01.cycmedia.net OR it's not a valid http URL (e.g. cycani-xxx ID), 
            # we need to resolve the signed URL
            # Priority: Node.js (Faster/Reliable) -> Selenium (Fallback)
            should_resolve = "cycmedia.net" in video_url or not video_url.startswith("http")
            
            if should_resolve:
                self.log(f"Detected encrypted/CDN URL ({video_url[:30]}...), attempting resolution...")
                
                # 1. Try Node.js first
                signed_url = self._resolve_with_node(video_url)
                if signed_url:
                    self.log(f"Resolved Signed URL via Node: {signed_url}")
                    video_url = signed_url
                else:
                    # 2. Fallback to Selenium
                    self.log("Node resolution skipped or failed, trying Selenium...")
                    try:
                        signed_url = self._resolve_with_selenium(video_url)
                        if signed_url:
                            self.log(f"Resolved Signed URL via Selenium: {signed_url}")
                            video_url = signed_url
                        else:
                            self.log("Selenium resolution failed, using base URL")
                    except Exception as e:
                        self.log(f"Selenium resolution error: {e}")
            
            return {
                "url": video_url,
                "type": "mp4" if ".mp4" in video_url else "m3u8"
            }
            
        except Exception as e:
            self.log(f"Resolve video failed: {e}")
            return None

    def _resolve_with_node(self, base_url):
        # 1. Check for Node executable
        node_exec = None
        try:
            subprocess.run(["node", "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            node_exec = "node"
        except FileNotFoundError:
            try:
                subprocess.run(["nodejs", "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                node_exec = "nodejs"
            except FileNotFoundError:
                pass
        
        if not node_exec:
            self.log("Node.js not found, skipping Node resolution")
            return None

        player_url = f"https://player.cycanime.com/?url={base_url}"
        self.log(f"Fetching player page for Node: {player_url}")
        
        try:
            resp = self.session.get(player_url, verify=False)
            text = resp.text
            
            # Parse IDs
            soup = BeautifulSoup(text, 'html.parser')
            viewport_meta = soup.find('meta', attrs={'name': 'viewport'})
            charset_meta = soup.find('meta', attrs={'charset': 'UTF-8'})
            
            viewport_id = viewport_meta.get('id') if viewport_meta else None
            charset_id = charset_meta.get('id') if charset_meta else None
            
            if not viewport_id or not charset_id:
                self.log("Failed to extract meta IDs for Node decryption")
                return None
            
            # Extract encrypted URL from config
            match = re.search(r'"url":\s*"([^"]+)"', text)
            if not match:
                self.log("Failed to extract encrypted URL from config")
                return None
            
            encrypted_url = match.group(1)
            
            # Call node script
            script_dir = os.path.dirname(os.path.abspath(__file__))
            node_script = os.path.join(script_dir, "node_decrypt.js")
            
            cmd = [node_exec, node_script, encrypted_url, viewport_id, charset_id]
            self.log(f"Running node decrypt using {node_exec}")
            
            process = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8')
            
            if process.returncode != 0:
                self.log(f"Node decrypt failed: {process.stderr}")
                return None
            
            output = process.stdout
            for line in output.splitlines():
                if line.startswith("DECRYPTED_URL:"):
                    return line.replace("DECRYPTED_URL:", "").strip()
            
            return None
            
        except Exception as e:
            self.log(f"Node resolution error: {e}")
            return None

    def _resolve_with_selenium(self, base_url):
        player_url = f"https://player.cycanime.com/?url={base_url}"
        self.log(f"Fetching player page via Selenium: {player_url}")
        
        driver = None
        try:
            # Setup Headless Chrome
            chrome_options = Options()
            chrome_options.add_argument("--headless")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-gpu")
            # Mimic the user agent
            chrome_options.add_argument(f"user-agent={self.headers['User-Agent']}")
            
            # Assuming chromedriver is in path (installed by docker)
            service = Service("chromedriver") # Or default
            # Fallback to default service if "chromedriver" not found in path specifically? 
            # In docker image, it's usually in path.
            
            try:
                driver = webdriver.Chrome(options=chrome_options)
            except Exception as e:
                self.log(f"Failed to start Chrome driver: {e}")
                # Try with specific path if needed, but 'chromium-driver' package puts it in path
                return None
                
            driver.get(player_url)
            
            # Wait for config to be available
            # We can just wait a bit or check for 'config' variable
            time.sleep(2) # Simple wait
            
            # Get encrypted URL from config
            encrypted_url = driver.execute_script("return (typeof config !== 'undefined') ? config.url : null;")
            
            if not encrypted_url:
                self.log("Failed to find config.url in page")
                # Fallback: try regex on page source
                match = re.search(r'"url":\s*"([^"]+)"', driver.page_source)
                if match:
                    encrypted_url = match.group(1)
                else:
                    return None
            
            # Read local scripts
            script_dir = os.path.dirname(os.path.abspath(__file__))
            crypto_js_path = os.path.join(script_dir, "crypto-js.min.js")
            logic_js_path = os.path.join(script_dir, "cycani_player_logic.js")
            
            if not os.path.exists(crypto_js_path) or not os.path.exists(logic_js_path):
                self.log("Missing crypto-js.min.js or cycani_player_logic.js")
                return None
                
            with open(crypto_js_path, 'r', encoding='utf-8') as f:
                crypto_js_content = f.read()
            
            with open(logic_js_path, 'r', encoding='utf-8') as f:
                logic_js_content = f.read()
                
            # Inject scripts
            # 1. Inject CryptoJS
            driver.execute_script(crypto_js_content)
            
            # 2. Inject Logic (it defines 'decrypt' function globally?)
            # Logic file seems to define functions. 'decrypt' is likely global or assigned to window.
            driver.execute_script(logic_js_content)
            
            # 3. Call decrypt
            decrypted = driver.execute_script("return typeof decrypt === 'function' ? decrypt(arguments[0]) : null;", encrypted_url)
            
            if decrypted:
                self.log("Decrypted successfully via Selenium")
                return decrypted
            else:
                self.log("Decrypted returned null")
                return None
            
        except Exception as e:
            self.log(f"Selenium resolution exception: {e}")
            return None
        finally:
            if driver:
                driver.quit()

    def download_m3u8_with_task_control(self, video_url, anime_name, episode_name, task=None):
        # Ensure anime_name is not None
        if not anime_name:
            anime_name = "Unknown"
        
        anime_folder = os.path.join(self.download_folder, re.sub(r'[\\/*?:"<>|]', '', anime_name))
        if not os.path.exists(anime_folder):
            os.makedirs(anime_folder)
            
        safe_episode_name = re.sub(r'[\\/*?:"<>|]', '', episode_name)
        output_path = os.path.join(anime_folder, f"{safe_episode_name}.mp4")
        
        if self.is_downloaded(anime_name, episode_name):
            if task: task.progress = 100
            return output_path
            
        if os.path.exists(output_path):
            if task: task.progress = 100
            return output_path
            
        # Check if it's m3u8
        is_m3u8 = '.m3u8' in video_url or 'application/vnd.apple.mpegurl' in video_url
        
        if is_m3u8:
            return self._download_m3u8_internal(video_url, output_path, task)
        else:
            return self._download_direct_internal(video_url, output_path, task)

    def _download_m3u8_internal(self, m3u8_url, output_path, task=None):
        try:
            self.log(f"Downloading m3u8: {m3u8_url}")
            
            # Fetch m3u8 content
            headers = self._get_headers_for_url(m3u8_url)
            response = requests.get(m3u8_url, headers=headers, verify=False, timeout=30)
            response.raise_for_status()
            
            # Resolve relative URIs
            base_uri = os.path.dirname(m3u8_url) + '/'
            m3u8_obj = m3u8.loads(response.text, uri=base_uri)
            
            # Handle nested playlists
            if m3u8_obj.playlists:
                playlist = m3u8_obj.playlists[0]
                m3u8_url = playlist.absolute_uri
                self.log(f"Nested m3u8 found, redirecting to: {m3u8_url}")
                base_uri = os.path.dirname(m3u8_url) + '/'
                headers = self._get_headers_for_url(m3u8_url)
                response = requests.get(m3u8_url, headers=headers, verify=False, timeout=30)
                m3u8_obj = m3u8.loads(response.text, uri=m3u8_url)
            
            segments = m3u8_obj.segments
            if not segments:
                self.log("No segments found")
                return None
                
            total_segments = len(segments)
            if task:
                task.total = total_segments
                task.message = f"Downloading {total_segments} segments"
            
            # Temp dir
            temp_dir = output_path + "_temp"
            if not os.path.exists(temp_dir):
                os.makedirs(temp_dir)
                
            def download_segment(args):
                seg_idx, segment = args
                
                # Task control check
                if task:
                    task.pause_event.wait()
                    if task.stop_event.is_set():
                        return False

                seg_url = segment.absolute_uri
                seg_path = os.path.join(temp_dir, f"segment_{seg_idx:04d}.ts")
                
                if os.path.exists(seg_path) and os.path.getsize(seg_path) > 0:
                    return True
                
                # Retry loop
                for attempt in range(3):
                    if task and task.stop_event.is_set(): return False
                    try:
                        headers = self._get_headers_for_url(seg_url)
                        r = requests.get(seg_url, headers=headers, verify=False, timeout=30, stream=True)
                        r.raise_for_status()
                        
                        with open(seg_path, 'wb') as f:
                            for chunk in r.iter_content(chunk_size=8192):
                                if task and task.stop_event.is_set(): return False
                                if chunk:
                                    f.write(chunk)
                                    if task: task.update_bytes(len(chunk))
                        return True
                    except Exception as e:
                        time.sleep(1)
                        if os.path.exists(seg_path):
                            try: os.remove(seg_path)
                            except: pass
                return False

            downloaded_count = 0
            
            # Use ThreadPoolExecutor
            with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
                seg_args = [(i, seg) for i, seg in enumerate(segments)]
                futures = {executor.submit(download_segment, arg): arg for arg in seg_args}
                
                for future in as_completed(futures):
                    if task and task.stop_event.is_set():
                        break
                    try:
                        success = future.result()
                        if success:
                            downloaded_count += 1
                    except:
                        pass
                    finally:
                        if task:
                            task.progress = (downloaded_count / total_segments) * 90
                            task.message = f"Downloading: {downloaded_count}/{total_segments} ({task.progress:.1f}%)"
            
            if task and task.stop_event.is_set():
                return None
                
            if downloaded_count < total_segments:
                self.log(f"❌ Download failed: only {downloaded_count}/{total_segments} segments")
                if task: task.message = "Download incomplete"
                return None
            
            # Merge logic
            if task: task.message = "Merging..."
            try:
                segment_list = os.path.join(temp_dir, "file_list.txt")
                with open(segment_list, 'w', encoding='utf-8') as f:
                    for i in range(total_segments):
                        seg_path = os.path.join(temp_dir, f"segment_{i:04d}.ts")
                        abs_seg_path = os.path.abspath(seg_path).replace('\\', '/')
                        f.write(f"file '{abs_seg_path}'\n")
                
                abs_segment_list = os.path.abspath(segment_list)
                abs_output_path = os.path.abspath(output_path)
                
                ffmpeg_cmd = "ffmpeg"
                merge_command = [
                    ffmpeg_cmd, "-y",
                    "-f", "concat", 
                    "-safe", "0", 
                    "-i", abs_segment_list, 
                    "-c", "copy", 
                    abs_output_path
                ]
                
                self.log(f"Merging with ffmpeg")
                
                process = subprocess.run(
                    merge_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    encoding='utf-8', errors='ignore', timeout=600
                )
                
                if process.returncode != 0:
                    self.log(f"FFmpeg merge failed: {process.stderr}")
                    return None
                
                shutil.rmtree(temp_dir, ignore_errors=True)
                if task: task.progress = 100
                return output_path
                
            except Exception as e:
                self.log(f"FFmpeg merge error: {e}")
                return None
            
        except Exception as e:
            self.log(f"Download failed: {e}")
            return None

    def _download_direct_internal(self, url, output_path, task=None):
        try:
            self.log(f"Downloading direct file: {url}")
            if task: task.message = "Downloading..."
            
            headers = self._get_headers_for_url(url)
            with requests.get(url, headers=headers, stream=True, verify=False) as r:
                r.raise_for_status()
                total_length = int(r.headers.get('content-length', 0))
                
                if task and total_length:
                    task.total = total_length
                
                dl = 0
                with open(output_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192): 
                        if chunk: 
                            f.write(chunk)
                            if task: task.update_bytes(len(chunk))
                            dl += len(chunk)
                            if task and total_length:
                                task.progress = (dl / total_length) * 100
                                task.message = f"Downloading: {dl/1024/1024:.1f}MB / {total_length/1024/1024:.1f}MB"
            
            if task: task.progress = 100
            return output_path
        except Exception as e:
            self.log(f"Direct download failed: {e}")
            return None
