import requests

url = "https://www.dmdan8.com/static/js/player.js"
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
}

try:
    print(f"Fetching {url}...")
    resp = requests.get(url, headers=headers, timeout=10)
    if resp.status_code == 200:
        print("Fetch successful.")
        print(resp.text[:1000])
        with open("player.js", "w", encoding="utf-8") as f:
            f.write(resp.text)
    else:
        print(f"Fetch failed: {resp.status_code}")
        
    # Also try to fetch common encryption handling scripts if known
    # e.g. /static/js/base64.js or similar?
    
except Exception as e:
    print(f"Error: {e}")
