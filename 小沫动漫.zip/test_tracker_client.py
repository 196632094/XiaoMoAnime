import socketio
import requests
import time
import threading

BASE_URL = 'http://yyal.iepose.cn'

def run_client(server_label, client_type='client'):
    sio = socketio.Client()
    
    @sio.event
    def connect():
        print(f"[{server_label}] SocketIO Connected!")
        
    @sio.event
    def disconnect():
        print(f"[{server_label}] SocketIO Disconnected!")

    try:
        # Use a fake public IP to test if it's recorded
        query = f"?type={client_type}&public_ip=1.2.3.4&visited_server={server_label}"
        print(f"Connecting to {BASE_URL}{query}...")
        sio.connect(f'{BASE_URL}{query}')
        sio.wait()
    except Exception as e:
        print(f"[{server_label}] Connection failed: {e}")

if __name__ == '__main__':
    print(f"Testing IP Fetch from {BASE_URL}...")
    try:
        resp = requests.get(f'{BASE_URL}/api/get_ip', timeout=10)
        print(f"Proxy Response Code: {resp.status_code}")
        print(f"Proxy Response Body: {resp.text}")
    except Exception as e:
        print(f"Proxy fetch failed: {e}")

    print("\nSimulating multiple connections...")
    
    # Simulate Frontend Visitor (should succeed)
    t1 = threading.Thread(target=run_client, args=('test_visitor_server', 'client'))
    t1.daemon = True
    t1.start()
    
    # Simulate Dashboard (should fail due to auth)
    t2 = threading.Thread(target=run_client, args=('test_dashboard_server', 'dashboard'))
    t2.daemon = True
    t2.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Stopping test...")
