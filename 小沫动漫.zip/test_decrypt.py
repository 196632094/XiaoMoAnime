import base64
import urllib.parse

def decrypt_video_url(encrypted_url):
    try:
        print(f"Input: {encrypted_url}")
        # 第一次URL解码
        url_decoded = urllib.parse.unquote(encrypted_url)
        print(f"Unquoted: {url_decoded}")
        
        # Base64解码
        base64_decoded = base64.b64decode(url_decoded).decode('utf-8')
        print(f"Base64 decoded: {base64_decoded}")
        
        # 循环进行URL解码，直到没有%编码
        decoded = base64_decoded
        while '%' in decoded:
            new_decoded = urllib.parse.unquote(decoded)
            if new_decoded == decoded:  # 如果没有变化，则停止
                break
            decoded = new_decoded
        
        return decoded
    except Exception as e:
        print(f"❌ 解密视频地址失败: {e}")
        return encrypted_url

encrypted = "JTY4JTc0JTc0JTcwJTczJTNBJTJGJTJGJTYxJTY5JTJFJTY3JTY5JTcyJTY5JTY3JTY5JTcyJTY5JTZDJTZGJTc2JTY1JTJFJTZFJTY1JTc0JTJGJTdBJTY5JTZBJTY5JTYxJTZFJTJGJTZGJTZDJTY0JTYxJTZFJTY5JTZEJTY1JTJGJTMyJTMwJTMxJTMwJTJGJTMwJTM3JTJGJTRGJTZFJTY5JTY5JTYzJTY4JTYxJTZFJTY4JTYxJTRGJTczJTY4JTY5JTZEJTYxJTY5JTJGJTMwJTMxJTJGJTcwJTZDJTYxJTc5JTZDJTY5JTczJTc0JTJFJTZEJTMzJTc1JTM4"
result = decrypt_video_url(encrypted)
print(f"Result: {result}")
