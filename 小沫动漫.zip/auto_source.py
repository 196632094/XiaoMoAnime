import concurrent.futures
import difflib
import json
import base64
import re
import time
from urllib.parse import quote, unquote

class AutoSource:
    def __init__(self, sources_dict, log_callback=None, progress_callback=None):
        self.sources = sources_dict
        self.log_callback = log_callback
        self.progress_callback = progress_callback
        # Sources to include in auto search (exclude auto itself if added recursively, and maybe some slow ones if desired)
        self.target_sources = [k for k in self.sources.keys() if k != 'auto']

    def log(self, message):
        if self.log_callback:
            self.log_callback(f"[Auto] {message}")
        else:
            print(f"[Auto] {message}")

    def search_anime(self, keyword):
        self.log(f"Searching across sources: {', '.join(self.target_sources)}")
        
        all_results = []
        
        # Parallel search with timeout
        # User wants speed: "don't wait for all". But we need to merge.
        # Compromise: Set a short timeout (e.g., 4s). Return whatever we have by then.
        timeout = 4.0 
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(self.target_sources)) as executor:
            future_to_source = {
                executor.submit(self._safe_search, source_name, keyword): source_name 
                for source_name in self.target_sources
            }
            
            # Wait for completion or timeout
            done, not_done = concurrent.futures.wait(
                future_to_source.keys(), 
                timeout=timeout,
                return_when=concurrent.futures.ALL_COMPLETED 
            )
            
            # Process completed
            for future in done:
                source_name = future_to_source[future]
                try:
                    results = future.result()
                    if results:
                        for r in results:
                            r['source'] = source_name
                        all_results.extend(results)
                except Exception as e:
                    self.log(f"Search failed for {source_name}: {e}")
            
            # Log skipped
            if not_done:
                skipped = [future_to_source[f] for f in not_done]
                self.log(f"Search timeout, skipping: {', '.join(skipped)}")
                # We do NOT cancel futures as they might be running, just ignore results for this request

        # Merge results
        merged_results = self._merge_search_results(all_results)
        return merged_results

    def _safe_search(self, source_name, keyword):
        source = self.sources.get(source_name)
        if not source: return []
        return source.search_anime(keyword)

    def _normalize_name(self, name):
        # Remove common suffixes/prefixes like [xx字幕] etc if needed
        # For now, just lowercase and remove non-alphanumeric for comparison
        # Actually, user wants "吻合" (matching).
        # Let's keep it simple: lower case.
        return name.lower().strip()

    def _merge_search_results(self, results):
        merged = {}
        
        for item in results:
            name = item.get('name', 'Unknown')
            norm_name = self._normalize_name(name)
            
            # Simple fuzzy matching or grouping
            # For now, let's group by exact normalized name first.
            # If we want to group "Anime S2" and "Anime Season 2", we need difflib.
            
            match_found = False
            for existing_norm in merged.keys():
                # Similarity check
                ratio = difflib.SequenceMatcher(None, norm_name, existing_norm).ratio()
                if ratio > 0.85: # Threshold for "same" anime
                    # Use the existing key
                    norm_name = existing_norm
                    match_found = True
                    break
            
            if norm_name not in merged:
                merged[norm_name] = {
                    'name': name, # Keep the first name found
                    'cover': item.get('cover', ''),
                    'status': item.get('status', 'unknown'),
                    'update_info': item.get('update_info', ''),
                    'source': 'auto',
                    'source_data': [] # List of {source, url}
                }
            
            # Add source info
            merged[norm_name]['source_data'].append({
                'source': item['source'],
                'url': item['url'],
                'name': item['name'] # Keep original name for debugging
            })
            
            # Update cover if missing
            if not merged[norm_name]['cover'] and item.get('cover'):
                merged[norm_name]['cover'] = item.get('cover')
                
        # Convert merged dict to list and create special URL
        final_list = []
        for key, data in merged.items():
            # Create a composite URL that contains all source URLs
            # We encode it to avoid breaking URL structure
            # Structure: auto:<base64_json>
            
            source_data_json = json.dumps(data['source_data'])
            encoded_data = base64.urlsafe_b64encode(source_data_json.encode()).decode()
            data['url'] = f"auto:{encoded_data}"
            
            # Clean up internal fields
            del data['source_data']
            
            final_list.append(data)
            
        return final_list

    def get_episodes(self, url):
        if not url.startswith("auto:"):
            return []
            
        try:
            encoded_data = url.split(":", 1)[1]
            try:
                decoded_json = base64.urlsafe_b64decode(encoded_data).decode()
                source_data = json.loads(decoded_json)
            except Exception as e:
                self.log(f"Failed to decode auto URL data: {e}")
                return []
            
            # Debug logging for source_data structure
            # self.log(f"Debug source_data type: {type(source_data)}")
            if isinstance(source_data, list) and len(source_data) > 0:
                 # Check first item type
                 if not isinstance(source_data[0], dict):
                     self.log(f"WARNING: source_data contains non-dict items! First item: {source_data[0]}")
            
            # source_data should be a list of dicts. If it's not, we have a problem.
            if not isinstance(source_data, list):
                self.log(f"Invalid source_data type: {type(source_data)}")
                return []
            
            all_episodes = {} # Key: episode number/normalized name, Value: {name, urls: []}
            
            # Fetch episodes from all sources in parallel
            # Strategy:
            # 1. Fetch from ALL sources (with timeout).
            # 2. Collect all valid results.
            # 3. Sort by episode count (descending) -> Prefer source with MOST episodes.
            # 4. If counts equal, prefer faster response.
            # 5. Embed alternatives for failover.
            
            first_episodes = None
            first_source_name = None
            
            # Manually manage executor to avoid waiting for all threads
            if len(source_data) == 0:
                return []
                
            executor = concurrent.futures.ThreadPoolExecutor(max_workers=len(source_data))
            valid_results = []
            
            try:
                future_to_src = {}
                for s in source_data:
                    if isinstance(s, dict) and 'source' in s and 'url' in s:
                         future_to_src[executor.submit(self._safe_get_episodes, s['source'], s['url'])] = s
                    else:
                         self.log(f"Invalid source entry: {s}")

                if not future_to_src:
                     return []

                # Wait for ALL completed or timeout
                done, not_done = concurrent.futures.wait(
                    future_to_src.keys(), 
                    timeout=8.0, # Wait up to 8s to ensure we get the best source (e.g. for updates)
                    return_when=concurrent.futures.ALL_COMPLETED
                )
                
                for future in done:
                    src_info = future_to_src[future]
                    source_name = src_info['source']
                    try:
                        episodes = future.result()
                        # Normalize dict result
                        if isinstance(episodes, dict):
                            if 'episodes' in episodes:
                                episodes = episodes['episodes']
                            else:
                                continue # Invalid dict
                                
                        if episodes and isinstance(episodes, list) and len(episodes) > 0:
                            valid_results.append({
                                'source': source_name,
                                'episodes': episodes,
                                'count': len(episodes)
                            })
                    except Exception as e:
                        self.log(f"Get episodes failed for {source_name}: {e}")
                        
            finally:
                executor.shutdown(wait=False, cancel_futures=True)
            
            if not valid_results:
                return []
                
            # Sort by count (descending)
            valid_results.sort(key=lambda x: x['count'], reverse=True)
            
            best_result = valid_results[0]
            first_episodes = best_result['episodes']
            first_source_name = best_result['source']
            
            self.log(f"Selected best source: {first_source_name} with {best_result['count']} episodes")
            
            if not first_episodes:
                return []

            # Normalize first_episodes if it's a dict (e.g. from Omofun/Yhdm)
            # Already normalized above, but kept for safety if logic changes
            if isinstance(first_episodes, dict):
                if 'episodes' in first_episodes:
                     first_episodes = first_episodes['episodes']
                else:
                     self.log(f"Source {first_source_name} returned dict without 'episodes' key")
                     return []

            if not isinstance(first_episodes, list):
                self.log(f"Source {first_source_name} returned invalid episodes type: {type(first_episodes)}")
                return []
                
            # Construct the result list from the first source
            result_list = []
            
            for ep in first_episodes:
                if not isinstance(ep, dict): continue
                # Structure: auto_ep:{ "main": {source, url}, "alternatives": [ {source, anime_url} ] }
                # We include the ANIME URL for alternatives, not episode url (since we haven't fetched them)
                
                alternatives = []
                for s in source_data:
                    # Validate source entry
                    if not isinstance(s, dict) or 'source' not in s or 'url' not in s:
                        continue
                        
                    if s['source'] != first_source_name:
                        alternatives.append({
                            'source': s['source'],
                            'anime_url': s['url']
                        })
                
                ep_data = {
                    'main': {
                        'source': first_source_name,
                        'url': ep['url']
                    },
                    'alternatives': alternatives,
                    'ep_name': ep['name'] # Needed for matching in alternatives
                }
                
                encoded_ep_data = base64.urlsafe_b64encode(json.dumps(ep_data).encode()).decode()
                
                result_list.append({
                    'name': ep['name'],
                    'url': f"auto_ep:{encoded_ep_data}"
                })
                
            return result_list
            
        except Exception as e:
            self.log(f"Error parsing auto URL: {e}")
            return []

    def _safe_get_episodes(self, source_name, url):
        source = self.sources.get(source_name)
        if not source: return []
        return source.get_episodes(url)

    def _merge_episodes(self, all_episodes, new_episodes, source_name):
        for ep in new_episodes:
            name = ep['name']
            url = ep['url']
            
            # Normalize name to find key
            # Try to extract just the number "01", "1", "第1集" -> "1"
            key = name
            match = re.search(r'(\d+(\.\d+)?)', name)
            if match:
                # If it looks like a standard episode number
                # Avoid matching "2023" as episode number if possible, but hard to distinguish
                # Heuristic: if number is < 2000, treat as episode?
                num_val = float(match.group(1))
                if num_val < 1900: 
                    key = str(int(num_val)) if num_val.is_integer() else str(num_val)
            
            if key not in all_episodes:
                all_episodes[key] = {
                    'name': name, # Keep first name
                    'urls': []
                }
            
            all_episodes[key]['urls'].append({
                'source': source_name,
                'url': url
            })

    def get_video_url(self, episode_url):
        if not episode_url.startswith("auto_ep:"):
            return None
            
        try:
            encoded_data = episode_url.split(":", 1)[1]
            ep_data = json.loads(base64.urlsafe_b64decode(encoded_data).decode())
            
            # ep_data structure: { "main": {source, url}, "alternatives": [ {source, anime_url} ], "ep_name": "..." }
            
            # 1. Try Main Source
            main_source_name = ep_data['main']['source']
            main_url = ep_data['main']['url']
            
            self.log(f"Trying main source: {main_source_name}")
            video_info = self._try_get_video(main_source_name, main_url)
            if video_info:
                return video_info
                
            self.log(f"Main source {main_source_name} failed/invalid. Switching to alternatives...")
            
            # 2. Try Alternatives (Lazy Fetch)
            target_ep_name = ep_data.get('ep_name', '')
            
            for alt in ep_data.get('alternatives', []):
                if not isinstance(alt, dict): continue
                
                alt_source_name = alt.get('source')
                alt_anime_url = alt.get('anime_url')
                
                if not alt_source_name or not alt_anime_url: continue
                
                self.log(f"Trying alternative source: {alt_source_name} (Lazy Fetch)")
                
                # Fetch episodes for this source
                source = self.sources.get(alt_source_name)
                if not source: continue
                
                try:
                    episodes = source.get_episodes(alt_anime_url)
                    # Find matching episode
                    found_ep_url = self._find_matching_episode(episodes, target_ep_name)
                    
                    if found_ep_url:
                        self.log(f"Found matching episode in {alt_source_name}: {found_ep_url}")
                        video_info = self._try_get_video(alt_source_name, found_ep_url)
                        if video_info:
                            self.log(f"Successfully switched to {alt_source_name}")
                            return video_info
                    else:
                        self.log(f"Episode '{target_ep_name}' not found in {alt_source_name}")
                        
                except Exception as e:
                    self.log(f"Alternative {alt_source_name} failed: {e}")
            
            return None
            
        except Exception as e:
            self.log(f"Error resolving auto episode: {e}")
            return None

    def _try_get_video(self, source_name, url):
        source = self.sources.get(source_name)
        if not source: return None
        try:
            video_info = source.get_video_url(url)
            
            # Handle if result is a string (URL)
            if isinstance(video_info, str):
                video_info = {'url': video_info}
                
            if video_info and video_info.get('url'):
                 v_url = video_info.get('url')
                 # Check validity (basic)
                 if v_url.startswith('http') or "cycani-" in v_url or "m3u8" in v_url:
                     # IMPORTANT: Inject the actual source name into the result
                     # This allows the proxy/player to use the correct headers (e.g. Ezdm Referer)
                     video_info['actual_source'] = source_name
                     return video_info
                 else:
                     self.log(f"Source {source_name} returned invalid URL format: {v_url[:50]}...")
        except Exception as e:
            self.log(f"Source {source_name} get_video_url error: {e}")
        return None

    def _find_matching_episode(self, episodes, target_name):
        if not episodes or not target_name: return None
        
        # Handle if episodes is a dict (like Omofun/Ezdm return structure)
        if isinstance(episodes, dict):
            if 'episodes' in episodes:
                episodes = episodes['episodes']
            else:
                # Fallback, maybe it's just source info?
                return None
        
        # Ensure episodes is a list
        if not isinstance(episodes, list):
            return None
            
        # 1. Exact Match
        for ep in episodes:
            if not isinstance(ep, dict): continue # Skip invalid entries
            if ep.get('name') == target_name:
                return ep.get('url')
        
        # 2. Number Match
        # Extract number from target
        target_num = self._extract_number(target_name)
        if target_num is not None:
             for ep in episodes:
                 if not isinstance(ep, dict): continue
                 ep_num = self._extract_number(ep.get('name'))
                 if ep_num is not None and ep_num == target_num:
                     return ep.get('url')
        
        return None

    def _extract_number(self, text):
        match = re.search(r'(\d+(\.\d+)?)', str(text))
        if match:
            return float(match.group(1))
        return None

    def is_downloaded(self, anime_name, episode_name):
        # Delegate to the first available source (e.g. girigiri) or check standard folder
        # Since most sources share the same download structure/logic, checking one is usually enough
        # or checking the file system directly if we knew the base path.
        # But we don't have direct access to download_folder config here easily without passing it.
        # However, we have self.sources.
        
        # Try 'girigiri' first as it's the base class for many
        if 'girigiri' in self.sources:
            return self.sources['girigiri'].is_downloaded(anime_name, episode_name)
            
        # Or just try any source
        for source in self.sources.values():
            if hasattr(source, 'is_downloaded'):
                return source.is_downloaded(anime_name, episode_name)
                
        return False

    def download_m3u8_with_task_control(self, video_url, anime_name, episode_name, task=None):
        # We need to delegate download to a real source.
        # Ideally, we should know WHICH source provided this video_url.
        # But video_url is just a string here (the resolved one).
        
        # Strategy:
        # 1. Use 'girigiri' (or any standard source) to handle the download if it's a standard URL.
        #    Most sources use the same download logic (requests/ffmpeg).
        # 2. IF the URL is special (e.g. requires specific headers like cycani), 
        #    we might need the specific source.
        
        # Since we don't track which source generated the final video_url in this method signature easily (unless we parse the URL),
        # we need to be smart. 
        # But wait! If this is an "auto_ep" URL (which it likely is if it came from AutoSource),
        # we can decode it to get the FULL list of alternatives!
        
        # However, the task manager resolves the video URL *before* calling download.
        # So 'video_url' passed here is the *resolved* M3U8/MP4 URL, not the "auto_ep:..." string.
        # This makes it hard to switch sources because we lost the alternatives list.
        
        # SOLUTION: We need to rely on the fact that `get_video_url` (which was called before this)
        # returned the resolved URL. If that download fails, the TaskManager usually just retries the SAME URL.
        # We can't easily switch sources *inside* download_m3u8_with_task_control unless we re-resolve.
        
        # BUT, we can try to guess the source from the URL and if it fails, we are stuck.
        # UNLESS... we change how TaskManager calls this.
        # OR... we re-implement the download logic here to handle the "Auto" nature if possible.
        
        # Actually, if the user says "Auto switch source if download fails", 
        # it implies we need access to those alternatives.
        
        # The only way to have access to alternatives here is if `video_url` contained them, 
        # OR if we stored them somewhere.
        # But `video_url` is a plain string.
        
        # WORKAROUND:
        # Since we can't easily change the TaskManager architecture right now (it expects get_video_url -> download),
        # we will try to make the best of what we have.
        # IF the download fails, we can't switch source because we don't know the other sources here.
        
        # WAIT! `task.episode_url` in TaskManager IS the "auto_ep:..." URL!
        # We can re-parse `task.episode_url` to get the alternatives!
        
        if not task or not hasattr(task, 'episode_url') or not task.episode_url.startswith('auto_ep:'):
            # Fallback to simple delegation if we can't find the auto info
            return self._delegate_download_simple(video_url, anime_name, episode_name, task)

        # We have the auto_ep URL! We can implement the full failover logic.
        try:
            encoded_data = task.episode_url.split(":", 1)[1]
            ep_data = json.loads(base64.urlsafe_b64decode(encoded_data).decode())
            
            # ep_data: { "main": ..., "alternatives": [...], "ep_name": ... }
            
            # Check data type
            if isinstance(ep_data, list):
                # Legacy or incorrect format, maybe list of sources?
                # Try to adapt if it's a list of {source, url}
                # But wait, the error `string indices must be integers` usually means 
                # we are doing `something['key']` but `something` is a string.
                # In `ep_data['main']['source']`, if `ep_data` is a list, `ep_data['main']` fails with integer index required.
                # OR if `ep_data['main']` is a string (not dict), `['source']` fails.
                
                self.log(f"Auto URL data is a list, not dict. Attempting compatibility.")
                # If it's a list, we assume it's [ {source, url}, ... ] (old format)
                sources_to_try = []
                for item in ep_data:
                    if isinstance(item, dict):
                        sources_to_try.append({
                            'source': item.get('source'),
                            'url': item.get('url'),
                            'is_main': False # Treat all as equal/alternatives
                        })
                
                # Mark first as main-ish
                if sources_to_try:
                    sources_to_try[0]['is_main'] = True
                    
                target_ep_name = task.episode_name # Fallback to task name
                
            else:
                # Standard Dict format
                # List of sources to try: Main -> Alternatives
                sources_to_try = []
                
                if 'main' in ep_data:
                    sources_to_try.append({
                        'source': ep_data['main']['source'],
                        'url': ep_data['main']['url'], 
                        'is_main': True
                    })
                
                # 2. Add Alternatives
                for alt in ep_data.get('alternatives', []):
                    if isinstance(alt, dict) and 'source' in alt and 'anime_url' in alt:
                        sources_to_try.append({
                            'source': alt['source'],
                            'url': alt['anime_url'], 
                            'is_main': False
                        })
                    
                target_ep_name = ep_data.get('ep_name', '')
            
            # Iterate and try downloading
            for i, src_info in enumerate(sources_to_try):
                source_name = src_info['source']
                
                if task.stop_event.is_set(): return None
                
                self.log(f"Attempting download via source: {source_name} ({i+1}/{len(sources_to_try)})")
                if task: task.message = f"正在尝试源: {source_name}..."
                
                # Get the source object
                source_obj = self.sources.get(source_name)
                if not source_obj: continue
                
                # Resolve Video URL for this source
                current_video_url = None
                
                try:
                    if src_info.get('is_main'):
                        # If it's main, we might already have the resolved video_url passed to this function.
                        # BUT, that `video_url` might be stale or dead (hence why we are here?).
                        # Or maybe it is the first attempt.
                        # Let's try to use the passed `video_url` ONLY for the first attempt (which matches main)
                        if i == 0:
                            current_video_url = video_url
                        else:
                            # Re-resolve
                            vid_info = self._try_get_video(source_name, src_info['url'])
                            if vid_info: current_video_url = vid_info.get('url')
                    else:
                        # Alternative: Need to fetch episodes first, then find match, then resolve
                        if task: task.message = f"正在切换源 {source_name}: 获取剧集..."
                        episodes = source_obj.get_episodes(src_info['url'])
                        found_ep_url = self._find_matching_episode(episodes, target_ep_name)
                        
                        if found_ep_url:
                            if task: task.message = f"正在切换源 {source_name}: 解析视频..."
                            vid_info = self._try_get_video(source_name, found_ep_url)
                            if vid_info: current_video_url = vid_info.get('url')
                        else:
                            self.log(f"Episode not found in {source_name}")
                            
                except Exception as e:
                    self.log(f"Resolution failed for {source_name}: {e}")
                    
                if not current_video_url:
                    self.log(f"Could not resolve video URL for {source_name}")
                    continue
                    
                # Now try to DOWNLOAD
                try:
                    # Delegate to the source's downloader
                    if hasattr(source_obj, 'download_m3u8_with_task_control'):
                        result = source_obj.download_m3u8_with_task_control(current_video_url, anime_name, episode_name, task)
                        
                        if result:
                            self.log(f"Download successful via {source_name}")
                            return result
                        else:
                            self.log(f"Download failed via {source_name} (returned None)")
                except Exception as e:
                    self.log(f"Download exception via {source_name}: {e}")
                    
                # If we are here, this source failed. Loop continues to next source.
                if task: task.message = f"源 {source_name} 下载失败，尝试下一个..."
                time.sleep(1)
            
            # All sources failed
            return None
            
        except Exception as e:
            self.log(f"Auto download failover error: {e}")
            # Fallback
            return self._delegate_download_simple(video_url, anime_name, episode_name, task)

    def _delegate_download_simple(self, video_url, anime_name, episode_name, task=None):
        # Original simple delegation logic
        downloader = None
        if "cycmedia" in video_url or "cycanime" in video_url:
             downloader = self.sources.get('cycani')
        elif "xifan" in video_url:
             downloader = self.sources.get('xifan')
        
        if not downloader:
             downloader = self.sources.get('girigiri')
             
        if not downloader:
             for s in self.sources.values():
                 if hasattr(s, 'download_m3u8_with_task_control'):
                     downloader = s
                     break
                     
        if downloader:
            self.log(f"Delegating download to {downloader.__class__.__name__}")
            return downloader.download_m3u8_with_task_control(video_url, anime_name, episode_name, task)
            
        return None
