import json
import os

class SettingsManager:
    def __init__(self, settings_file="settings.json"):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        if not os.path.isabs(settings_file):
            settings_file = os.path.join(base_dir, settings_file)
        self.settings_file = settings_file
        self.settings = {
            "max_threads": 10,
            "max_retries": 3,
            "download_folder": "downloads",
            "concurrent_episodes": 3,
            "concurrent_anime_enabled": False,
            "max_concurrent_anime": 1,
            "auto_update_interval": 24,
            "enable_hidden_sources": False,
            "naming_scheme": "simple",
            "default_season_number": 1
        }
        self.load_settings()

    def load_settings(self):
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    saved_settings = json.load(f)
                    self.settings.update(saved_settings)
            except Exception as e:
                print(f"Failed to load settings: {e}")

    def save_settings(self):
        try:
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(self.settings, f, indent=4)
        except Exception as e:
            print(f"Failed to save settings: {e}")

    def get(self, key, default=None):
        return self.settings.get(key, default)

    def set(self, key, value):
        self.settings[key] = value
        self.save_settings()

    def update(self, new_settings):
        self.settings.update(new_settings)
        self.save_settings()
