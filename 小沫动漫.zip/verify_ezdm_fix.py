from ezdm import Ezdm
import urllib3

urllib3.disable_warnings()

def log(msg):
    print(msg)

ezdm = Ezdm(log_callback=log)

urls = [
    "https://m.ezdmw.site/Index/video/70874.html", # Should work
    "https://m.ezdmw.site/Index/video/77526.html"  # Likely fails
]

for url in urls:
    print(f"\nTesting: {url}")
    result = ezdm.resolve_video(url)
    print(f"Result: {result}")
