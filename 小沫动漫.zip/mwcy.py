import requests
import re
import os
import json
import time
import shutil
import subprocess
from bs4 import BeautifulSoup
from urllib.parse import urljoin, unquote
from concurrent.futures import ThreadPoolExecutor, as_completed
import m3u8
import threading
try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad
    import base64
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False

class MwcySource:
    def __init__(self, log_callback=None, progress_callback=None):
        self.base_url = "https://www.mwcy.net"
        self.search_url = "https://www.mwcy.net/search.html?wd={}"
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Referer": self.base_url
        })
        # SSL verification disabled for this source
        self.session.verify = False
        
        self.log_callback = log_callback
        self.progress_callback = progress_callback
        
        self.download_folder = "downloads"
        self.log_folder = "logs"
        self.download_history_file = os.path.join(self.log_folder, "download_history.json")
        self.max_threads = 10
        
        if not os.path.exists(self.download_folder):
            os.makedirs(self.download_folder)
        if not os.path.exists(self.log_folder):
            os.makedirs(self.log_folder)
            
        self.download_history = self.load_download_history()

    def log(self, message):
        print(message)
        if self.log_callback:
            self.log_callback(message)

    def update_progress(self, current, total, desc=""):
        if self.progress_callback:
            self.progress_callback(current, total, desc)

    def load_download_history(self):
        if os.path.exists(self.download_history_file):
            try:
                with open(self.download_history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
        
    def save_download_history(self):
        with open(self.download_history_file, 'w', encoding='utf-8') as f:
            json.dump(self.download_history, f, ensure_ascii=False, indent=2)

    def is_downloaded(self, anime_name, episode_name):
        key = f"{anime_name}||{episode_name}"
        if key not in self.download_history:
            return False
        record = self.download_history[key]
        if 'path' in record and os.path.exists(record['path']):
            return True
        del self.download_history[key]
        self.save_download_history()
        return False

    def search_anime(self, keyword):
        """搜索番剧并返回结果列表"""
        try:
            self.log(f"正在搜索(Mwcy): {keyword}")
            response = self.session.get(self.search_url.format(keyword))
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            results = []
            # Try specific selectors found in inspection
            items = soup.select('.search-list')
            if not items:
                items = soup.select('.public-list-box') # Fallback
            if not items:
                # Based on inspection, items are wrapped in search-list but also have .fadeInLeft
                # If .search-list is the container, items are children? 
                # Inspection showed: <div class="vod-detail style-detail cor4 search-list"> is the item itself
                items = soup.select('.search-list')

            for item in items:
                title = ""
                detail_path = ""
                
                # Title & Link
                # Try finding link first
                link_elem = item.select_one('.detail-info > a')
                if not link_elem:
                    link_elem = item.select_one('a.detail-pic')
                
                if link_elem:
                    detail_path = link_elem.get('href')
                    # Try to get title from title element if exists
                    title_elem = item.select_one('.slide-info-title')
                    if title_elem:
                        title = title_elem.text.strip()
                    elif link_elem.get('title'):
                        title = link_elem.get('title')
                
                # Image & Fallback Title
                img_elem = item.select_one('.detail-pic img')
                if img_elem:
                    if not title and img_elem.get('alt'):
                        title = img_elem['alt'].strip()
                
                if not title or not detail_path:
                    continue
                    
                # Cover URL
                cover_url = ""
                if img_elem:
                    if img_elem.get('data-src'):
                        cover_url = img_elem['data-src']
                    elif img_elem.get('src'):
                        cover_url = img_elem['src']
                
                if cover_url and not cover_url.startswith('http'):
                    cover_url = urljoin(self.base_url, cover_url)
                
                # Status & Update Info
                status = "unknown"
                update_info = ""
                
                # Look for remarks (e.g. "更新至12集", "2025", "webrip")
                remarks = item.select('.slide-info-remarks')
                all_remarks_text = " ".join([r.text.strip() for r in remarks])
                
                if "完结" in all_remarks_text:
                    status = "completed"
                    update_info = "已完结"
                elif "更新" in all_remarks_text:
                    status = "ongoing"
                    # Find the specific remark with "更新"
                    for r in remarks:
                        if "更新" in r.text:
                            update_info = r.text.strip()
                            break
                    if not update_info: update_info = "连载中"
                elif "未播" in all_remarks_text or "预告" in all_remarks_text:
                    status = "not_aired"
                    update_info = "未开播"
                
                # Date checks
                if status == "unknown":
                    if "2025" in all_remarks_text or "2026" in all_remarks_text:
                        # Heuristic: if future year and no "update/completed", might be not aired or just year info
                        # But user wants "未开播" for future
                        # If it has "webrip" it might be aired? 
                        if "webrip" in all_remarks_text.lower():
                            status = "ongoing" # Or completed? Webrip usually means out.
                            update_info = "WebRip"
                        else:
                            # Assume ongoing or not aired based on context?
                            # Let's default to ongoing if year is present unless explicitly "not aired"
                            # But user said "预更新也要同步好", "未开播"
                            # Let's look for "开播" text
                            if "开播" in all_remarks_text:
                                status = "not_aired"
                                update_info = all_remarks_text
                            else:
                                status = "ongoing" # Default to ongoing if year found
                                update_info = all_remarks_text

                results.append({
                    "name": title,
                    "url": urljoin(self.base_url, detail_path),
                    "cover": cover_url,
                    "source": "mwcy",
                    "status": status,
                    "update_info": update_info
                })
            
            return results
            
        except Exception as e:
            self.log(f"搜索失败(Mwcy): {e}")
            return []

    def get_episodes(self, anime_url):
        """获取番剧的线路和剧集"""
        try:
            response = self.session.get(anime_url)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 解析线路 - Mwcy might have tabs like .anthology-tab
            lines = []
            # Check for tabs
            tabs = soup.select('.anthology-tab .swiper-slide')
            if tabs:
                for i, tab in enumerate(tabs):
                    lines.append({
                        "id": i,
                        "name": tab.text.strip(),
                        "episodes": []
                    })
            else:
                 # Fallback: check for headers or just one list
                 pass
            
            if not lines:
                lines.append({"id": 0, "name": "默认线路", "episodes": []})

            # 解析剧集列表 containers
            # Usually .anthology-list-box corresponds to tabs
            containers = soup.select('.anthology-list-box')
            
            # If no containers found by class, try finding any list
            if not containers:
                 # Fallback for simple pages
                 containers = [soup] # Search in whole soup or specific div
            
            for i, container in enumerate(containers):
                if i >= len(lines):
                    # If more containers than lines (or lines manually created), map 1-to-1
                    if len(lines) == 1 and i > 0:
                        lines.append({"id": i, "name": f"线路{i+1}", "episodes": []})
                    elif i >= len(lines):
                         break
                
                current_line = lines[i]
                
                # Find episodes in this container
                # Selectors: .anthology-list-play li a, .playlist li a, .num-list li a
                eps = container.select('.anthology-list-play li a')
                if not eps:
                    eps = container.select('.playlist li a')
                if not eps:
                    eps = container.select('.num-list li a')
                
                for ep in eps:
                    ep_url = urljoin(self.base_url, ep['href'])
                    ep_name = ep.text.strip()
                    current_line["episodes"].append({
                        "name": ep_name,
                        "original_name": ep_name,
                        "url": ep_url
                    })

            # Select best line (default logic)
            selected_line = None
            for line in lines:
                if line['episodes']:
                    selected_line = line
                    break
            
            if selected_line:
                self.log(f"已选择线路(Mwcy): {selected_line['name']}")
                return selected_line['episodes']
            
            return []
            
        except Exception as e:
            self.log(f"获取剧集失败(Mwcy): {e}")
            return []

    def _clean_url(self, url):
        if not url: return None
        url = url.replace('\\/', '/')
        url = url.replace('\\\\', '/')
        url = re.sub(r'^(https?:)/+', r'\1//', url)
        return url.strip()

    def get_video_url(self, episode_url):
        """从播放页提取视频直链"""
        for attempt in range(3):
            try:
                response = self.session.get(episode_url)
                response.raise_for_status()
                html_content = response.text
                
                # 1. JSON Data (player_aaaa)
                # Use greedy match for JSON content to capture nested objects
                match = re.search(r'player_aaaa\s*=\s*({.*})', html_content)
                if match:
                    try:
                        json_str = match.group(1)
                        # Attempt to parse
                        try:
                            player_data = json.loads(json_str)
                            if 'url' in player_data:
                                video_url = unquote(player_data['url'])
                                
                                # Check if URL is encoded/obfuscated (doesn't start with http)
                                if not video_url.startswith('http'):
                                    self.log(f"Detected encoded URL: {video_url[:30]}...")
                                    # Try to decode via API
                                    decoded_url = self._decode_url_via_api(video_url)
                                    if decoded_url:
                                        return self._clean_url(decoded_url)
                                    else:
                                        # Fallback: maybe it's just missing protocol?
                                        # But the example was "D3canc..." which is definitely encoded
                                        pass
                                
                                return self._clean_url(video_url)
                        except:
                            pass
                            
                        # Fallback: Regex search for "url" key
                        url_match = re.search(r'"url"\s*:\s*"([^"]+)"', json_str)
                        if url_match:
                            video_url = unquote(url_match.group(1))
                            if not video_url.startswith('http'):
                                decoded_url = self._decode_url_via_api(video_url)
                                if decoded_url: return self._clean_url(decoded_url)
                            return self._clean_url(video_url)
                    except:
                        pass

                # 2. Iframe
                soup = BeautifulSoup(html_content, 'html.parser')
                iframe = soup.find('iframe')
                if iframe and iframe.get('src'):
                    src = urljoin(episode_url, iframe['src'])
                    # If src is video
                    if '.mp4' in src or '.m3u8' in src:
                        # Check if it has url param
                        url_match = re.search(r'url=([^&"]+)', src)
                        if url_match:
                            return self._clean_url(unquote(url_match.group(1)))
                        return self._clean_url(src)
                    
                    # Fetch iframe content
                    try:
                        r_iframe = self.session.get(src, headers={"Referer": episode_url})
                        # Look for mp4/m3u8 in iframe
                        v_match = re.search(r'(https?://[^\s"\'<>]+\.(?:mp4|m3u8))', r_iframe.text)
                        if v_match:
                            return self._clean_url(unquote(v_match.group(1)))
                    except:
                        pass

                # 3. Direct Regex in page
                v_match = re.search(r'(https?://[^\s"\'<>]+\.(?:mp4|m3u8))', html_content)
                if v_match:
                    return self._clean_url(unquote(v_match.group(1)))

            except Exception as e:
                self.log(f"提取视频失败 {attempt}: {e}")
        
        return None

    def _decode_url_via_api(self, encoded_url, depth=0):
        """Decode obfuscated URL using the external API found in player config (Recursive + AES)"""
        if depth > 3:
            self.log("Max recursion depth reached for URL decoding")
            return None

        # API endpoint found in playerconfig.js
        api_url = "https://play.catw.moe/player/ec.php"
        params = {
            "code": "qw",
            "if": "1",
            "url": encoded_url
        }
        
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Referer": "https://www.mwcy.net"
        }

        # Retry logic for API call
        for attempt in range(3):
            try:
                self.log(f"Decoding URL via API (Depth {depth}, Attempt {attempt+1}/3)...")
                
                # Increased timeout to 30 seconds
                resp = requests.get(api_url, params=params, headers=headers, verify=False, timeout=30)
                
                if resp.status_code == 200:
                    result_url = None
                    uid = None
                    
                    # Check for JSON first
                    try:
                        data = resp.json()
                        if 'url' in data:
                            result_url = data['url']
                        if 'config' in data and 'uid' in data['config']:
                            uid = data['config']['uid']
                    except:
                        pass
                    
                    if not result_url:
                        # Check for regex match in text (e.g. var url = '...')
                        m = re.search(r'url\s*=\s*[\'"](http[^"\']+)[\'"]', resp.text)
                        if m:
                            result_url = m.group(1)
                            
                    if not result_url:
                        # Check for m3u8 directly in text
                        m_m3u8 = re.search(r'(https?://[^"\']+\.m3u8)', resp.text)
                        if m_m3u8:
                            result_url = m_m3u8.group(1)
                            
                    if not result_url:
                        # Check for JSON in text
                        m_json = re.search(r'"url"\s*:\s*"([^"]+)"', resp.text)
                        if m_json:
                            result_url = m_json.group(1).replace('\\/', '/')
                    
                    # Always try to find ConFig for UID
                    # Support let/var/const and optional spaces
                    m_config = re.search(r'(?:let|var|const)\s+ConFig\s*=\s*({.*})', resp.text)
                    if m_config:
                        try:
                            config_data = json.loads(m_config.group(1))
                            if not result_url and 'url' in config_data:
                                result_url = config_data['url']
                            if 'config' in config_data and 'uid' in config_data['config']:
                                uid = config_data['config']['uid']
                        except:
                            # Regex fallback for ConFig
                            if not result_url:
                                m_url_in_config = re.search(r'"url"\s*:\s*"([^"]+)"', m_config.group(1))
                                if m_url_in_config:
                                    result_url = m_url_in_config.group(1).replace('\\/', '/')
                            
                            m_uid = re.search(r'"uid"\s*:\s*"([^"]+)"', m_config.group(1))
                            if m_uid:
                                uid = m_uid.group(1)
                    
                    # Global fallback for UID if not found in ConFig
                    if not uid:
                        m_uid_global = re.search(r'"uid"\s*:\s*"([^"]+)"', resp.text)
                        if m_uid_global:
                            uid = m_uid_global.group(1)
                            self.log(f"Found UID via global search: {uid}")

                    if result_url:
                        # Recursive check
                        if result_url.startswith('http'):
                            return result_url
                        
                        # Try AES Decryption if UID is present and result is not http
                        if uid:
                            if HAS_CRYPTO:
                                try:
                                    self.log(f"Attempting AES decryption with UID: {uid}")
                                    key_str = f"2890{uid}tB959C"
                                    iv_str = "2F131BE91247866E"
                                    key = key_str.encode('utf-8')
                                    iv = iv_str.encode('utf-8')
                                    cipher = AES.new(key, AES.MODE_CBC, iv)
                                    encrypted_bytes = base64.b64decode(result_url)
                                    decrypted_bytes = unpad(cipher.decrypt(encrypted_bytes), AES.block_size)
                                    decrypted_url = decrypted_bytes.decode('utf-8')
                                    if decrypted_url.startswith('http'):
                                        self.log("AES Decryption successful")
                                        return decrypted_url
                                    else:
                                        self.log(f"AES Decrypted URL invalid: {decrypted_url[:50]}...")
                                except Exception as e:
                                    self.log(f"AES Decryption failed: {e}")
                            else:
                                self.log("AES decryption required but pycryptodome not installed")
                        else:
                            self.log("UID not found for AES decryption")
                            if depth == 0: self.log(f"Response snippet: {resp.text[:200]}")

                        self.log(f"Decoded URL is still encoded: {result_url[:30]}...")
                        return self._decode_url_via_api(result_url, depth + 1)
                
                self.log(f"API decode failed: Status {resp.status_code}")
                
            except requests.exceptions.Timeout:
                self.log(f"API decode timeout (Attempt {attempt+1})")
            except Exception as e:
                self.log(f"API decode error: {e}")
            
            # Short sleep before retry
            if attempt < 2:
                time.sleep(2)
                
        return None

    def download_m3u8_with_task_control(self, url, anime_name, episode_name, task=None):
        # Re-using Xifan's logic or generic logic. 
        # Since I cannot import XifanSource here easily to reuse without instantiation,
        # I will duplicate the standard download logic which is robust.
        
        if not anime_name: anime_name = "Unknown"
        anime_folder = os.path.join(self.download_folder, re.sub(r'[\\/*?:"<>|]', '', anime_name))
        if not os.path.exists(anime_folder): os.makedirs(anime_folder)
            
        # Format filename
        formatted_episode = episode_name
        ep_match = re.search(r'第\s*(\d+)\s*[话集]', episode_name)
        if ep_match:
            formatted_episode = f"第{ep_match.group(1)}集"
        else:
            num_match = re.search(r'\d+', episode_name)
            if num_match: formatted_episode = f"第{num_match.group()}集"
            else: formatted_episode = re.sub(r'[\\/*?:"<>|]', '', episode_name)
        
        output_path = os.path.join(anime_folder, f"{formatted_episode}.mp4")
        
        if self.is_downloaded(anime_name, formatted_episode):
            if task: task.progress = 100
            return output_path
        if os.path.exists(output_path):
            self.download_history[f"{anime_name}||{formatted_episode}"] = {"path": output_path, "time": time.strftime("%Y-%m-%d %H:%M:%S")}
            self.save_download_history()
            if task: task.progress = 100
            return output_path

        # Determine type
        if '.mp4' in url or 'format=mp4' in url:
            return self._download_mp4_file(url, output_path, task, anime_name, formatted_episode)
        else:
            return self._download_m3u8_segments(url, output_path, task, anime_name, formatted_episode)

    def _download_mp4_file(self, url, output_path, task, anime_name, episode_name):
        safe_url = requests.utils.requote_uri(url)
        try:
            kwargs = {"stream": True, "timeout": 30, "headers": {"Referer": self.base_url}}
            self.log(f"下载MP4: {url}")
            response = self.session.get(safe_url, **kwargs)
            response.raise_for_status()
            total_size = int(response.headers.get('content-length', 0))
            if task: task.total = total_size; task.message = "下载MP4..."
            
            downloaded = 0
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(8192):
                    if task:
                        task.pause_event.wait()
                        if task.stop_event.is_set(): break
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if task:
                            task.update_bytes(len(chunk))
                            if total_size > 0:
                                task.progress = int((downloaded/total_size)*100)
                                task.message = f"{downloaded/1024/1024:.1f}MB / {total_size/1024/1024:.1f}MB"
            
            if task and task.stop_event.is_set():
                if os.path.exists(output_path): os.remove(output_path)
                return None
            
            self.download_history[f"{anime_name}||{episode_name}"] = {"path": output_path, "time": time.strftime("%Y-%m-%d %H:%M:%S")}
            self.save_download_history()
            return output_path
        except Exception as e:
            self.log(f"MP4下载失败: {e}")
            if os.path.exists(output_path): os.remove(output_path)
            return None

    def _download_m3u8_segments(self, m3u8_url, output_path, task, anime_name, episode_name):
        try:
            self.log(f"解析m3u8: {m3u8_url}")
            response = self.session.get(m3u8_url, timeout=30)
            playlist = m3u8.loads(response.text, uri=m3u8_url)
            if playlist.is_variant:
                m3u8_url = playlist.playlists[0].absolute_uri
                response = self.session.get(m3u8_url, timeout=30)
                playlist = m3u8.loads(response.text, uri=m3u8_url)
            
            segments = playlist.segments
            if not segments: return None
            
            total = len(segments)
            if task: task.total = total; task.message = f"准备下载 {total} 分片"
            
            safe_name = re.sub(r'[\\/*?:"<>|\s]', '_', anime_name)
            safe_ep = re.sub(r'[\\/*?:"<>|\s]', '_', episode_name)
            temp_dir = os.path.join(self.download_folder, "temp", f"{safe_name}_{safe_ep}")
            os.makedirs(temp_dir, exist_ok=True)
            
            downloaded = 0
            def dl_seg(seg, idx):
                if task and task.stop_event.is_set(): return False
                p = os.path.join(temp_dir, f"seg_{idx:04d}.ts")
                if os.path.exists(p) and os.path.getsize(p) > 0: return True
                try:
                    r = self.session.get(seg.absolute_uri, stream=True, timeout=15)
                    if r.status_code == 200:
                        with open(p, 'wb') as f:
                            for c in r.iter_content(8192): f.write(c); 
                            if task: task.update_bytes(len(c))
                        return True
                except: pass
                return False

            with ThreadPoolExecutor(max_workers=self.max_threads) as exc:
                futures = {exc.submit(dl_seg, s, i): i for i, s in enumerate(segments)}
                for f in as_completed(futures):
                    if task and task.stop_event.is_set(): break
                    if f.result():
                        downloaded += 1
                        if task: task.progress = int((downloaded/total)*90); task.message = f"下载分片: {downloaded}/{total}"
            
            if task and task.stop_event.is_set():
                shutil.rmtree(temp_dir, ignore_errors=True)
                return None
                
            if downloaded < total:
                self.log("分片不完整")
                return None
                
            # Concat
            if task: task.message = "正在合并..."
            lst_path = os.path.join(temp_dir, "list.txt")
            with open(lst_path, 'w', encoding='utf-8') as f:
                for i in range(total): f.write(f"file 'seg_{i:04d}.ts'\n")
            
            subprocess.run(["ffmpeg", "-f", "concat", "-safe", "0", "-i", os.path.abspath(lst_path), "-c", "copy", os.path.abspath(output_path), "-y"], 
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            
            shutil.rmtree(temp_dir, ignore_errors=True)
            self.download_history[f"{anime_name}||{episode_name}"] = {"path": output_path, "time": time.strftime("%Y-%m-%d %H:%M:%S")}
            self.save_download_history()
            if task: task.progress = 100
            return output_path
        except Exception as e:
            self.log(f"M3U8下载失败: {e}")
            return None
