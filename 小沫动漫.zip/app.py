from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit
import json
import eventlet
import threading
import time
import os
import sys
import requests

# Monkey patch for eventlet if used, but we'll try threading mode first for simplicity on Windows
# eventlet.monkey_patch() 

from gir import GirigiriAnimeSource
from fantu import FanTuanSource
from omofun import OmoFunSource
from yhdm import YhdmSource
from xifan import XifanSource
from task_manager import TaskManager
from settings_manager import SettingsManager
from shopping_cart_manager import ShoppingCartManager
from library_manager import LibraryManager
from auto_update_manager import AutoUpdateManager

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
# Use threading for Windows compatibility and simple background tasks
socketio = SocketIO(app, async_mode='threading')

settings_manager = SettingsManager()
task_manager = TaskManager(settings_manager)
cart_manager = ShoppingCartManager()
library_manager = LibraryManager(settings_manager)
auto_update_manager = AutoUpdateManager()

# Ensure log directory exists
LOG_DIR = "logs"
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)
LOG_FILE = os.path.join(LOG_DIR, "app.log")

def log_to_file(msg):
    try:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] {msg}\n")
    except Exception as e:
        print(f"Logging failed: {e}")

def log_callback(msg):
    print(f"Log: {msg}")
    log_to_file(msg)
    socketio.emit('log', {'message': msg})

def progress_callback(current, total, desc):
    socketio.emit('progress', {'current': current, 'total': total, 'desc': desc})

# Initialize sources with callbacks
sources = {
    'girigiri': GirigiriAnimeSource(log_callback=log_callback, progress_callback=progress_callback),
    'fantu': FanTuanSource(log_callback=log_callback, progress_callback=progress_callback),
    'omofun': OmoFunSource(log_callback=log_callback, progress_callback=progress_callback),
    'yhdm': YhdmSource(log_callback=log_callback, progress_callback=progress_callback),
    'xifan': XifanSource(log_callback=log_callback, progress_callback=progress_callback)
}

# Update download folder and threads from settings for all sources
for source in sources.values():
    source.download_folder = settings_manager.get("download_folder") or "downloads"
    source.max_threads = int(settings_manager.get("max_threads") or 10)

# Default source helper
def get_source(name='girigiri'):
    return sources.get(name, sources['girigiri'])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/search', methods=['POST'])
def search():
    keyword = request.form.get('keyword')
    source_name = request.form.get('source', 'girigiri')
    
    if not keyword:
        return jsonify([])
        
    source = get_source(source_name)
    results = source.search_anime(keyword)
    return jsonify(results)

@app.route('/api/episodes', methods=['POST'])
def episodes():
    url = request.form.get('url')
    source_name = request.form.get('source', 'girigiri') # Try to get source
    
    # If source is not passed explicitly, we might need to guess or rely on frontend passing it
    # Frontend should pass it.
    
    if not url:
        return jsonify([])
        
    source = get_source(source_name)
    data = source.get_episodes(url)
    
    # Handle dict response (with sources info) or legacy list
    ep_list = []
    if isinstance(data, dict) and 'episodes' in data:
        ep_list = data['episodes']
    elif isinstance(data, list):
        ep_list = data
    
    # Enrich episodes with download status
    anime_name = request.form.get('anime_name') # Need to pass anime name now
    if anime_name and anime_name != 'undefined':
        for ep in ep_list:
            ep['downloaded'] = source.is_downloaded(anime_name, ep['name'])
            
    return jsonify(data)

@app.route('/api/cart', methods=['GET'])
def get_cart():
    return jsonify(cart_manager.get_all())

@app.route('/api/cart/add', methods=['POST'])
def add_to_cart():
    anime_name = request.form.get('anime_name')
    url = request.form.get('url')
    source_name = request.form.get('source', 'girigiri')
    episode_json = request.form.get('episode') # Optional single episode
    cover = request.form.get('cover', '')
    
    episodes = None
    if episode_json:
        try:
            episodes = [json.loads(episode_json)]
        except:
            pass

    if cart_manager.add_anime(anime_name, url, episodes, source_name, cover):
        msg = f'已加入清单: {anime_name}'
        if episodes:
            msg += f" ({episodes[0]['name']})"
        return jsonify({'status': 'success', 'message': msg})
    return jsonify({'status': 'error', 'message': '添加失败'})

@app.route('/api/cart/remove', methods=['POST'])
def remove_from_cart():
    anime_name = request.form.get('anime_name')
    episode_name = request.form.get('episode_name') # Optional
    
    if episode_name:
        if cart_manager.remove_episode(anime_name, episode_name):
            return jsonify({'status': 'success', 'message': '剧集已移除'})
        return jsonify({'status': 'error', 'message': '剧集移除失败'})
        
    if cart_manager.remove_anime(anime_name):
        return jsonify({'status': 'success', 'message': '已移除'})
    return jsonify({'status': 'error', 'message': '移除失败'})

@app.route('/api/cart/download', methods=['POST'])
def download_cart_item():
    anime_name = request.form.get('anime_name')
    return _process_cart_item_download(anime_name)

@app.route('/api/cart/download_all', methods=['POST'])
def download_all_cart():
    items = cart_manager.get_all()
    if not items:
        return jsonify({'status': 'error', 'message': '清单为空'})
    
    count = 0
    errors = []
    
    for item in items:
        try:
            # Re-use logic but don't return immediately
            # We can't use _process_cart_item_download directly because it returns a Response object
            # So we refactor logic or call internal helper
            anime_name = item['anime_name']
            source_name = item.get('source', 'girigiri')
            source = get_source(source_name)
            
            # Fetch episodes if needed
            episodes = item.get('episodes')
            if not episodes:
                episodes = source.get_episodes(item['url'])
                cart_manager.update_episodes(anime_name, episodes)
            
            if episodes:
                for ep in episodes:
                    if not source.is_downloaded(anime_name, ep['name']):
                        task_manager.add_task(anime_name, ep['name'], ep['url'], source)
                
                cart_manager.remove_anime(anime_name)
                count += 1
            else:
                errors.append(f"{anime_name}: 未找到剧集")
                
        except Exception as e:
            errors.append(f"{anime_name}: {str(e)}")
            
    msg = f"已将 {count} 个番剧加入下载队列"
    if errors:
        msg += f"\n失败: {len(errors)} 个"
        
    return jsonify({'status': 'success', 'message': msg})

def _process_cart_item_download(anime_name):
    # Find item
    items = cart_manager.get_all()
    item = next((i for i in items if i['anime_name'] == anime_name), None)
    
    if not item:
        return jsonify({'status': 'error', 'message': '番剧不在清单中'})
        
    source_name = item.get('source', 'girigiri')
    source = get_source(source_name)
    
    # If episodes not cached, fetch them
    episodes = item.get('episodes')
    if not episodes:
        try:
            episodes = source.get_episodes(item['url'])
            cart_manager.update_episodes(anime_name, episodes)
        except Exception as e:
            return jsonify({'status': 'error', 'message': f'获取剧集失败: {str(e)}'})
            
    # Add to download queue
    count = 0
    for ep in episodes:
        if not source.is_downloaded(anime_name, ep['name']):
            task_manager.add_task(anime_name, ep['name'], ep['url'], source)
            count += 1
            
    cart_manager.remove_anime(anime_name)
    
    return jsonify({'status': 'success', 'message': f'已将 {anime_name} ({count}集) 加入下载队列'})

# Library API
@app.route('/api/library', methods=['GET'])
def get_library():
    data = {
        'anime_list': library_manager.get_anime_list(),
        'storage_stats': library_manager.get_storage_stats()
    }
    return jsonify(data)

@app.route('/api/library/<anime_name>', methods=['GET'])
def get_library_episodes(anime_name):
    return jsonify(library_manager.get_episodes(anime_name))

@app.route('/api/library/delete_anime', methods=['POST'])
def library_delete_anime():
    anime_name = request.form.get('anime_name')
    anime_names = request.form.getlist('anime_names[]')
    
    if anime_names:
        results = library_manager.batch_delete_anime(anime_names)
        success_count = len(results['success'])
        fail_count = len(results['failed'])
        return jsonify({
            'status': 'success', 
            'message': f'已删除 {success_count} 个番剧' + (f'，{fail_count} 个失败' if fail_count > 0 else ''),
            'results': results
        })
    elif anime_name:
        if library_manager.delete_anime(anime_name):
            return jsonify({'status': 'success', 'message': '番剧已删除'})
        return jsonify({'status': 'error', 'message': '删除失败'})
    
    return jsonify({'status': 'error', 'message': '未指定番剧'})

@app.route('/api/library/delete_episode', methods=['POST'])
def library_delete_episode():
    anime_name = request.form.get('anime_name')
    episode_name = request.form.get('episode_name')
    if library_manager.delete_episode(anime_name, episode_name):
        return jsonify({'status': 'success', 'message': '剧集已删除'})
    return jsonify({'status': 'error', 'message': '删除失败'})

from flask import send_from_directory
@app.route('/api/library/video/<path:filepath>')
def serve_video(filepath):
    # Security check: ensure path is within download folder
    download_folder = os.path.abspath(settings_manager.get("download_folder", "downloads"))
    full_path = os.path.abspath(os.path.join(download_folder, filepath))
    
    if not full_path.startswith(download_folder):
        return "Access denied", 403
        
    directory = os.path.dirname(full_path)
    filename = os.path.basename(full_path)
    return send_from_directory(directory, filename)

# Auto Update API
@app.route('/api/auto_update/list', methods=['GET'])
def auto_update_list():
    return jsonify(auto_update_manager.get_all())

@app.route('/api/auto_update/add', methods=['POST'])
def auto_update_add():
    anime_name = request.form.get('anime_name')
    url = request.form.get('url')
    source_name = request.form.get('source', 'girigiri')
    status = request.form.get('status', 'waiting')
    update_info = request.form.get('update_info', '')
    cover = request.form.get('cover', '')
    
    # Ensure source_name is valid or default
    if not source_name or source_name == 'undefined':
        source_name = 'girigiri'
        
    if auto_update_manager.add_anime(anime_name, url, source_name, status, update_info, cover):
        return jsonify({'status': 'success', 'message': f'已加入预更新: {anime_name}'})
    return jsonify({'status': 'error', 'message': '已存在 (已更新信息)'})

@app.route('/api/auto_update/remove', methods=['POST'])
def auto_update_remove():
    anime_name = request.form.get('anime_name')
    anime_names = request.form.getlist('anime_names[]')
    
    if anime_names:
        if auto_update_manager.batch_remove_anime(anime_names):
            return jsonify({'status': 'success', 'message': f'已批量移除 {len(anime_names)} 个番剧'})
        return jsonify({'status': 'error', 'message': '批量移除失败'})
    elif anime_name:
        if auto_update_manager.remove_anime(anime_name):
            return jsonify({'status': 'success', 'message': '已移除'})
        return jsonify({'status': 'error', 'message': '移除失败'})
    
    return jsonify({'status': 'error', 'message': '未指定番剧'})

@app.route('/api/auto_update/check_all', methods=['POST'])
def auto_update_check_all():
    threading.Thread(target=run_auto_update_check, args=(True,)).start()
    return jsonify({'status': 'started', 'message': '开始检查所有预更新番剧...'})

@app.route('/api/auto_update/check_single', methods=['POST'])
def auto_update_check_single():
    anime_name = request.form.get('anime_name')
    # Find item
    items = auto_update_manager.get_all()
    item = next((i for i in items if i['anime_name'] == anime_name), None)
    if item:
        threading.Thread(target=check_single_anime_update, args=(item,)).start()
        return jsonify({'status': 'started', 'message': f'开始检查: {anime_name}'})
    return jsonify({'status': 'error', 'message': '未找到番剧'})

def check_single_anime_update(item):
    anime_name = item['anime_name']
    url = item['url']
    source_name = item.get('source', 'girigiri')
    source = get_source(source_name)
    
    auto_update_manager.update_item_status(anime_name, 'checking')
    try:
        episodes = source.get_episodes(url)
        
        # Compatibility fix for sources returning dict (e.g. omofun, yhdm)
        if isinstance(episodes, dict) and 'episodes' in episodes:
            episodes = episodes['episodes']
            
        new_count = 0
        for ep in episodes:
            if not source.is_downloaded(anime_name, ep['name']):
                # Double check task manager to avoid duplicates in queue
                # TaskManager.add_task handles deduplication, so it's safe
                task_manager.add_task(anime_name, ep['name'], ep['url'], source)
                new_count += 1
        
        status = f'updated_new_{new_count}' if new_count > 0 else 'updated_no_new'
        auto_update_manager.update_item_status(anime_name, status, time.time())
        print(f"Auto-update checked {anime_name}: Found {new_count} new episodes")
        
    except Exception as e:
        print(f"Auto-update failed for {anime_name}: {e}")
        auto_update_manager.update_item_status(anime_name, 'failed')

def run_auto_update_check(force=False):
    items = auto_update_manager.get_all()
    print(f"Starting auto-update check for {len(items)} items (Force: {force})")
    
    # Get interval from settings (default 24 hours), convert to seconds
    interval_hours = float(settings_manager.get('auto_update_interval', 24))
    interval_seconds = interval_hours * 3600
    
    for item in items:
        # Check interval
        if force or (time.time() - item.get('last_checked', 0) > interval_seconds):
            check_single_anime_update(item)
            # Add small delay to be nice to the server
            time.sleep(2)

@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    # Return grouped tasks structure for frontend
    all_tasks = task_manager.get_all_tasks()
    grouped = {}
    for task in all_tasks:
        anime = task['anime_name']
        if anime not in grouped:
            grouped[anime] = []
        grouped[anime].append(task)
    return jsonify(grouped)

@app.route('/api/settings', methods=['GET', 'POST'])
def settings():
    if request.method == 'POST':
        data = request.json
        settings_manager.update(data)
        # Apply relevant settings immediately
        if "download_folder" in data:
            source.download_folder = data["download_folder"]
        if "max_threads" in data:
            source.max_threads = int(data["max_threads"])
        return jsonify({'status': 'success', 'message': '设置已保存'})
    return jsonify(settings_manager.settings)

@app.route('/api/settings/temp_clean', methods=['GET', 'POST'])
def temp_clean():
    temp_path = os.path.join(source.download_folder, "temp")
    
    if request.method == 'GET':
        size = 0
        if os.path.exists(temp_path):
            for root, dirs, files in os.walk(temp_path):
                for f in files:
                    fp = os.path.join(root, f)
                    try: size += os.path.getsize(fp)
                    except: pass
        
        # Format size
        if size < 1024: size_str = f"{size} B"
        elif size < 1024*1024: size_str = f"{size/1024:.2f} KB"
        elif size < 1024*1024*1024: size_str = f"{size/1024/1024:.2f} MB"
        else: size_str = f"{size/1024/1024/1024:.2f} GB"
        
        return jsonify({'size': size, 'size_str': size_str})
        
    elif request.method == 'POST':
        try:
            import shutil
            if os.path.exists(temp_path):
                shutil.rmtree(temp_path)
                os.makedirs(temp_path)
            return jsonify({'status': 'success', 'message': '临时文件已清理'})
        except Exception as e:
            return jsonify({'status': 'error', 'message': f'清理失败: {str(e)}'})

@app.route('/api/settings/logs_clean', methods=['GET', 'POST'])
def logs_clean():
    if request.method == 'GET':
        size = 0
        if os.path.exists(LOG_DIR):
            for root, dirs, files in os.walk(LOG_DIR):
                for f in files:
                    # Skip history files
                    if f == "download_history.json" or f.startswith("download_report_"):
                        continue
                    fp = os.path.join(root, f)
                    try: size += os.path.getsize(fp)
                    except: pass
        
        # Format size
        if size < 1024: size_str = f"{size} B"
        elif size < 1024*1024: size_str = f"{size/1024:.2f} KB"
        elif size < 1024*1024*1024: size_str = f"{size/1024/1024:.2f} MB"
        else: size_str = f"{size/1024/1024/1024:.2f} GB"
        
        return jsonify({'size': size, 'size_str': size_str})
        
    elif request.method == 'POST':
        try:
            import shutil
            # Don't remove directory, just files, to keep permissions/existence
            # And PRESERVE download_history.json
            if os.path.exists(LOG_DIR):
                for f in os.listdir(LOG_DIR):
                    # Protect history and report files
                    if f == "download_history.json" or f.startswith("download_report_"):
                        continue
                        
                    fp = os.path.join(LOG_DIR, f)
                    try:
                        if os.path.isfile(fp):
                            os.unlink(fp)
                    except Exception as e:
                        print(f"Failed to delete {fp}: {e}")
            return jsonify({'status': 'success', 'message': '日志文件已清理 (保留下载记录)'})
        except Exception as e:
            return jsonify({'status': 'error', 'message': f'清理失败: {str(e)}'})

@app.route('/api/settings/restart', methods=['POST'])
def restart_app():
    def restart():
        time.sleep(1) # Give time for response to be sent
        print("Restarting application...")
        python = sys.executable
        os.execl(python, python, *sys.argv)
        
    threading.Thread(target=restart).start()
    return jsonify({'status': 'success', 'message': '程序正在重启...'})

@app.route('/api/settings/clean_empty_folders', methods=['POST'])
def clean_empty_folders():
    try:
        download_folder = settings_manager.get("download_folder", "downloads")
        if not os.path.exists(download_folder):
             return jsonify({'status': 'error', 'message': '下载目录不存在'})
             
        deleted_count = 0
        # Walk bottom-up so we can delete nested empty folders
        for root, dirs, files in os.walk(download_folder, topdown=False):
            for name in dirs:
                path = os.path.join(root, name)
                try:
                    # Check if empty
                    if not os.listdir(path):
                        os.rmdir(path)
                        deleted_count += 1
                except Exception as e:
                    print(f"Failed to delete empty folder {path}: {e}")
                    
        return jsonify({'status': 'success', 'message': f'已清理 {deleted_count} 个空文件夹'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'清理失败: {str(e)}'})

@app.route('/api/resolve_video', methods=['POST'])
def resolve_video():
    try:
        episode_url = request.form.get('episode_url')
        source_name = request.form.get('source', 'girigiri')
        
        if not episode_url:
            return jsonify({'status': 'error', 'message': 'Missing episode_url'})
            
        source = get_source(source_name)
        video_url = source.get_video_url(episode_url)
        
        if not video_url:
            return jsonify({'status': 'error', 'message': '无法解析视频地址'})
            
        if not isinstance(video_url, str):
            video_url = str(video_url)
            
        # Check if it's an M3U8
        is_m3u8 = '.m3u8' in video_url or 'type=m3u8' in video_url
        
        return jsonify({
            'status': 'success', 
            'url': video_url, 
            'type': 'm3u8' if is_m3u8 else 'mp4',
            'proxy_url': f"/api/proxy?url={requests.utils.quote(video_url)}&source={source_name}"
        })
    except Exception as e:
        print(f"Resolve video error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'status': 'error', 'message': f'Server Error: {str(e)}'}), 500

@app.route('/api/proxy', methods=['GET'])
def proxy_stream():
    url = request.args.get('url')
    source_name = request.args.get('source', 'girigiri')
    
    if not url: return "Missing URL", 400
    
    source = get_source(source_name)
    
    try:
        # Check for Range header
        client_headers = {}
        if 'Range' in request.headers:
            client_headers['Range'] = request.headers['Range']
            
        # Strategies for Referer to handle anti-hotlinking
        strategies = [
            ("Default", {}),
            ("No Referer", {"Referer": None}),
            ("Self Referer", {"Referer": url})
        ]
        
        resp = None
        last_error = None
        
        for strategy_name, strategy_headers in strategies:
            try:
                # Merge client headers (Range) with strategy headers
                req_headers = client_headers.copy()
                req_headers.update(strategy_headers)
                
                # print(f"Proxy trying strategy: {strategy_name} for {url}")
                current_resp = source.session.get(url, stream=True, timeout=10, headers=req_headers)
                
                if current_resp.status_code in [200, 206]:
                    resp = current_resp
                    break
                else:
                    current_resp.close()
                    last_error = f"Status {current_resp.status_code}"
                    # print(f"Strategy {strategy_name} failed: {current_resp.status_code}")
            except Exception as e:
                last_error = str(e)
                continue
        
        if not resp:
            return f"Proxy failed after strategies: {last_error}", 500
        
        # If m3u8, we might need to rewrite it.
        content_type = resp.headers.get('Content-Type', '')
        if 'mpegurl' in content_type or url.endswith('.m3u8'):
             # Read content
             content = resp.text
             # Rewrite URIs
             # We need to make sure relative URLs become absolute to the proxy
             # Base URI is the m3u8 url
             from urllib.parse import urljoin
             base_uri = url
             
             new_lines = []
             for line in content.splitlines():
                 if line.strip() and not line.startswith('#'):
                     # It's a URI
                     abs_uri = urljoin(base_uri, line.strip())
                     # Encode for proxy
                     proxy_uri = f"/api/proxy?url={requests.utils.quote(abs_uri)}&source={source_name}"
                     new_lines.append(proxy_uri)
                 else:
                     new_lines.append(line)
             
             return "\n".join(new_lines), 200, {'Content-Type': 'application/vnd.apple.mpegurl'}
        
        # For TS or other binary, stream it
        from flask import Response
        
        # Filter headers to forward
        excluded_headers = ['content-encoding', 'content-length', 'transfer-encoding', 'connection']
        headers = [(name, value) for (name, value) in resp.headers.items()
                   if name.lower() not in excluded_headers]
        
        def generate():
            for chunk in resp.iter_content(chunk_size=8192):
                yield chunk
        
        response = Response(generate(), status=resp.status_code)
        
        # Forward headers
        for name, value in headers:
            response.headers[name] = value
            
        # Explicitly set Content-Length if available (and not compressed)
        if 'Content-Length' in resp.headers and 'Content-Encoding' not in resp.headers:
            response.headers['Content-Length'] = resp.headers['Content-Length']
            
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Accept-Ranges'] = 'bytes'
        
        return response
        
    except Exception as e:
        print(f"Proxy error: {e}")
        return f"Proxy error: {e}", 500

@app.route('/api/download_single', methods=['POST'])
def download_single():
    anime_name = request.form.get('anime_name')
    episode_url = request.form.get('episode_url')
    episode_name = request.form.get('episode_name')
    
    # We need to know the source.
    # Frontend should pass it, or we rely on the URL or some cache?
    # Best to pass it.
    # But currentAnime in frontend has source.
    # Let's check frontend call.
    
    # If frontend doesn't pass source, default to girigiri.
    # BUT wait, the currentAnime object in JS has source.
    # We should update JS to pass source.
    
    source_name = request.form.get('source', 'girigiri')
    source = get_source(source_name)
    
    task_id = task_manager.add_task(anime_name, episode_name, episode_url, source)
    return jsonify({'status': 'started', 'task_id': task_id, 'message': f'已添加到下载队列: {episode_name}'})

@app.route('/api/task/<task_id>/pause', methods=['POST'])
def pause_task(task_id):
    if task_manager.pause_task(task_id):
        return jsonify({'status': 'success', 'message': '任务已暂停'})
    return jsonify({'status': 'error', 'message': '任务不存在或无法暂停'})

@app.route('/api/task/<task_id>/resume', methods=['POST'])
def resume_task(task_id):
    if task_manager.resume_task(task_id):
        return jsonify({'status': 'success', 'message': '任务已继续'})
    return jsonify({'status': 'error', 'message': '任务不存在或无法继续'})

@app.route('/api/task/delete_anime', methods=['POST'])
def delete_anime():
    anime_name = request.form.get('anime_name')
    if task_manager.delete_anime(anime_name):
        return jsonify({'status': 'success', 'message': f'已删除番剧 {anime_name} 的所有任务'})
    return jsonify({'status': 'error', 'message': '删除失败或番剧不存在'})

@app.route('/api/task/pause_anime', methods=['POST'])
def pause_anime():
    anime_name = request.form.get('anime_name')
    count = task_manager.pause_anime(anime_name)
    return jsonify({'status': 'success', 'message': f'已暂停 {anime_name} 的 {count} 个任务'})

@app.route('/api/task/resume_anime', methods=['POST'])
def resume_anime():
    anime_name = request.form.get('anime_name')
    count = task_manager.resume_anime(anime_name)
    return jsonify({'status': 'success', 'message': f'已继续 {anime_name} 的 {count} 个任务'})

@app.route('/api/task/<task_id>/delete', methods=['POST'])
def delete_task(task_id):
    if task_manager.delete_task(task_id):
        return jsonify({'status': 'success', 'message': '任务已删除'})
    return jsonify({'status': 'error', 'message': '任务不存在'})

@app.route('/api/tasks/clear_completed', methods=['POST'])
def clear_completed_tasks():
    count = task_manager.clear_completed()
    return jsonify({'status': 'success', 'message': f'已清除 {count} 个已完成任务'})

@app.route('/api/tasks/delete_all', methods=['POST'])
def delete_all_tasks():
    count = task_manager.delete_all_tasks()
    return jsonify({'status': 'success', 'message': f'已删除所有任务 ({count} 个)'})

@app.route('/api/tasks/pause_all', methods=['POST'])
def pause_all_tasks():
    count = task_manager.pause_all()
    return jsonify({'status': 'success', 'message': f'已暂停 {count} 个任务'})

@app.route('/api/tasks/resume_all', methods=['POST'])
def resume_all_tasks():
    count = task_manager.resume_all()
    return jsonify({'status': 'success', 'message': f'已恢复 {count} 个任务'})

@app.route('/api/download_all', methods=['POST'])
def download_all():
    anime_name = request.form.get('anime_name')
    episodes_json = request.form.get('episodes')
    source_name = request.form.get('source', 'girigiri')
    
    source = get_source(source_name)
    
    try:
        episodes = json.loads(episodes_json)
    except:
        return jsonify({'status': 'error', 'message': 'Invalid episodes data'})
    
    count = 0
    for ep in episodes:
        # Skip downloaded
        if not source.is_downloaded(anime_name, ep['name']):
            task_manager.add_task(anime_name, ep['name'], ep['url'], source)
            count += 1
            
    return jsonify({'status': 'started', 'message': f'已添加 {count} 个任务到队列'})

# Periodic task update
def background_task_update():
    last_auto_check = 0
    while True:
        # Run scheduler
        task_manager.scheduler_step()
        
        # Auto Update Check (Every hour check if we need to run daily checks)
        # Actually run_auto_update_check handles per-item interval
        # So we can run it every hour or so.
        if time.time() - last_auto_check > 3600:
            threading.Thread(target=run_auto_update_check).start()
            last_auto_check = time.time()
        
        # Group tasks before emitting to match frontend expectation
        all_tasks = task_manager.get_all_tasks()
        grouped = {}
        for task in all_tasks:
            anime = task['anime_name']
            if anime not in grouped:
                grouped[anime] = []
            grouped[anime].append(task)
        socketio.emit('tasks_update', grouped)
        time.sleep(1)

threading.Thread(target=background_task_update, daemon=True).start()

if __name__ == '__main__':
    print("Starting server on http://localhost:5000")
    socketio.run(app, debug=True, host='0.0.0.0', port=5000, allow_unsafe_werkzeug=True)
