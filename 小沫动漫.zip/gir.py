import sys
import requests
import re
import os
import subprocess
import time
import json
import shutil
import traceback
from bs4 import BeautifulSoup
from urllib.parse import unquote
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

class GirigiriAnimeSource:
    def __init__(self, log_callback=None, progress_callback=None):
        self.base_url = "https://bgm.girigirilove.com"
        # 修改搜索URL增加结果数量到20
        self.search_url = "https://bgm.girigirilove.com/search/-------------/?wd={}&limit=20"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
            "Referer": self.base_url
        }
        self.cookies = {"quality": "1080P"}
        self.session = requests.Session()
        self.download_folder = "downloads"
        self.log_folder = "logs"
        self.download_history_file = os.path.join(self.log_folder, "download_history.json")
        
        self.log_callback = log_callback
        self.progress_callback = progress_callback
        
        self.max_threads = 10 # Default
        
        # 确保下载目录和日志目录存在
        if not os.path.exists(self.download_folder):
            os.makedirs(self.download_folder)
        if not os.path.exists(self.log_folder):
            os.makedirs(self.log_folder)
            
        self.download_history = self.load_download_history()

    def log(self, message):
        print(message)
        if self.log_callback:
            self.log_callback(message)

    def update_progress(self, current, total, desc=""):
        if self.progress_callback:
            self.progress_callback(current, total, desc)
            
    def load_download_history(self):
        """加载下载历史记录"""
        if os.path.exists(self.download_history_file):
            try:
                with open(self.download_history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
        
    def save_download_history(self):
        """保存下载历史记录"""
        with open(self.download_history_file, 'w', encoding='utf-8') as f:
            json.dump(self.download_history, f, ensure_ascii=False, indent=2)
            
    def is_downloaded(self, anime_name, episode_name):
        """检查剧集是否已下载"""
        key = f"{anime_name}||{episode_name}"
        if key not in self.download_history:
            return False
            
        record = self.download_history[key]
        # Some old records might not have 'path', handle that
        if 'path' in record and os.path.exists(record['path']):
            return True
            
        # File doesn't exist, remove from history
        del self.download_history[key]
        self.save_download_history()
        return False
        
    def search_anime(self, keyword):
        """搜索番剧（支持模糊匹配）"""
        keyword = keyword.strip()
        from urllib.parse import quote
        encoded_keyword = quote(keyword)
        
        url = self.search_url.format(encoded_keyword)
        try:
            response = self.session.get(url, headers=self.headers)
            response.raise_for_status()
            return self._parse_search_results(response.text)
        except Exception as e:
            self.log(f"搜索失败: {e}")
            return []

    def _parse_search_results(self, html):
        """解析搜索结果页面（更健壮的解析）"""
        soup = BeautifulSoup(html, 'html.parser')
        results = []
        
        containers = soup.select('.search-box, .search-list, .video-list')
        
        results = []
        for container in containers:
            titles = container.select('.thumb-txt, .video-name, .title, .name')
            links = container.select('.thumb-menu > a, .video-pic > a, a[href], .pic > a')
            
            if not titles or not links:
                titles = container.select('.title, .name, h3, h4, h5')
                links = container.select('a[href]')
            
            min_count = min(len(titles), len(links))
            for i in range(min_count):
                title_text = titles[i].get_text(strip=True)
                href = links[i].get('href', '')
                
                if href and not href.startswith('http'):
                    href = self.base_url + href
                
                results.append({
                    'name': title_text,
                    'url': href,
                    'source': 'girigiri'
                })
        
        if not results:
            self.log("⚠️ 使用备用解析方法...")
            items = soup.select('.video-item, .search-item, .item')
            for item in items:
                title_el = item.select_one('.title, .name, h3, h4, h5, a')
                link_el = item.select_one('a[href]')
                
                if title_el and link_el:
                    title_text = title_el.get_text(strip=True)
                    href = link_el['href']
                    if not href.startswith('http'):
                        href = self.base_url + href
                    results.append({
                        'name': title_text,
                        'url': href,
                        'source': 'girigiri'
                    })
            
            if not results:
                all_links = soup.select('a[href]')
                for link in all_links:
                    if '/detail/' in link['href'] or '/play/' in link['href'] or '/anime/' in link['href']:
                        title_text = link.get_text(strip=True)
                        if title_text and len(title_text) > 2:
                            href = link['href']
                            if not href.startswith('http'):
                                href = self.base_url + href
                            results.append({
                                'name': title_text,
                                'url': href,
                                'source': 'girigiri'
                            })
        
        return results[:20]

    def get_episodes(self, anime_url):
        """获取剧集列表"""
        try:
            response = self.session.get(anime_url, headers=self.headers)
            response.raise_for_status()
            return self._parse_episodes(response.text)
        except Exception as e:
            self.log(f"获取剧集失败: {e}")
            return []

    def _parse_episodes(self, html):
        """解析剧集信息，支持多线路选择（优先简中）"""
        soup = BeautifulSoup(html, 'html.parser')
        episodes = []
        
        line_tab = soup.select_one('.anthology-tab')
        line_containers = soup.select('.anthology-list-box')
        
        selected_container = None
        line_name = "默认线路"
        
        if line_tab and line_containers:
            line_tabs = line_tab.select('.swiper-slide')
            line_names = [tab.get_text(strip=True) for tab in line_tabs]
            
            selected_index = 0
            for i, name in enumerate(line_names):
                if "简中" in name:
                    selected_index = i
                    line_name = "简中"
                    break
                elif "繁中" in name:
                    selected_index = i
                    line_name = "繁中"
            
            if selected_index < len(line_containers):
                selected_container = line_containers[selected_index]
        
        if selected_container:
            for episode in selected_container.select('a'):
                name = episode.get_text(strip=True)
                ep_match = re.search(r'第\s*(\d+)\s*[话集]', name)
                ep_num = int(ep_match.group(1)) if ep_match else name
                
                formatted_name = f"第{ep_num}集" if isinstance(ep_num, int) else name
                
                episodes.append({
                    'name': formatted_name,
                    'original_name': name,
                    'episode': ep_num,
                    'url': self.base_url + episode['href'] if not episode['href'].startswith('http') else episode['href']
                })
        else:
            episode_lists = soup.select('.anthology-list-box')
            for container in episode_lists:
                for episode in container.select('a'):
                    name = episode.get_text(strip=True)
                    ep_match = re.search(r'第\s*(\d+)\s*[话集]', name)
                    ep_num = int(ep_match.group(1)) if ep_match else name
                    
                    formatted_name = f"第{ep_num}集" if isinstance(ep_num, int) else name
                    
                    episodes.append({
                        'name': formatted_name,
                        'original_name': name,
                        'episode': ep_num,
                        'url': self.base_url + episode['href'] if not episode['href'].startswith('http') else episode['href']
                    })
        
        self.log(f"自动选择线路: {line_name}")
        return episodes

    def get_video_url(self, episode_url):
        """深度分析网页结构获取视频地址"""
        self.log(f"分析网页结构: {episode_url}")
        
        try:
            response = self.session.get(
                episode_url,
                headers=self.headers,
                cookies=self.cookies
            )
            response.raise_for_status()
            html = response.text
        except Exception as e:
            self.log(f"获取页面失败: {e}")
            return None
        
        soup = BeautifulSoup(html, 'html.parser')
        iframe = soup.select_one('iframe')
        
        if iframe and 'src' in iframe.attrs:
            iframe_src = iframe['src']
            self.log(f"发现iframe: {iframe_src}")
            
            if 'url=' in iframe_src:
                url_match = re.search(r'[?&]url=([^&"]+)', iframe_src)
                if url_match:
                    video_url = unquote(url_match.group(1))
                    self.log(f"提取到视频URL: {video_url}")
                    return video_url
            
            if iframe_src.endswith('.m3u8') or iframe_src.endswith('.mp4'):
                self.log(f"直接提取到视频URL: {iframe_src}")
                return iframe_src
            
            self.log("尝试获取iframe内容")
            if not iframe_src.startswith('http'):
                iframe_src = self.base_url + iframe_src
            
            try:
                response = self.session.get(
                    iframe_src,
                    headers={**self.headers, "Referer": episode_url}
                )
                response.raise_for_status()
                iframe_html = response.text
                return self._analyze_video_source(iframe_html)
            except Exception as e:
                self.log(f"获取iframe内容失败: {e}")
        
        return self._analyze_video_source(html)
    
    def _analyze_video_source(self, html):
        """深度分析HTML结构寻找视频源"""
        self.log(f"开始分析HTML内容，长度: {len(html)}字符")
        
        self.log("尝试方法0: 提取JavaScript中的加密视频URL...")
        encrypted_url = self._extract_encrypted_url(html)
        if encrypted_url:
            self.log(f"找到加密视频URL: {encrypted_url}")
            return self.decrypt_video_url(encrypted_url)
        
        self.log("尝试方法1: 查找视频播放器配置...")
        player_config = self._extract_player_config(html)
        if player_config:
            self.log(f"找到播放器配置: {player_config}")
            return player_config
        
        self.log("尝试方法2: 查找m3u8链接...")
        m3u8_url = self._find_m3u8_url(html)
        if m3u8_url:
            self.log(f"找到m3u8链接: {m3u8_url}")
            return m3u8_url
        
        self.log("尝试方法3: 查找JavaScript变量...")
        js_url = self._find_js_video_url(html)
        if js_url:
            self.log(f"找到JS视频URL: {js_url}")
            return js_url
        
        self.log("尝试方法4: 查找视频标签...")
        video_tag_url = self._find_video_tag(html)
        if video_tag_url:
            self.log(f"找到视频标签: {video_tag_url}")
            return video_tag_url
        
        self.log("尝试方法5: 查找加密数据...")
        encrypted_data = self._find_encrypted_data(html)
        if encrypted_data:
            self.log(f"找到加密数据: {encrypted_data[:50]}...")
            return f"发现加密视频数据，可能需要解密: {encrypted_data[:50]}..."
        
        self.log("所有方法失败，保存HTML供分析")
        self._save_html_for_analysis(html)
        return None
        
    def _extract_encrypted_url(self, html):
        direct_match = re.search(r'var player_aaaa\s*=\s*{.*?"url"\s*:\s*"([^"]+)"', html, re.DOTALL)
        if direct_match:
            return direct_match.group(1)
        
        pattern = r'var player_aaaa\s*=\s*({[\s\S]*?});'
        match = re.search(pattern, html)
        if match:
            try:
                player_config = json.loads(match.group(1))
                return player_config.get('url')
            except json.JSONDecodeError:
                url_match = re.search(r'"url":\s*"([^"]+)"', match.group(1))
                if url_match:
                    return url_match.group(1)
        return None
    
    def _extract_player_config(self, html):
        patterns = [
            r'player\.setup\(({[\s\S]*?})\);',
            r'var\s+playerConfig\s*=\s*({[\s\S]*?});',
            r'videoConfig:\s*({[\s\S]*?})'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, html)
            if match:
                try:
                    config_str = match.group(1)
                    config = json.loads(config_str)
                    
                    if config.get('encrypt') == 2 and 'url' in config:
                        self.log("检测到加密视频地址，尝试解密...")
                        config['url'] = self.decrypt_video_url(config['url'])
                    
                    for key in ['url', 'source', 'file', 'sources']:
                        if key in config:
                            if isinstance(config[key], str):
                                return config[key]
                            elif isinstance(config[key], list) and config[key]:
                                return config[key][0].get('file', config[key][0].get('src'))
                    
                    if 'sources' in config and config['sources']:
                        return config['sources'][0].get('src', config['sources'][0].get('file'))
                    
                except json.JSONDecodeError:
                    url_match = re.search(r'["\'](https?://[^\'"]+\.m3u8[^\'"]*)["\']', config_str)
                    if url_match:
                        return url_match.group(1)
        
        return None
    
    def _find_m3u8_url(self, html):
        patterns = [
            r'(https?://[^\s"\']+?\.m3u8[^\s"\']*)',
            r'file:\s*["\'](https?://[^\'"]+\.m3u8[^\'"]*)["\']',
            r'var\s+video_url\s*=\s*["\'](https?://[^\'"]+\.m3u8[^\'"]*)["\']'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, html, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return None
    
    def _find_js_video_url(self, html):
        patterns = [
            r'var\s+[a-zA-Z0-9_]*?url\s*=\s*["\'](https?://[^\'"]+?\.m3u8[^\'"]*)["\']',
            r'video_src\s*=\s*["\'](https?://[^\'"]+?\.m3u8[^\'"]*)["\']',
            r'player\.load\(["\'](https?://[^\'"]+?\.m3u8[^\'"]*)["\']\)',
            r'\.src\s*=\s*["\'](https?://[^\'"]+?\.m3u8[^\'"]*)["\']',
            r'\.src\s*=\s*["\'](https?://[^\'"]+?\.mp4[^\'"]*)["\']',
            r'\.src\s*=\s*["\'](https?://[^\'"]+?\.flv[^\'"]*)["\']'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, html)
            if match:
                return match.group(1)
        
        return None
    
    def _find_video_tag(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        
        video_tag = soup.select_one('video')
        if video_tag:
            if video_tag.get('src'):
                return video_tag['src']
            
            source = video_tag.select_one('source')
            if source and source.get('src'):
                return source['src']
        
        iframe = soup.select_one('iframe')
        if iframe and iframe.get('src'):
            iframe_src = iframe['src']
            m3u8_match = re.search(r'url=([^&"]+\.m3u8)', iframe_src)
            if m3u8_match:
                return m3u8_match.group(1)
        
        return None
    
    def _find_encrypted_data(self, html):
        patterns = [
            r'var\s+encrypted\s*=\s*["\']([a-fA-F0-9]{32,})["\']',
            r'data:\s*["\']([a-zA-Z0-9+/=]{100,})["\']',
            r'window\.videoData\s*=\s*["\']([^\'"]{50,})["\']'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, html)
            if match:
                return match.group(1)
        
        return None
    
    def _save_html_for_analysis(self, html):
        try:
            with open('video_page_analysis.html', 'w', encoding='utf-8') as f:
                f.write(html)
            self.log("已保存HTML文件供进一步分析: video_page_analysis.html")
        except Exception as e:
            self.log(f"保存HTML文件失败: {e}")
            
    def decrypt_video_url(self, encrypted_url):
        import base64
        import urllib.parse
        
        try:
            url_decoded = urllib.parse.unquote(encrypted_url)
            base64_decoded = base64.b64decode(url_decoded).decode('utf-8')
            
            decoded = base64_decoded
            while '%' in decoded:
                new_decoded = urllib.parse.unquote(decoded)
                if new_decoded == decoded:
                    break
                decoded = new_decoded
            
            return decoded
        except Exception as e:
            self.log(f"❌ 解密视频地址失败: {e}")
            return encrypted_url

    def download_m3u8_with_task_control(self, m3u8_url, anime_name, episode_name, task=None):
        """下载m3u8视频并保存为MP4文件 - 支持任务控制"""
        anime_folder = os.path.join(self.download_folder, re.sub(r'[\\/*?:"<>|]', '', anime_name))
        if not os.path.exists(anime_folder):
            os.makedirs(anime_folder)
        
        ep_match = re.search(r'第\s*(\d+)\s*[话集]', episode_name)
        if ep_match:
            ep_num = int(ep_match.group(1))
            formatted_episode = f"第{ep_num}集"
        else:
            num_match = re.search(r'\d+', episode_name)
            if num_match:
                ep_num = int(num_match.group())
                formatted_episode = f"第{ep_num}集"
            else:
                formatted_episode = re.sub(r'[\\/*?:"<>|]', '', episode_name)
        
        output_path = os.path.join(anime_folder, f"{formatted_episode}.mp4")
        
        # 检查是否已下载（逻辑与download_m3u8相同，省略）
        if self.is_downloaded(anime_name, formatted_episode):
            self.log(f"⏭️ 已下载: {anime_name} - {formatted_episode}")
            return output_path
            
        if os.path.exists(output_path):
            self.log(f"⏭️ 文件已存在: {output_path}")
            self.download_history[f"{anime_name}||{formatted_episode}"] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            return output_path
        
        import m3u8
        try:
            self.log(f"正在获取m3u8播放列表: {m3u8_url}")
            response = self.session.get(m3u8_url, headers=self.headers, timeout=30)
            response.raise_for_status()
            
            playlist = m3u8.loads(response.text, uri=m3u8_url)
            
            segments = playlist.segments
            if not segments:
                self.log(f"❌ 无法获取视频分片列表: {m3u8_url}")
                return None
            self.log(f"成功获取播放列表，共 {len(segments)} 个分片")
        except Exception as e:
            self.log(f"❌ 解析m3u8文件失败: {e}")
            import traceback
            self.log(traceback.format_exc())
            return None
        
        safe_anime_name = re.sub(r'[\\/*?:"<>|\s]', '_', anime_name)
        safe_episode = re.sub(r'[\\/*?:"<>|\s]', '_', formatted_episode)
        temp_dir = os.path.join(self.download_folder, "temp", f"{safe_anime_name}_{safe_episode}")
        os.makedirs(temp_dir, exist_ok=True)
        
        total_segments = len(segments)
        if task:
            task.total = total_segments
            task.message = f"开始下载 {total_segments} 个分片"
        
        def download_segment(segment, index):
            # Task control check
            if task:
                task.pause_event.wait()
                if task.stop_event.is_set():
                    return False

            segment_url = segment.absolute_uri
            segment_path = os.path.join(temp_dir, f"segment_{index:04d}.ts")
            
            # Skip if already downloaded
            if os.path.exists(segment_path) and os.path.getsize(segment_path) > 0:
                return True

            for attempt in range(6):
                if task and task.stop_event.is_set(): return False
                try:
                    response = requests.get(segment_url, headers=self.headers, stream=True, timeout=30)
                    response.raise_for_status()
                    
                    content_length = int(response.headers.get('Content-Length', 0))
                    downloaded = 0
                    
                    with open(segment_path, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            if task and task.stop_event.is_set(): return False
                            if chunk:
                                f.write(chunk)
                                downloaded += len(chunk)
                                if task: task.update_bytes(len(chunk))
                    
                    if content_length > 0 and downloaded < content_length:
                        raise Exception(f"下载不完整: {downloaded}/{content_length}字节")
                    
                    return True
                except Exception as e:
                    # self.log(f"⚠️ 分片下载失败 (尝试 {attempt+1}/6): {segment_url} - {str(e)}")
                    time.sleep(2)
                    if os.path.exists(segment_path):
                        try:
                            os.remove(segment_path)
                        except: pass
            return False
        
        downloaded_count = 0
        failed_segments = []
        
        # Use ThreadPoolExecutor but check task status
        with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            futures = {executor.submit(download_segment, segment, i): (i, segment) for i, segment in enumerate(segments)}
            
            for future in as_completed(futures):
                if task and task.stop_event.is_set():
                    self.log("任务已停止，取消剩余下载")
                    break
                    
                idx, segment = futures[future]
                try:
                    success = future.result()
                    if success:
                        downloaded_count += 1
                    else:
                        failed_segments.append((idx, segment))
                except Exception as e:
                    failed_segments.append((idx, segment))
                    self.log(f"分片下载异常: {e}")
                finally:
                    if task:
                        task.progress = int((downloaded_count / total_segments) * 90) # Reserve 10% for merge
                        task.message = f"下载中: {downloaded_count}/{total_segments}"
        
        if task and task.stop_event.is_set():
            return None

        # Retry logic (simplified for brevity, can reuse existing logic or just fail)
        if failed_segments:
            self.log(f"⚠️ 有 {len(failed_segments)} 个分片下载失败，尝试重试...")
            for idx, segment in failed_segments:
                if task and task.stop_event.is_set(): break
                success = download_segment(segment, idx)
                if success:
                    downloaded_count += 1
                if task:
                    task.message = f"重试中: {downloaded_count}/{total_segments}"

        if downloaded_count < total_segments:
            self.log(f"❌ 最终下载失败: 仅下载 {downloaded_count}/{total_segments} 个分片")
            if task: task.message = "下载不完整"
            return None
        
        # Merge logic
        if task: task.message = "正在合并文件..."
        try:
            segment_list = os.path.join(temp_dir, "file_list.txt")
            with open(segment_list, 'w', encoding='utf-8') as f:
                for i in range(total_segments):
                    f.write(f"file 'segment_{i:04d}.ts'\n")
            
            abs_segment_list = os.path.abspath(segment_list)
            abs_output_path = os.path.abspath(output_path)
            
            merge_command = [
                "ffmpeg", "-f", "concat", "-safe", "0",
                "-i", abs_segment_list, "-c", "copy", abs_output_path
            ]
            
            process = subprocess.run(
                merge_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                encoding='utf-8', errors='ignore', timeout=600
            )
            
            if process.returncode != 0:
                self.log(f"❌ 合并失败: {process.stderr}")
                return None
                
            self.log(f"✅ 合并完成: {output_path}")
            
            # Cleanup
            try:
                shutil.rmtree(temp_dir, ignore_errors=True)
            except: pass
            
            # Save history
            self.download_history[f"{anime_name}||{formatted_episode}"] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            
            if task: task.progress = 100
            return output_path
            
        except Exception as e:
            self.log(f"❌ 合并异常: {e}")
            return None

    def download_m3u8(self, m3u8_url, anime_name, episode_name):
        """下载m3u8视频并保存为MP4文件 - 增强版多线程分片下载"""
        anime_folder = os.path.join(self.download_folder, re.sub(r'[\\/*?:"<>|]', '', anime_name))
        if not os.path.exists(anime_folder):
            os.makedirs(anime_folder)
        
        ep_match = re.search(r'第\s*(\d+)\s*[话集]', episode_name)
        if ep_match:
            ep_num = int(ep_match.group(1))
            formatted_episode = f"第{ep_num}集"
        else:
            num_match = re.search(r'\d+', episode_name)
            if num_match:
                ep_num = int(num_match.group())
                formatted_episode = f"第{ep_num}集"
            else:
                formatted_episode = re.sub(r'[\\/*?:"<>|]', '', episode_name)
        
        output_path = os.path.join(anime_folder, f"{formatted_episode}.mp4")
        
        if self.is_downloaded(anime_name, formatted_episode):
            self.log(f"⏭️ 已下载: {anime_name} - {formatted_episode}")
            self.update_progress(1, 1, f"{anime_name} - {formatted_episode} (已下载)")
            return output_path
            
        if os.path.exists(output_path):
            self.log(f"⏭️ 文件已存在: {output_path}")
            self.download_history[f"{anime_name}||{formatted_episode}"] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            self.update_progress(1, 1, f"{anime_name} - {formatted_episode} (已存在)")
            return output_path
        
        import m3u8
        try:
            self.log(f"正在获取m3u8播放列表: {m3u8_url}")
            # Use requests to fetch content with headers to avoid 403 Forbidden
            response = self.session.get(m3u8_url, headers=self.headers, timeout=30)
            response.raise_for_status()
            
            # Resolve relative URIs by setting base_uri
            playlist = m3u8.loads(response.text, uri=m3u8_url)
            
            segments = playlist.segments
            if not segments:
                self.log(f"❌ 无法获取视频分片列表: {m3u8_url}")
                return None
            self.log(f"成功获取播放列表，共 {len(segments)} 个分片")
        except Exception as e:
            self.log(f"❌ 解析m3u8文件失败: {e}")
            import traceback
            self.log(traceback.format_exc())
            return None
        
        safe_anime_name = re.sub(r'[\\/*?:"<>|\s]', '_', anime_name)
        safe_episode = re.sub(r'[\\/*?:"<>|\s]', '_', formatted_episode)
        temp_dir = os.path.join(self.download_folder, "temp", f"{safe_anime_name}_{safe_episode}")
        os.makedirs(temp_dir, exist_ok=True)
        self.log(f"📁 临时目录: {temp_dir}")
        
        total_segments = len(segments)
        self.update_progress(0, total_segments, f"开始下载 {anime_name} - {formatted_episode}")
        
        def download_segment(segment, index):
            segment_url = segment.absolute_uri
            segment_path = os.path.join(temp_dir, f"segment_{index:04d}.ts")
            
            for attempt in range(6):
                try:
                    response = requests.get(segment_url, headers=self.headers, stream=True, timeout=30)
                    response.raise_for_status()
                    
                    content_length = int(response.headers.get('Content-Length', 0))
                    downloaded = 0
                    
                    with open(segment_path, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                                downloaded += len(chunk)
                    
                    if content_length > 0 and downloaded < content_length:
                        raise Exception(f"下载不完整: {downloaded}/{content_length}字节")
                    
                    return True
                except Exception as e:
                    # self.log(f"⚠️ 分片下载失败 (尝试 {attempt+1}/6): {segment_url} - {str(e)}")
                    time.sleep(2)
                    if os.path.exists(segment_path):
                        os.remove(segment_path)
            return False
        
        downloaded_count = 0
        failed_segments = []
        
        with ThreadPoolExecutor(max_workers=50) as executor:
            futures = {executor.submit(download_segment, segment, i): (i, segment) for i, segment in enumerate(segments)}
            
            for future in as_completed(futures):
                idx, segment = futures[future]
                try:
                    success = future.result()
                    if success:
                        downloaded_count += 1
                    else:
                        failed_segments.append((idx, segment))
                except Exception as e:
                    failed_segments.append((idx, segment))
                    self.log(f"❌ 分片下载异常: {e}")
                finally:
                    self.update_progress(downloaded_count, total_segments, f"下载中 {downloaded_count}/{total_segments}")
        
        if failed_segments:
            self.log(f"⚠️ 有 {len(failed_segments)} 个分片下载失败，正在重试...")
            
            for idx, segment in failed_segments:
                success = download_segment(segment, idx)
                if success:
                    downloaded_count += 1
                self.update_progress(downloaded_count, total_segments, f"重试中 {downloaded_count}/{total_segments}")
            
        if downloaded_count < total_segments:
            self.log(f"❌ 最终下载失败: 仅下载 {downloaded_count}/{total_segments} 个分片")
            shutil.rmtree(temp_dir, ignore_errors=True)
            return None
        
        try:
            segment_list = os.path.join(temp_dir, "file_list.txt")
            with open(segment_list, 'w', encoding='utf-8') as f:
                for i in range(total_segments):
                    f.write(f"file 'segment_{i:04d}.ts'\n")
            
            abs_segment_list = os.path.abspath(segment_list)
            abs_output_path = os.path.abspath(output_path)
            
            # Check for ffmpeg
            import subprocess
            ffmpeg_cmd = "ffmpeg"
            try:
                subprocess.run([ffmpeg_cmd, "-version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            except (subprocess.CalledProcessError, FileNotFoundError):
                # Fallback
                if os.name == 'posix':
                    if os.path.exists("/usr/bin/ffmpeg"): ffmpeg_cmd = "/usr/bin/ffmpeg"
                    elif os.path.exists("/usr/local/bin/ffmpeg"): ffmpeg_cmd = "/usr/local/bin/ffmpeg"
                elif os.name == 'nt':
                    if os.path.exists("ffmpeg.exe"): ffmpeg_cmd = "ffmpeg.exe"
            
            merge_command = [
                ffmpeg_cmd,
                "-f", "concat",
                "-safe", "0",
                "-i", abs_segment_list,
                "-c", "copy",
                abs_output_path
            ]
            
            self.log(f"🔄 合并命令: {' '.join(merge_command)}")
            self.update_progress(total_segments, total_segments, "正在合并文件...")
            
            try:
                process = subprocess.run(
                    merge_command, 
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    encoding='utf-8',
                    errors='ignore',
                    timeout=600
                )
                
                if process.returncode != 0:
                    error_log = os.path.join(temp_dir, "merge_error.log")
                    with open(error_log, 'w', encoding='utf-8') as f:
                        f.write(process.stderr)
                    self.log(f"❌ 合并分片失败，错误日志已保存: {error_log}")
                    return None
            except subprocess.TimeoutExpired:
                self.log("⏱️ 合并操作超时")
                return None
            except Exception as e:
                self.log(f"❌ 合并分片时发生异常: {str(e)}")
                return None
            
            self.log(f"✅ 合并完成: {output_path}")
        except Exception as e:
            self.log(f"❌ 合并分片时出错: {e}")
            return None
        finally:
            try:
                self.log(f"🧹 清理临时目录: {temp_dir}")
                shutil.rmtree(temp_dir, ignore_errors=True)
            except Exception as e:
                self.log(f"❌ 清理临时目录失败: {e}")
        
        self.download_history[f"{anime_name}||{formatted_episode}"] = {
            "path": output_path,
            "time": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        self.save_download_history()
        
        self.log(f"✅ 下载完成: {output_path}")
        return output_path

    def download_single_episode(self, anime_name, episode_url, episode_name):
        """下载单集视频"""
        if self.is_downloaded(anime_name, episode_name):
            self.log(f"⏭️ 已下载: {anime_name} - {episode_name}")
            return None
        
        video_url = self.get_video_url(episode_url)
        if not video_url:
            self.log(f"❌ 无法获取视频地址: {episode_name}")
            return None
        
        return self.download_m3u8(video_url, anime_name, episode_name)

    def download_all_episodes(self, anime_name, episodes):
        """下载所有剧集（顺序下载）"""
        self.log(f"⏬ 开始下载全季: {anime_name} ({len(episodes)}集)")
        self.log("注意: 下载需要时间，请耐心等待...")
        self.log("模式: 顺序下载（1集1集下载）")
        
        report = {
            "anime": anime_name,
            "total_episodes": len(episodes),
            "downloaded": [],
            "failed": [],
            "skipped": [],
            "start_time": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        
        for i, episode in enumerate(episodes):
            if self.is_downloaded(anime_name, episode['name']):
                report["skipped"].append(episode)
                self.log(f"⏭️ 跳过: {episode['name']} (已下载)")
                continue
                
            self.log(f"\n⏬ 开始下载: {anime_name} - {episode['name']}")
            try:
                download_path = self.download_single_episode(
                    anime_name,
                    episode['url'],
                    episode['name']
                )
                
                if download_path:
                    report["downloaded"].append({
                        "episode": episode,
                        "path": download_path
                    })
                    self.log(f"✅ 下载完成: {episode['name']}")
                else:
                    report["failed"].append(episode)
                    self.log(f"❌ 下载失败: {episode['name']}")
            except Exception as e:
                report["failed"].append(episode)
                self.log(f"❌ 下载异常: {episode['name']} - {e}")
            
            self.log(f"\n当前进度: 成功 {len(report['downloaded'])}集, 失败 {len(report['failed'])}集, 跳过 {len(report['skipped'])}集")
        
        report["end_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
        report["duration"] = time.time() - time.mktime(time.strptime(report["start_time"], "%Y-%m-%d %H:%M:%S"))
        
        report_filename = f"download_report_{anime_name}_{time.strftime('%Y%m%d%H%M%S')}.json"
        report_path = os.path.join(self.log_folder, report_filename)
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        self.log("\n" + "="*50)
        self.log(f"✅ 全季下载完成! {anime_name}")
        self.log(f"总剧集: {report['total_episodes']}")
        self.log(f"成功下载: {len(report['downloaded'])}")
        self.log(f"跳过: {len(report['skipped'])}")
        self.log(f"失败: {len(report['failed'])}")
        self.log(f"耗时: {report['duration']:.2f}秒")
        
        safe_anime_name = re.sub(r'[\\/*?:"<>|]', '', anime_name)
        save_path = os.path.join(self.download_folder, safe_anime_name)
        self.log(f"文件保存在: {save_path}")
        self.log(f"下载报告已保存: {report_path}")
        self.log("="*50)
        
        return report

if __name__ == "__main__":
    print("This module is now adapted for web usage. Run app.py instead.")
