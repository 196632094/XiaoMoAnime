import re
import json
import requests
import urllib.parse
from bs4 import BeautifulSoup
from urllib.parse import urljoin

class Ezdm:
    def __init__(self, log_callback=None, progress_callback=None):
        self.base_url = "https://m.ezdmw.site"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Referer": "https://m.ezdmw.site/"
        }
        self.log_callback = log_callback
        self.progress_callback = progress_callback
        self.download_folder = "downloads"
        self.max_threads = 10

    def log(self, message):
        if self.log_callback:
            self.log_callback(f"[Ezdm] {message}")
        else:
            print(f"[Ezdm] {message}")

    def is_downloaded(self, anime_name, episode_name):
        # Basic check (can be improved)
        import os
        path = os.path.join(self.download_folder, anime_name, f"{episode_name}.mp4")
        return os.path.exists(path)

    def search_anime(self, keyword):
        try:
            search_url = f"{self.base_url}/Index/search.html"
            params = {'searchText': keyword}
            self.log(f"Searching: {search_url} params={params}")
            
            resp = requests.get(search_url, params=params, headers=self.headers, verify=False)
            resp.encoding = 'utf-8'
            
            soup = BeautifulSoup(resp.text, 'html.parser')
            results = []
            
            # Based on analysis: items are in <li> tags
            # <li>
            #  <a href="/show/51412.html">
            #   <img alt="Title" src="..."/>
            #  </a>
            #  <h2><a ...>Title</a></h2>
            # </li>
            
            items = soup.select('li')
            for item in items:
                link = item.select_one('a')
                if not link:
                    continue
                    
                url = link.get('href')
                if not url:
                    continue
                
                # Full URL
                if not url.startswith('http'):
                    url = urljoin(self.base_url, url)
                
                # Rewrite URL if it contains /show/
                # Search results return /show/ID.html but actual detail page is /Index/bangumi/ID.html
                if '/show/' in url:
                    url = url.replace('/show/', '/Index/bangumi/')
                    
                # Title
                title = ""
                h2 = item.select_one('h2 a')
                if h2:
                    title = h2.get_text(strip=True)
                elif link.get('title'):
                    title = link.get('title')
                else:
                    # Try image alt
                    img = link.select_one('img')
                    if img and img.get('alt'):
                        title = img.get('alt')
                
                if not title:
                    continue
                    
                # Cover
                cover = ""
                img = item.select_one('img')
                if img:
                    cover = img.get('src')
                    if cover and not cover.startswith('http'):
                        cover = urljoin(self.base_url, cover)
                
                # Status/Update info (not easily visible in search results based on analysis, but maybe in text)
                # We'll leave status as unknown or ongoing
                status = "ongoing"
                update_info = ""
                
                results.append({
                    "name": title,
                    "url": url,
                    "cover": cover,
                    "source": "ezdm",
                    "status": status,
                    "update_info": update_info
                })
            
            return results
            
        except Exception as e:
            self.log(f"Search failed: {e}")
            return []

    def get_episodes(self, anime_url):
        try:
            self.log(f"Fetching episodes: {anime_url}")
            resp = requests.get(anime_url, headers=self.headers, verify=False)
            resp.encoding = 'utf-8'
            soup = BeautifulSoup(resp.text, 'html.parser')
            
            all_sources = []
            
            # Strategy 1: .anthology container
            # Usually these correspond to different tabs/sources
            anthology_divs = soup.select('.anthology')
            
            if anthology_divs:
                for idx, anth in enumerate(anthology_divs):
                    # Check for line_buttonX pattern
                    line_buttons = anth.find_all('div', class_=re.compile(r'^line_button\d+$'))
                    
                    if line_buttons:
                        # Found explicit lines
                        for btn in line_buttons:
                            # Extract line number
                            classes = btn.get('class', [])
                            line_class = next((c for c in classes if c.startswith('line_button') and c[11:].isdigit()), None)
                            if not line_class:
                                continue
                            
                            line_num = line_class[11:] # Extract number after line_button
                            
                            # Extract name (remove count inside em)
                            # Simple way: get text and remove digits at end if they match em content
                            # Or just iterate contents
                            source_name = ""
                            for content in btn.contents:
                                if isinstance(content, str):
                                    source_name += content.strip()
                            
                            if not source_name:
                                source_name = f"线路 {line_num}"
                            
                            # Find links
                            switch_class = f"circuit_switch{line_num}"
                            links = anth.select(f'a.{switch_class}')
                            
                            if links:
                                episodes = self._parse_episodes_from_links(links)
                                if episodes:
                                    all_sources.append({
                                        'name': source_name,
                                        'episodes': episodes
                                    })
                    else:
                        # No line buttons, treat all links in this anthology as one source
                        links = anth.select('a')
                        if not links:
                            continue
                            
                        # Extract episodes for this source
                        source_episodes = self._parse_episodes_from_links(links)
                        if source_episodes:
                            source_name = f"线路 {len(all_sources) + 1}"
                            all_sources.append({
                                'name': source_name,
                                'episodes': source_episodes
                            })
            
            # Strategy 2: Fallback (if no anthology or empty)
            if not all_sources:
                all_links = soup.find_all('a')
                links = [a for a in all_links if '/Index/video/' in a.get('href', '') or '/video/' in a.get('href', '')]
                episodes = self._parse_episodes_from_links(links)
                if episodes:
                    all_sources.append({
                        'name': '默认线路',
                        'episodes': episodes
                    })

            if not all_sources:
                return []
                
            # Strategy 3: Extract Batch Torrents from Detail Page
            # Check for magnet links in the page
            batch_torrent = ""
            magnets = []
            for a in soup.find_all('a'):
                href = a.get('href', '')
                if href and href.startswith('magnet:?'):
                    magnets.append(href)
            
            if magnets:
                # Use the first one or logic to pick best?
                # Usually the first one is relevant or there is only one batch.
                batch_torrent = magnets[0]
                self.log(f"Found batch torrent on detail page: {batch_torrent}")
            
            # Attach torrent to all episodes if found
            if batch_torrent:
                for src in all_sources:
                    for ep in src['episodes']:
                        ep['torrent'] = batch_torrent

            # Construct response
            # Note: app.py handles dict with 'episodes' and 'sources'
            response = {
                'episodes': all_sources[0]['episodes'], # Default to first source
                'sources': all_sources
            }
            
            return response
            
        except Exception as e:
            self.log(f"Get episodes failed: {e}")
            return []

    def _parse_episodes_from_links(self, links):
        episodes = []
        seen_urls = set()
        for a in links:
            href = a.get('href')
            if not href or href in seen_urls:
                continue
            
            # Check if it looks like an episode link
            if '/video/' not in href and '/play/' not in href:
                continue
            
            name = a.get_text(strip=True)
            if not name:
                name = f"Episode {len(episodes)+1}"
        
            # Format name: if digit, make it 第XX集
            if name.isdigit():
                try:
                    name = f"第{int(name):02d}集"
                except:
                    pass
        
            full_url = urljoin(self.base_url, href)
        
            episodes.append({
                "name": name,
                "url": full_url
            })
            seen_urls.add(href)
        return episodes

    def get_video_url(self, episode_url):
        # Call resolve_video to get full info including torrent
        return self.resolve_video(episode_url)

    def resolve_video(self, episode_url):
        try:
            self.log(f"Resolving video: {episode_url}")
            resp = requests.get(episode_url, headers=self.headers, verify=False)
            resp.encoding = 'utf-8'
            
            # 1. Find iframes
            soup = BeautifulSoup(resp.text, 'html.parser')
            iframes = soup.select('iframe')
            
            m3u8_url = ""
            failure_reason = ""
            
            for iframe in iframes:
                iframe_src = iframe.get('src')
                if not iframe_src:
                    continue
                    
                # Skip comment iframes
                if '/comment/' in iframe_src:
                    continue
                    
                self.log(f"Found candidate iframe: {iframe_src}")
                
                if 'src=null' in iframe_src:
                    failure_reason = "iframe URL contains src=null"
                
                if not iframe_src.startswith('http'):
                    iframe_src = urljoin(self.base_url, iframe_src)
                    
                try:
                    # 2. Fetch iframe content
                    # Need to update Referer
                    iframe_headers = self.headers.copy()
                    iframe_headers['Referer'] = episode_url
                    
                    iframe_resp = requests.get(iframe_src, headers=iframe_headers, verify=False)
                    iframe_content = iframe_resp.text
                    
                    # 3. Extract m3u8 or video src
                    
                    # Strategy 2.5: Extract from video tag
                    try:
                        soup_iframe = BeautifulSoup(iframe_content, 'html.parser')
                        video_tag = soup_iframe.find('video')
                        if video_tag:
                            v_src = video_tag.get('src')
                            if v_src:
                                if v_src.startswith('//'):
                                    v_src = 'https:' + v_src
                                
                                if 'm3u8' in v_src or 'listres' in v_src or v_src.endswith('.webp'):
                                     m3u8_url = v_src
                                     self.log(f"Found video src in iframe: {m3u8_url}")
                    except Exception as e:
                        self.log(f"Video tag extraction failed: {e}")

                    if not m3u8_url:
                        # Look for .m3u8 using regex
                        m_m3u8 = re.search(r'[\'"]([^\'"]+\.m3u8[^\'"]*)[\'"]', iframe_content)
                        if m_m3u8:
                            m3u8_url = m_m3u8.group(1)
                        else:
                            # Try simple search without quotes (sometimes JSON unescaped)
                            m_m3u8_simple = re.search(r'(http[s]?://[^\s]+\.m3u8)', iframe_content)
                            if m_m3u8_simple:
                                m3u8_url = m_m3u8_simple.group(1)
                    
                    # Strategy 3: API Call (player.ezdmw.com)
                    if not m3u8_url and 'player.ezdmw.com' in iframe_src:
                        try:
                            from urllib.parse import parse_qs, urlparse
                            parsed = urlparse(iframe_src)
                            params = parse_qs(parsed.query)
                            nk = params.get('nk', [''])[0]
                            
                            if nk:
                                api_url = "https://player.ezdmw.com/danmuku/api.php"
                                data = {'url': nk}
                                api_headers = {
                                    'User-Agent': self.headers['User-Agent'],
                                    'Referer': iframe_src, 
                                }
                                
                                # Encode Chinese characters in Referer URL
                                from urllib.parse import quote, urlparse, urlunparse
                                parsed_ref = urlparse(iframe_src)
                                safe_ref = urlunparse(parsed_ref._replace(query=quote(parsed_ref.query, safe='=&/')))
                                api_headers['Referer'] = safe_ref
                                
                                self.log(f"Calling API for m3u8: {api_url} params={data}")
                                api_resp = requests.post(api_url, data=data, headers=api_headers, verify=False)
                                
                                try:
                                    res_json = api_resp.json()
                                    if 'url' in res_json:
                                        m3u8_url = res_json['url']
                                        self.log(f"API returned m3u8: {m3u8_url}")
                                except:
                                    pass
                        except Exception as e:
                            self.log(f"API call failed: {e}")
                    
                    # Strategy 4: Fallback to 'src' param in iframe URL (redirects to video)
                    if not m3u8_url:
                        try:
                            from urllib.parse import parse_qs, urlparse
                            parsed = urlparse(iframe_src)
                            params = parse_qs(parsed.query)
                            src_param = params.get('src', [''])[0]
                            
                            if src_param and src_param.startswith('http'):
                                self.log(f"Found src param in iframe: {src_param}")
                                # Follow redirect to get final URL
                                # We use a session to control headers
                                try:
                                    # Use original iframe src as referer for the redirector
                                    headers = self.headers.copy()
                                    
                                    # Encode Referer
                                    from urllib.parse import quote, urlparse, urlunparse
                                    parsed_ref = urlparse(iframe_src)
                                    safe_ref = urlunparse(parsed_ref._replace(query=quote(parsed_ref.query, safe='=&/')))
                                    headers['Referer'] = safe_ref
                                    
                                    # Perform HEAD request to follow redirects
                                    # We catch the final URL from response.url
                                    resp_head = requests.head(src_param, headers=headers, verify=False, allow_redirects=True)
                                    final_url = resp_head.url
                                    
                                    self.log(f"Resolved src param to: {final_url}")
                                    
                                    # If the final URL is different or valid, use it
                                    if final_url.startswith('http'):
                                        m3u8_url = final_url
                                        
                                except Exception as e:
                                    self.log(f"Failed to follow redirect: {e}")
                                    # Fallback: just return the src_param itself if resolution failed, 
                                    # maybe the proxy can handle it?
                                    m3u8_url = src_param
                                    
                        except Exception as e:
                            self.log(f"Src param extraction failed: {e}")

                    # If we found a URL, break the loop
                    if m3u8_url:
                        break
                        
                except Exception as e:
                    self.log(f"Error processing iframe {iframe_src}: {e}")
                    continue

            if not m3u8_url:
                # Check if resource might be missing on source site
                if 'var player_url = "";' in resp.text or "var player_url = '';" in resp.text:
                    self.log("❌ 源站资源可能已失效 (player_url is empty)")
                
                if failure_reason:
                    self.log(f"❌ 解析失败原因: {failure_reason}")
                
                self.log("No m3u8 found in iframe or API")
                return None
                
            # Unescape if needed (e.g. \/)
            m3u8_url = m3u8_url.replace('\\/', '/')
            
            # 4. Extract Torrent (Magnet)
            # Search in the original episode page content
            torrent_url = ""
            magnet_match = re.search(r'magnet:\?xt=urn:btih:[a-zA-Z0-9]+', resp.text)
            if magnet_match:
                torrent_url = magnet_match.group(0)
            else:
                # Try looking for links
                magnet_link = soup.find('a', href=re.compile(r'^magnet:'))
                if magnet_link:
                    torrent_url = magnet_link.get('href')
            
            # 5. Extract Danmaku
            # Logic: Try to find api in iframe or use default
            # The iframe url is like: https://player.ezdmw.com/danmuku/?nk=...
            # This suggests it might use a standard API.
            # But without a clear API endpoint, we can't do much.
            # We'll just return video for now.
            
            return {
                "url": m3u8_url,
                "type": "m3u8",
                "torrent": torrent_url
            }
            
        except Exception as e:
            self.log(f"Resolve video failed: {e}")
            return None

    def download_m3u8_with_task_control(self, video_url, anime_name, episode_name, task=None):
        import os
        import re
        import time
        import shutil
        import m3u8
        
        # Ensure anime_name is not None
        if not anime_name:
            anime_name = "Unknown"
        
        anime_folder = os.path.join(self.download_folder, re.sub(r'[\\/*?:"<>|]', '', anime_name))
        if not os.path.exists(anime_folder):
            os.makedirs(anime_folder)
            
        safe_episode_name = re.sub(r'[\\/*?:"<>|]', '', episode_name)
        output_path = os.path.join(anime_folder, f"{safe_episode_name}.mp4")
        
        if self.is_downloaded(anime_name, episode_name):
            if task: task.progress = 100
            return output_path
            
        if os.path.exists(output_path):
            if task: task.progress = 100
            return output_path
            
        # Check if it's m3u8
        # Note: .webp files from ezdm are often m3u8 playlists disguised as images
        is_m3u8 = '.m3u8' in video_url or '.webp' in video_url or 'application/vnd.apple.mpegurl' in video_url
        
        if is_m3u8:
            return self._download_m3u8_internal(video_url, output_path, task)
        else:
            return self._download_direct_internal(video_url, output_path, task)

    def _download_m3u8_internal(self, m3u8_url, output_path, task=None):
        import m3u8
        import os
        import shutil
        import time
        from urllib.parse import urljoin
        from concurrent.futures import ThreadPoolExecutor, as_completed
        import subprocess
        
        try:
            self.log(f"Downloading m3u8: {m3u8_url}")
            
            # Fetch m3u8 content
            response = requests.get(m3u8_url, headers=self.headers, verify=False, timeout=30)
            response.raise_for_status()
            
            # Resolve relative URIs
            base_uri = os.path.dirname(m3u8_url) + '/'
            m3u8_obj = m3u8.loads(response.text, uri=base_uri)
            
            # Handle nested playlists
            if m3u8_obj.playlists:
                playlist = m3u8_obj.playlists[0]
                m3u8_url = playlist.absolute_uri
                self.log(f"Nested m3u8 found, redirecting to: {m3u8_url}")
                base_uri = os.path.dirname(m3u8_url) + '/'
                response = requests.get(m3u8_url, headers=self.headers, verify=False, timeout=30)
                m3u8_obj = m3u8.loads(response.text, uri=m3u8_url)
            
            segments = m3u8_obj.segments
            if not segments:
                self.log("No segments found")
                return None
                
            total_segments = len(segments)
            if task:
                task.total = total_segments
                task.message = f"Downloading {total_segments} segments"
            
            # Temp dir
            temp_dir = output_path + "_temp"
            if not os.path.exists(temp_dir):
                os.makedirs(temp_dir)
                
            # Shared state for adaptive strategy (Ezdm specific)
            # index 0: use_no_referer (bool)
            # index 1: has_logged_switch (bool)
            strategy_state = [False, False]
            
            def download_segment(args):
                seg_idx, segment = args
                
                # Task control check
                if task:
                    task.pause_event.wait()
                    if task.stop_event.is_set():
                        return False

                seg_url = segment.absolute_uri
                seg_path = os.path.join(temp_dir, f"segment_{seg_idx:04d}.ts")
                
                # Helper to validate file content
                def is_valid_ts(path):
                    try:
                        if not os.path.exists(path) or os.path.getsize(path) == 0:
                            return False
                        with open(path, 'rb') as f:
                            header = f.read(8)
                            # Check for common text/html headers
                            if header.startswith(b'<!DO') or header.startswith(b'<htm') or header.startswith(b'<HTM'):
                                return False
                            # Valid TS usually starts with 0x47
                            # But we should be careful not to reject valid files that might have some garbage
                            # If it starts with 0x47, it's definitely TS
                            if header.startswith(b'\x47'):
                                return True
                            # If it's a known image header, it's invalid (unless we fixed it, but this checks AFTER fix)
                            if header.startswith(b'GIF8') or header.startswith(b'\x89PNG') or header.startswith(b'\xff\xd8'):
                                return False
                        return True
                    except:
                        return False
                
                def fix_disguised_ts(path):
                    try:
                        with open(path, 'rb') as f:
                            content = f.read()
                        
                        # Check for GIF/Image header
                        if content.startswith(b'GIF8') or content.startswith(b'\x89PNG'):
                            # Scan for TS sync byte pattern (0x47 ... 188 bytes ... 0x47)
                            # We scan first 2000 bytes
                            limit = min(2000, len(content) - 376)
                            for i in range(limit):
                                if content[i] == 0x47 and content[i+188] == 0x47:
                                    # Found pattern, strip header
                                    # self.log(f"Stripping disguised header from {os.path.basename(path)} (offset {i})")
                                    with open(path, 'wb') as f:
                                        f.write(content[i:])
                                    return True
                        return False
                    except Exception as e:
                        return False

                # Skip if already downloaded AND valid
                if is_valid_ts(seg_path):
                    return True
                elif os.path.exists(seg_path):
                    # Check if it can be fixed
                    if fix_disguised_ts(seg_path) and is_valid_ts(seg_path):
                        return True
                    # Invalid file exists, delete it
                    try: os.remove(seg_path)
                    except: pass
                
                # Determine headers for segment
                seg_headers = self.headers.copy()
                
                # Apply adaptive strategy if enabled
                if strategy_state[0]:
                    seg_headers['Referer'] = ''
                
                # Specific domain rules (override only if adaptive strategy hasn't disabled referer)
                if 'ins.moei.xyz' in seg_url or 'moei.xyz' in seg_url:
                     seg_headers['Referer'] = ''
                elif ('player.ezdmw.com' in seg_url or 'ezdmw.com' in seg_url) and not strategy_state[0]:
                     seg_headers['Referer'] = 'https://player.ezdmw.com/'
                
                # Retry loop (Giri style: 6 attempts)
                for attempt in range(6):
                    if task and task.stop_event.is_set(): return False
                    try:
                        r = requests.get(seg_url, headers=seg_headers, verify=False, timeout=30, stream=True)
                        
                        # Ezdm specific: Handle 403 adaptive switch
                        if r.status_code == 403 and seg_headers.get('Referer'):
                            strategy_state[0] = True
                            if not strategy_state[1]:
                                self.log(f"Segment {seg_idx} 403 with Referer. Switching to No-Referer strategy.")
                                strategy_state[1] = True
                            seg_headers['Referer'] = ''
                            continue
                            
                        r.raise_for_status()
                        
                        content_length = int(r.headers.get('Content-Length', 0))
                        downloaded = 0
                        
                        with open(seg_path, 'wb') as f:
                            for chunk in r.iter_content(chunk_size=8192):
                                if task and task.stop_event.is_set(): return False
                                if chunk:
                                    f.write(chunk)
                                    downloaded += len(chunk)
                        
                        if content_length > 0 and downloaded < content_length:
                            raise Exception(f"Incomplete download: {downloaded}/{content_length} bytes")
                        
                        # Try to fix if it's disguised
                        fix_disguised_ts(seg_path)

                        # Verify file header using helper logic
                        if not is_valid_ts(seg_path):
                            # It's an invalid file (HTML/Image error page)
                            # Trigger adaptive strategy if not already
                            if not strategy_state[0]:
                                strategy_state[0] = True
                                if not strategy_state[1]:
                                    self.log(f"Segment {seg_idx} invalid content (soft 403). Switching to No-Referer strategy.")
                                    strategy_state[1] = True
                            
                            # Raise exception to trigger retry
                            raise Exception("Segment content invalid (soft 403)")

                        return True
                    except Exception as e:
                        # self.log(f"Segment {seg_idx} failed: {e}")
                        time.sleep(2)
                        if os.path.exists(seg_path):
                            try:
                                os.remove(seg_path)
                            except: pass
                return False

            downloaded_count = 0
            failed_segments = []
            
            # Use ThreadPoolExecutor but check task status
            with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
                # Prepare args
                seg_args = [(i, seg) for i, seg in enumerate(segments)]
                futures = {executor.submit(download_segment, arg): arg for arg in seg_args}
                
                for future in as_completed(futures):
                    if task and task.stop_event.is_set():
                        self.log("Task stopped, cancelling remaining downloads")
                        break
                        
                    arg = futures[future]
                    idx = arg[0]
                    segment = arg[1]
                    
                    try:
                        success = future.result()
                        if success:
                            downloaded_count += 1
                        else:
                            failed_segments.append((idx, segment))
                    except Exception as e:
                        failed_segments.append((idx, segment))
                        self.log(f"Segment download exception: {e}")
                    finally:
                        if task:
                            # Use float for smoother progress bar
                            task.progress = (downloaded_count / total_segments) * 90
                            task.message = f"Downloading: {downloaded_count}/{total_segments} ({task.progress:.1f}%)"
            
            if task and task.stop_event.is_set():
                return None
                
            # Retry logic
            if failed_segments:
                self.log(f"⚠️ {len(failed_segments)} segments failed, retrying...")
                for idx, segment in failed_segments:
                    if task and task.stop_event.is_set(): break
                    success = download_segment((idx, segment))
                    if success:
                        downloaded_count += 1
                    if task:
                        task.message = f"Retrying: {downloaded_count}/{total_segments}"

            if downloaded_count < total_segments:
                self.log(f"❌ Download failed: only {downloaded_count}/{total_segments} segments")
                if task: task.message = "Download incomplete"
                return None
            
            # Merge logic (Giri style)
            if task: task.message = "Merging..."
            try:
                segment_list = os.path.join(temp_dir, "file_list.txt")
                with open(segment_list, 'w', encoding='utf-8') as f:
                    for i in range(total_segments):
                        # Use absolute paths with forward slashes to avoid FFmpeg issues on Windows
                        seg_path = os.path.join(temp_dir, f"segment_{i:04d}.ts")
                        abs_seg_path = os.path.abspath(seg_path).replace('\\', '/')
                        f.write(f"file '{abs_seg_path}'\n")
                
                abs_segment_list = os.path.abspath(segment_list)
                abs_output_path = os.path.abspath(output_path)
                
                # Check for ffmpeg (simple check)
                ffmpeg_cmd = "ffmpeg"
                
                merge_command = [
                    ffmpeg_cmd, "-y",
                    "-f", "concat", 
                    "-safe", "0", 
                    "-i", abs_segment_list, 
                    "-c", "copy", 
                    abs_output_path
                ]
                
                self.log(f"Merging with ffmpeg: {' '.join(merge_command)}")
                
                process = subprocess.run(
                    merge_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    encoding='utf-8', errors='ignore', timeout=600
                )
                
                if process.returncode == 0:
                    self.log("FFmpeg merge successful")
                else:
                    self.log(f"FFmpeg merge failed (code {process.returncode}): {process.stderr}")
                    return None
                
                # Cleanup
                shutil.rmtree(temp_dir, ignore_errors=True)
                
                if task: task.progress = 100
                return output_path
                
            except Exception as e:
                self.log(f"FFmpeg merge error: {e}")
                return None
            
        except Exception as e:
            self.log(f"Download failed: {e}")
            return None

    def _download_direct_internal(self, url, output_path, task=None):
        try:
            self.log(f"Downloading direct file: {url}")
            if task: task.message = "Downloading..."
            
            # Special handling for domains requiring no Referer
            req_headers = self.headers.copy()
            if 'larksuitecdn.com' in url or 'ibyteimg.com' in url or 'xhscdn.com' in url:
                req_headers['Referer'] = ''
                self.log("Using empty Referer for known CDN")
            
            with requests.get(url, headers=req_headers, stream=True, verify=False) as r:
                r.raise_for_status()
                total_length = int(r.headers.get('content-length', 0))
                
                if task and total_length:
                    task.total = total_length
                
                dl = 0
                with open(output_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192): 
                        if chunk: 
                            f.write(chunk)
                            dl += len(chunk)
                            if task and total_length:
                                task.progress = (dl / total_length) * 100
                                task.message = f"Downloading: {dl/1024/1024:.1f}MB / {total_length/1024/1024:.1f}MB"
            
            if task: task.progress = 100
            return output_path
        except Exception as e:
            self.log(f"Direct download failed: {e}")
            return None
