import os
import requests
import re
import json
import m3u8
import time
import shutil
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed
from Crypto.Cipher import AES
from naming_rules import build_download_path, ensure_parent_dir, history_key, possible_legacy_history_keys

class FanTuanSource:
    def __init__(self, log_callback=None, progress_callback=None):
        self.base_url = "https://acgfta.com"
        self.search_url = f"{self.base_url}/search.html?wd="
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Referer": self.base_url,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2"
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
        self.log_callback = log_callback
        self.progress_callback = progress_callback
        
        self.download_folder = "downloads"
        self.log_folder = "logs"
        self.max_threads = 10
        self.download_history_file = os.path.join(self.log_folder, "download_history.json")
        
        if not os.path.exists(self.download_folder):
            os.makedirs(self.download_folder)
        if not os.path.exists(self.log_folder):
            os.makedirs(self.log_folder)
            
        self.download_history = self.load_download_history()

    def log(self, message):
        print(message)
        if self.log_callback:
            self.log_callback(message)

    def load_download_history(self):
        if os.path.exists(self.download_history_file):
            try:
                with open(self.download_history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
        
    def save_download_history(self):
        with open(self.download_history_file, 'w', encoding='utf-8') as f:
            json.dump(self.download_history, f, ensure_ascii=False, indent=2)

    def is_downloaded(self, anime_name, episode_name):
        for key in possible_legacy_history_keys(anime_name, episode_name):
            if key not in self.download_history:
                continue
            record = self.download_history.get(key) or {}
            if isinstance(record, dict) and record.get('path') and os.path.exists(record['path']):
                return True
            try:
                del self.download_history[key]
            except:
                pass
            self.save_download_history()

        schemes = []
        current_scheme = getattr(self, "naming_scheme", "simple") or "simple"
        schemes.append(current_scheme)
        schemes.extend(["simple", "jellyfin", "emby", "fnos"])
        schemes = list(dict.fromkeys([str(s).lower() for s in schemes]))
        default_season = int(getattr(self, "default_season_number", 1) or 1)
        for scheme in schemes:
            for ext in ["mp4", "mkv", "avi"]:
                expected, _ = build_download_path(
                    self.download_folder, anime_name, episode_name,
                    scheme=scheme, ext=ext, default_season=default_season
                )
                if os.path.exists(expected):
                    self.download_history[history_key(anime_name, episode_name)] = {
                        "path": expected,
                        "time": time.strftime("%Y-%m-%d %H:%M:%S")
                    }
                    self.save_download_history()
                    return True
        return False

    def search_anime(self, keyword):
        """搜索番剧"""
        self.log(f"正在搜索: {keyword}")
        url = self.search_url + requests.utils.quote(keyword)
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            response.encoding = 'utf-8' # Ensure UTF-8
            soup = BeautifulSoup(response.text, 'html.parser')
            
            results = []
            items = soup.select('body > main > div > div.mt-2-5 > div > div > div > a')
            for item in items:
                title = item.get('title', '').strip() or item.text.strip()
                href = item.get('href', '')
                if href:
                    href = urljoin(self.base_url, href)
                    results.append({
                        'name': title,
                        'url': href,
                        'source': 'fantu',
                        'cover': item.find('img').get('src') if item.find('img') else ''
                    })
            return results
        except Exception as e:
            self.log(f"搜索失败: {e}")
            return []

    def get_episodes(self, detail_url):
        """获取剧集列表"""
        try:
            self.log(f"正在获取剧集列表: {detail_url}")
            response = self.session.get(detail_url, timeout=30)
            response.raise_for_status()
            response.encoding = 'utf-8' # Ensure UTF-8
            soup = BeautifulSoup(response.text, 'html.parser')
            
            episodes = []
            selectors = [
                '.module-play-list-content a',
                '.scroll-content a',
                '#线路一 > a',
                '.anime-episode a',
                '.episode-list a',
                '.playlist a',
                'a[href*="episode"]',
                'a[href*="/play/"]'
            ]
            
            for selector in selectors:
                items = soup.select(selector)
                if items:
                    current_episodes = []
                    for item in items:
                        ep_name = item.text.strip()
                        ep_url = item.get('href', '')
                        if ep_url:
                            ep_url = urljoin(self.base_url, ep_url)
                            # Filter out non-play links if using generic selector
                            if selector == 'a[href*="/play/"]' and 'vod' not in ep_url and 'play' not in ep_url:
                                continue
                                
                            current_episodes.append({
                                'name': ep_name,
                                'url': ep_url
                            })
                    
                    if current_episodes:
                        episodes = current_episodes
                        self.log(f"使用选择器 '{selector}' 找到 {len(episodes)} 集")
                        break
            
            if not episodes:
                self.log("⚠️ 未找到任何剧集，尝试调试...")
                # Try to find any list of links
                all_links = soup.select('.module-list a, .content a') 
                self.log(f"页面包含 {len(all_links)} 个潜在链接")
                
            return episodes
        except Exception as e:
            self.log(f"获取剧集失败: {e}")
            return []

    def get_video_url(self, episode_url):
        """解析视频真实地址"""
        try:
            self.log(f"正在解析: {episode_url}")
            response = self.session.get(episode_url, timeout=10)
            response.raise_for_status()
            
            # 方法1：从iframe中提取
            iframe_url = self._extract_from_iframe(response.text)
            if iframe_url: return iframe_url
                
            # 方法2：从JavaScript变量中提取
            js_url = self._extract_from_javascript(response.text)
            if js_url: return js_url
                
            # 方法3：从JSON数据中提取
            json_url = self._extract_from_json(response.text)
            if json_url: return json_url
                
            # 方法4：通用视频地址匹配
            return self._extract_universal(response.text)
            
        except Exception as e:
            self.log(f"解析视频地址失败: {e}")
            return None

    def download_m3u8_with_task_control(self, m3u8_url, anime_name, episode_name, task=None):
        """下载m3u8视频并保存为MP4文件 - 支持任务控制"""
        current_scheme = getattr(self, "naming_scheme", "simple") or "simple"
        default_season = int(getattr(self, "default_season_number", 1) or 1)
        output_path, normalized_episode = build_download_path(
            self.download_folder, anime_name, episode_name,
            scheme=current_scheme, ext="mp4", default_season=default_season
        )
        ensure_parent_dir(output_path)
        safe_episode_name = normalized_episode
        
        if self.is_downloaded(anime_name, normalized_episode):
            self.log(f"⏭️ 已下载: {anime_name} - {normalized_episode}")
            if task: task.progress = 100
            return output_path
            
        if os.path.exists(output_path):
            self.log(f"⏭️ 文件已存在: {output_path}")
            self.download_history[history_key(anime_name, normalized_episode)] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            if task: task.progress = 100
            return output_path
        
        try:
            self.log(f"正在获取m3u8播放列表: {m3u8_url}")
            base_uri = os.path.dirname(m3u8_url) + '/'
            content = self._download_content(m3u8_url)
            if not content: return None
            
            m3u8_obj = m3u8.loads(content, uri=base_uri)
            
            # 处理主m3u8文件
            if m3u8_obj.playlists:
                playlist = m3u8_obj.playlists[0]
                m3u8_url = urljoin(base_uri, playlist.uri)
                base_uri = os.path.dirname(m3u8_url) + '/'
                content = self._download_content(m3u8_url)
                if not content: return None
                m3u8_obj = m3u8.loads(content, uri=base_uri)
            
            segments = m3u8_obj.segments
            if not segments:
                self.log(f"❌ 无法获取视频分片列表")
                return None
            
            key = self._get_decryption_key(m3u8_obj)
            
            safe_anime_name = re.sub(r'[\\/*?:"<>|\s]', '_', anime_name)
            safe_episode = re.sub(r'[\\/*?:"<>|\s]', '_', safe_episode_name)
            temp_dir = os.path.join(self.download_folder, "temp", f"{safe_anime_name}_{safe_episode}")
            os.makedirs(temp_dir, exist_ok=True)
            
            total_segments = len(segments)
            if task:
                task.total = total_segments
                task.message = f"开始下载 {total_segments} 个分片"
            
            def download_segment(segment, index):
                if task:
                    task.pause_event.wait()
                    if task.stop_event.is_set(): return False
                
                segment_url = urljoin(base_uri, segment.uri)
                segment_path = os.path.join(temp_dir, f"segment_{index:04d}.ts")
                
                if os.path.exists(segment_path) and os.path.getsize(segment_path) > 1024:
                    return True
                
                for attempt in range(5):
                    if task and task.stop_event.is_set(): return False
                    try:
                        content = self.session.get(segment_url, timeout=30).content
                        if key:
                            iv = bytes([index % 256] * 16)
                            cipher = AES.new(key, AES.MODE_CBC, iv=iv)
                            content = cipher.decrypt(content)
                        
                        with open(segment_path, 'wb') as f:
                            f.write(content)
                            if task: task.update_bytes(len(content))
                        return True
                    except Exception as e:
                        time.sleep(1)
                return False

            downloaded_count = 0
            with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
                futures = {executor.submit(download_segment, segment, i): i for i, segment in enumerate(segments)}
                for future in as_completed(futures):
                    if task and task.stop_event.is_set(): break
                    if future.result():
                        downloaded_count += 1
                    if task:
                        task.progress = int((downloaded_count / total_segments) * 90)
                        task.message = f"下载中: {downloaded_count}/{total_segments}"
            
            if task and task.stop_event.is_set():
                self.log(f"🛑 任务停止，清理临时文件: {temp_dir}")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return None
            
            if downloaded_count < total_segments:
                self.log(f"❌ 下载不完整: {downloaded_count}/{total_segments}")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return None
                
            # Merge - Try ffmpeg first, then Python fallback
            if task: task.message = "正在合并文件..."
            
            # Create file list for ffmpeg
            try:
                segment_list = os.path.join(temp_dir, "file_list.txt")
                with open(segment_list, 'w', encoding='utf-8') as f:
                    for i in range(total_segments):
                        f.write(f"file 'segment_{i:04d}.ts'\n")
                
                abs_segment_list = os.path.abspath(segment_list)
                abs_output_path = os.path.abspath(output_path)
                
                # Try to use ffmpeg if available
                import subprocess
                
                # Check for ffmpeg in system path or common locations
                ffmpeg_cmd = "ffmpeg"
                try:
                    # Test if ffmpeg is available
                    subprocess.run([ffmpeg_cmd, "-version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
                except (subprocess.CalledProcessError, FileNotFoundError):
                    # Fallback for some environments
                    if os.name == 'nt':
                        possible_paths = [
                            r"C:\ffmpeg\bin\ffmpeg.exe",
                            r"ffmpeg.exe"
                        ]
                        for p in possible_paths:
                            if os.path.exists(p):
                                ffmpeg_cmd = p
                                break
                    else:
                        # Linux fallback paths
                        possible_paths = [
                            "/usr/bin/ffmpeg",
                            "/usr/local/bin/ffmpeg"
                        ]
                        for p in possible_paths:
                            if os.path.exists(p):
                                ffmpeg_cmd = p
                                break
                
                merge_command = [
                    ffmpeg_cmd, "-f", "concat", "-safe", "0",
                    "-i", abs_segment_list, "-c", "copy", abs_output_path, "-y"
                ]
                
                self.log(f"尝试使用ffmpeg合并: {' '.join(merge_command)}")
                
                process = subprocess.run(
                    merge_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    encoding='utf-8', errors='ignore', timeout=300
                )
                
                if process.returncode == 0:
                    self.log(f"✅ ffmpeg合并成功: {output_path}")
                else:
                    self.log(f"⚠️ ffmpeg合并失败 (代码 {process.returncode}): {process.stderr[:200]}... 转为使用Python直接合并")
                    raise Exception("ffmpeg failed")
                    
            except Exception as e:
                self.log(f"⚠️ ffmpeg合并不可用或失败 ({e})，使用Python直接二进制合并")
                # Fallback to Python binary merge
                try:
                    with open(output_path, 'wb') as outfile:
                        for i in range(total_segments):
                            segment_path = os.path.join(temp_dir, f"segment_{i:04d}.ts")
                            if not os.path.exists(segment_path): continue
                            with open(segment_path, 'rb') as infile:
                                outfile.write(infile.read())
                    self.log(f"✅ Python合并完成: {output_path}")
                except Exception as py_e:
                     self.log(f"❌ Python合并也失败: {py_e}")
                     return None
            
            try: shutil.rmtree(temp_dir, ignore_errors=True)
            except: pass
            
            self.download_history[history_key(anime_name, normalized_episode)] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            
            if task: task.progress = 100
            return output_path
            
        except Exception as e:
            self.log(f"下载失败: {e}")
            import traceback
            traceback.print_exc()
            return None

    def _download_content(self, url):
        try:
            return self.session.get(url, timeout=10).text
        except: return None

    def _get_decryption_key(self, m3u8_obj):
        if not m3u8_obj.keys or not m3u8_obj.keys[0]: return None
        key_uri = m3u8_obj.keys[0].uri
        if not key_uri: return None
        try:
            key_url = urljoin(m3u8_obj.base_uri, key_uri)
            return self.session.get(key_url).content
        except: return None

    def _extract_from_iframe(self, html):
        iframe_pattern = re.compile(r'<iframe[^>]+src="([^"]+)"')
        iframe_matches = iframe_pattern.findall(html)
        for iframe_url in iframe_matches:
            if any(x in iframe_url for x in ['m3u8', 'mp4', 'mkv', 'flv', 'video', 'play']):
                return iframe_url
            try:
                nested_response = self.session.get(iframe_url, timeout=10)
                nested_response.raise_for_status()
                return self._extract_from_javascript(nested_response.text) or \
                       self._extract_from_json(nested_response.text) or \
                       self._extract_universal(nested_response.text)
            except: continue
        return None
        
    def _extract_from_javascript(self, html):
        patterns = [
            r'var\s+video_url\s*=\s*["\']([^"\']+)["\']',
            r'player\.setup $[^)]*url["\']?\s*:\s*["\']([^"\']+)',
            r'video_url\s*=\s*["\']([^"\']+)["\']',
            r'src:\s*["\']([^"\']+)["\']'
        ]
        for pattern in patterns:
            matches = re.compile(pattern).findall(html)
            if matches: return matches[0]
        return None
        
    def _extract_from_json(self, html):
        try:
            json_pattern = re.compile(r'\{.*?(?:url|src|video_url).*?\}', re.DOTALL)
            json_matches = json_pattern.findall(html)
            for match in json_matches:
                try:
                    data = json.loads(match)
                    for key in ['url', 'src', 'video_url', 'videoUrl', 'video']:
                        if key in data and isinstance(data[key], str) and \
                           any(x in data[key] for x in ['http', 'm3u8', 'mp4']):
                            return data[key]
                except: continue
        except: pass
        return None
        
    def _extract_universal(self, html):
        patterns = [
            r'(http[s]?://[^\s<>"\']+\.m3u8[^\s<>"\']*)',
            r'(http[s]?://[^\s<>"\']+\.(?:mp4|mkv|flv)[^\s<>"\']*)',
            r'(http[s]?://[^\s<>"\']+/[^\s<>"\']*?(?:video|play|stream)[^\s<>"\']*)'
        ]
        for pattern in patterns:
            matches = re.compile(pattern).findall(html)
            if matches: return matches[0]
        return None
