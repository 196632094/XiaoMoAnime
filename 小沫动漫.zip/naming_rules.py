import os
import re


def sanitize_path_component(text: str) -> str:
    if text is None:
        return "Unknown"
    text = str(text).strip()
    if not text:
        return "Unknown"
    text = re.sub(r'[\\/*?:"<>|]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text or "Unknown"


def extract_year_from_title(title: str):
    if not title:
        return None
    m = re.search(r'[\(\[\{（【](\d{4})[\)\]\}）】]', title)
    if m:
        return int(m.group(1))
    m = re.search(r'\b(19\d{2}|20\d{2})\b', title)
    if m:
        return int(m.group(1))
    return None


def extract_episode_number(episode_name: str):
    if not episode_name:
        return None
    m = re.search(r'第\s*(\d+)\s*[话集]', str(episode_name))
    if m:
        try:
            return int(m.group(1))
        except:
            return None
    m = re.search(r'\b(\d{1,4})\b', str(episode_name))
    if m:
        try:
            return int(m.group(1))
        except:
            return None
    return None


def normalize_episode_key(episode_name: str) -> str:
    if not episode_name:
        return "Unknown"
    num = extract_episode_number(episode_name)
    if num is not None:
        return f"第{num}集"
    return sanitize_path_component(episode_name)


def infer_season_number(episode_name: str, default_season: int = 1) -> int:
    text = (episode_name or "").lower()
    if any(k in text for k in ["ova", "sp", "special", "specials", "pv"]):
        return 0
    if any(k in (episode_name or "") for k in ["特典", "特辑", "番外", "外传"]):
        return 0
    return int(default_season or 1)


def extract_episode_title(episode_name: str):
    if not episode_name:
        return ""
    s = str(episode_name).strip()
    s = re.sub(r'^第\s*\d+\s*[话集]\s*', '', s)
    s = re.sub(r'^\d+\s*', '', s)
    s = s.strip(' -._')
    return sanitize_path_component(s) if s else ""


def format_sxxeyy(season: int, episode: int):
    return f"S{int(season):02d}E{int(episode):02d}"


def build_download_path(
    download_root: str,
    anime_name: str,
    episode_name: str,
    scheme: str = "simple",
    ext: str = "mp4",
    default_season: int = 1,
):
    scheme = (scheme or "simple").lower()
    safe_root = download_root or "downloads"
    show = sanitize_path_component(anime_name)
    ep_key = normalize_episode_key(episode_name)
    ep_num = extract_episode_number(episode_name)
    season = infer_season_number(episode_name, default_season=default_season)
    year = extract_year_from_title(anime_name)

    if scheme == "simple" or ep_num is None:
        folder = os.path.join(safe_root, show)
        filename = f"{sanitize_path_component(ep_key)}.{ext}"
        return os.path.join(folder, filename), ep_key

    sxxeyy = format_sxxeyy(season, ep_num)

    if scheme in ["jellyfin", "emby"]:
        if year and f"({year})" not in show:
            show_folder = f"{show} ({year})"
        else:
            show_folder = show
        season_folder = f"Season {int(season):02d}"
        title = extract_episode_title(episode_name)
        if title:
            filename = f"{show} - {sxxeyy} - {title}.{ext}"
        else:
            filename = f"{show} - {sxxeyy}.{ext}"
        return os.path.join(safe_root, show_folder, season_folder, filename), ep_key

    if scheme in ["fnos"]:
        filename = f"{show} {sxxeyy}.{ext}"
        return os.path.join(safe_root, show, filename), ep_key

    if scheme in ["feiniu", "飞牛影视"]:
        season_folder = "特别篇" if int(season) == 0 else f"第{int(season)}季"
        filename = f"{show} {sxxeyy}.{ext}"
        return os.path.join(safe_root, show, season_folder, filename), ep_key

    folder = os.path.join(safe_root, show)
    filename = f"{sanitize_path_component(ep_key)}.{ext}"
    return os.path.join(folder, filename), ep_key


def history_key(anime_name: str, episode_name: str):
    return f"{anime_name or 'Unknown'}||{normalize_episode_key(episode_name)}"


def ensure_parent_dir(file_path: str):
    parent = os.path.dirname(file_path)
    if parent:
        os.makedirs(parent, exist_ok=True)


def possible_legacy_history_keys(anime_name: str, episode_name: str):
    keys = []
    keys.append(history_key(anime_name, episode_name))
    if episode_name:
        keys.append(f"{anime_name or 'Unknown'}||{episode_name}")
    return list(dict.fromkeys(keys))
