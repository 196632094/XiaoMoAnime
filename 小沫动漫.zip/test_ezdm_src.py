import requests
from urllib.parse import parse_qs, urlparse
import base64

def test_src_param():
    iframe_src = "https://player.ezdmw.com/danmuku/?nk=wxhdsmm/wxhdsmm_05&name=wxhdsmm/wxhdsmm_05&src=https://player.ezdmw.com/index/urls/video/aHR0cHM6Ly9zbnMtdmlkZW8tYmQueGhzY2RuLmNvbS9zcGVjdHJ1bS80ODc2NjBlZjhmNDk5NzVjMzU1ODhlMDY1YTQxYzgyN2Q4Zjg2ZWRiindex.mp4&title=我喜欢的是妹妹但不是妹妹&total=null&timeAxis=false&sign=ccf7426102c434e5807c46b6b2713133&quarterly=2018年10月【全集完】"
    
    parsed = urlparse(iframe_src)
    params = parse_qs(parsed.query)
    src_url = params.get('src', [''])[0]
    
    print(f"Extracted src: {src_url}")
    
    if not src_url:
        print("No src param found")
        return

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Referer": "https://m.ezdmw.site/"
    }
    
    try:
        print(f"Testing URL: {src_url}")
        resp = requests.head(src_url, headers=headers, verify=False, allow_redirects=True)
        print(f"Final URL: {resp.url}")
        print(f"Content-Type: {resp.headers.get('Content-Type')}")
        print(f"Status: {resp.status_code}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    import urllib3
    urllib3.disable_warnings()
    test_src_param()
