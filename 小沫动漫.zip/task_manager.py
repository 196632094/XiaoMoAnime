import threading
import time
import uuid
from enum import Enum
import os
import shutil

class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"

class DownloadTask:
    def __init__(self, task_id, anime_name, episode_name, episode_url, source, max_retries=3):
        self.task_id = task_id
        self.anime_name = anime_name
        self.episode_name = episode_name
        self.episode_url = episode_url
        self.source = source
        self.status = TaskStatus.PENDING
        self.progress = 0
        self.total = 0
        self.message = "等待开始"
        self.stop_event = threading.Event()
        self.pause_event = threading.Event()
        self.pause_event.set()
        self.thread = None
        self.created_at = time.time()
        self.max_retries = max_retries
        self.retry_count = 0
        
        # Speed tracking
        self.downloaded_bytes = 0
        self.last_bytes = 0
        self.last_speed_time = time.time()
        self.speed = "0 B/s"
        self.speed_bps = 0
        self.bytes_lock = threading.Lock()

    def update_bytes(self, size):
        with self.bytes_lock:
            self.downloaded_bytes += size

    def calculate_speed(self):
        now = time.time()
        duration = now - self.last_speed_time
        if duration >= 1.0:
            with self.bytes_lock:
                current_bytes = self.downloaded_bytes
            
            diff = current_bytes - self.last_bytes
            if diff < 0: diff = 0 # Should not happen unless restarted
            
            self.speed_bps = diff / duration
            
            if self.speed_bps < 1024:
                self.speed = f"{self.speed_bps:.0f} B/s"
            elif self.speed_bps < 1024 * 1024:
                self.speed = f"{self.speed_bps/1024:.1f} KB/s"
            else:
                self.speed = f"{self.speed_bps/1024/1024:.2f} MB/s"
            
            self.last_bytes = current_bytes
            self.last_speed_time = now

    def start(self):
        if self.status in [TaskStatus.RUNNING, TaskStatus.COMPLETED]:
            return
        
        self.status = TaskStatus.RUNNING
        self.stop_event.clear()
        self.pause_event.set()
        
        self.thread = threading.Thread(target=self._run)
        self.thread.daemon = True
        self.thread.start()

    def pause(self):
        if self.status == TaskStatus.RUNNING:
            self.status = TaskStatus.PAUSED
            self.pause_event.clear()
            self.message = "已暂停"

    def resume(self):
        if self.status == TaskStatus.PAUSED:
            self.status = TaskStatus.RUNNING
            self.pause_event.set()
            self.message = "继续下载中..."

    def stop(self):
        if self.status in [TaskStatus.RUNNING, TaskStatus.PAUSED, TaskStatus.PENDING]:
            self.status = TaskStatus.STOPPED
            self.stop_event.set()
            self.pause_event.set()
            self.message = "已停止"

    def _run(self):
        # Initial check for duplicates before starting heavy work
        if self.source.is_downloaded(self.anime_name, self.episode_name):
             self.status = TaskStatus.COMPLETED
             self.message = "已存在，跳过下载"
             self.progress = 100
             return

        while self.retry_count <= self.max_retries:
            if self.stop_event.is_set(): return
            try:
                self.pause_event.wait()
                
                self.message = "正在获取视频地址..."
                video_result = self.source.get_video_url(self.episode_url)
                
                if not video_result:
                    raise Exception("无法获取视频地址")

                # Handle dict response (common in new sources like ezdm)
                video_url = ""
                if isinstance(video_result, dict):
                    video_url = video_result.get('url', '')
                else:
                    video_url = str(video_result)
                    
                if not video_url:
                     raise Exception("解析到的视频地址为空")

                # Check again just in case
                if self.source.is_downloaded(self.anime_name, self.episode_name):
                    self.status = TaskStatus.COMPLETED
                    self.message = "已存在，跳过下载"
                    self.progress = 100
                    return

                result = self.source.download_m3u8_with_task_control(
                    video_url, 
                    self.anime_name, 
                    self.episode_name,
                    self
                )
                
                if result:
                    self.status = TaskStatus.COMPLETED
                    self.message = "下载完成"
                    self.progress = 100
                    return
                elif self.stop_event.is_set():
                    self.status = TaskStatus.STOPPED
                    self.message = "已停止"
                    return
                else:
                    raise Exception("下载过程中失败")
                    
            except Exception as e:
                if self.stop_event.is_set(): return
                
                self.retry_count += 1
                if self.retry_count <= self.max_retries:
                    self.message = f"下载失败: {str(e)}，正在重试 ({self.retry_count}/{self.max_retries})..."
                    time.sleep(5) # Wait before retry
                else:
                    self.status = TaskStatus.FAILED
                    self.message = f"下载失败 (重试次数耗尽): {str(e)}"
                    import traceback
                    traceback.print_exc()

    def to_dict(self):
        return {
            "id": self.task_id,
            "anime_name": self.anime_name,
            "episode_name": self.episode_name,
            "status": self.status.value,
            "progress": self.progress,
            "total": self.total,
            "message": self.message,
            "speed": self.speed,
            "created_at": self.created_at
        }

class TaskManager:
    def __init__(self, settings_manager):
        self.tasks = {}
        self.lock = threading.Lock()
        self.settings = settings_manager

    def add_task(self, anime_name, episode_name, episode_url, source):
        # Ensure anime_name and episode_name are strings
        if not anime_name or anime_name == 'undefined':
            anime_name = "Unknown"
        if not episode_name or episode_name == 'undefined':
            episode_name = "Unknown"

        # Check if task already exists (deduplication)
        with self.lock:
            for task in self.tasks.values():
                if task.anime_name == anime_name and task.episode_name == episode_name:
                    if task.status in [TaskStatus.FAILED, TaskStatus.STOPPED]:
                        # Restart failed/stopped task
                        task.retry_count = 0
                        task.status = TaskStatus.PENDING
                        task.message = "等待重新开始"
                        # Don't start immediately, let scheduler handle it
                        return task.task_id
                    elif task.status in [TaskStatus.COMPLETED]:
                        return task.task_id # Already done
                    else:
                        return task.task_id # Already running/pending

            task_id = str(uuid.uuid4())
            max_retries = self.settings.get("max_retries", 3)
            task = DownloadTask(task_id, anime_name, episode_name, episode_url, source, max_retries)
            self.tasks[task_id] = task
            # Don't start immediately
            return task_id

    def delete_anime(self, anime_name):
        # Ensure anime_name is not None
        if not anime_name:
            return False
            
        with self.lock:
            to_delete = []
            for task_id, task in self.tasks.items():
                if task.anime_name == anime_name:
                    task.stop()
                    to_delete.append(task_id)
            
            for task_id in to_delete:
                del self.tasks[task_id]
            
            # Check if we should delete empty folder
            try:
                import re
                download_folder = self.settings.get("download_folder", "downloads")
                
                # Ensure anime_name is not None
                if not anime_name:
                    anime_name = "Unknown"
                    
                safe_anime_name = re.sub(r'[\\/*?:"<>|]', '', anime_name)
                anime_path = os.path.join(download_folder, safe_anime_name)
                
                if os.path.exists(anime_path):
                    # Check if empty or only contains temp files (which task.stop() might not have cleaned yet? 
                    # actually task.stop just sets flag. gir.py cleans temp if fail/complete.
                    # If we delete tasks, gir.py threads might still be running or stopped.
                    # We should check if any valid video files exist.
                    
                    has_videos = False
                    for entry in os.scandir(anime_path):
                        if entry.is_file() and entry.name.endswith(('.mp4', '.mkv', '.avi')):
                            has_videos = True
                            break
                    
                    if not has_videos:
                        # Double check we don't delete if there are other files user put there?
                        # Requirement: "If no episode downloaded". 
                        # So if no video files, delete folder.
                        # Be careful with temp folder inside if any.
                        
                        # Wait a bit for threads to release locks? 
                        # Might be risky if download is writing. But we called task.stop().
                        
                        shutil.rmtree(anime_path, ignore_errors=True)
            except Exception as e:
                print(f"Error cleaning up anime folder: {e}")

            return len(to_delete) > 0

    def pause_anime(self, anime_name):
        with self.lock:
            count = 0
            for task in self.tasks.values():
                if task.anime_name == anime_name:
                    if task.status == TaskStatus.RUNNING:
                        task.pause()
                        count += 1
                    elif task.status == TaskStatus.PENDING:
                        task.status = TaskStatus.PAUSED
                        task.message = "已暂停 (等待中)"
                        count += 1
            return count

    def resume_anime(self, anime_name):
        with self.lock:
            count = 0
            for task in self.tasks.values():
                if task.anime_name == anime_name and task.status == TaskStatus.PAUSED:
                    if task.message == "已暂停 (等待中)":
                        task.status = TaskStatus.PENDING
                        task.message = "等待开始"
                    else:
                        task.resume()
                    count += 1
            return count

    def pause_all(self):
        with self.lock:
            count = 0
            for task in self.tasks.values():
                if task.status == TaskStatus.RUNNING:
                    task.pause()
                    count += 1
                elif task.status == TaskStatus.PENDING:
                    task.status = TaskStatus.PAUSED
                    task.message = "已暂停 (等待中)"
                    count += 1
            return count

    def resume_all(self):
        with self.lock:
            count = 0
            for task in self.tasks.values():
                if task.status == TaskStatus.PAUSED:
                    if task.message == "已暂停 (等待中)":
                        task.status = TaskStatus.PENDING
                        task.message = "等待开始"
                    else:
                        task.resume()
                    count += 1
            return count

    def get_total_speed(self, anime_name):
        with self.lock:
            total_bps = 0
            for task in self.tasks.values():
                if task.anime_name == anime_name and task.status == TaskStatus.RUNNING:
                    # Parse speed string back to bps or store bps in task?
                    # Storing bps is cleaner.
                    # But for now, let's parse or just use rough sum if tasks had bps property
                    pass 
            
            # Refactor DownloadTask to store speed_bps
            # For now return None, UI will sum up
            return None

    def scheduler_step(self):
        """Main scheduling logic to be called periodically"""
        with self.lock:
            # Group tasks by anime
            anime_groups = {}
            for task in self.tasks.values():
                if task.anime_name not in anime_groups:
                    anime_groups[task.anime_name] = []
                anime_groups[task.anime_name].append(task)
            
            # Sort anime by creation time (FIFO)
            # We determine anime creation time by the earliest task creation time
            anime_order = []
            for name, tasks in anime_groups.items():
                created_at = min(t.created_at for t in tasks)
                anime_order.append({'name': name, 'created_at': created_at, 'tasks': tasks})
            
            anime_order.sort(key=lambda x: x['created_at'])
            
            # Determine concurrency limits
            max_anime = self.settings.get("max_concurrent_anime", 1)
            if not self.settings.get("concurrent_anime_enabled", False):
                max_anime = 1
            
            max_episodes = self.settings.get("concurrent_episodes", 3)
            
            processing_anime_count = 0
            
            for anime_data in anime_order:
                tasks = anime_data['tasks']
                
                # Check if anime is complete
                if all(t.status == TaskStatus.COMPLETED for t in tasks):
                    continue
                
                # If we have slots for anime processing
                if processing_anime_count < max_anime:
                    processing_anime_count += 1
                    
                    # Process episodes for this anime
                    running_episodes = sum(1 for t in tasks if t.status == TaskStatus.RUNNING)
                    pending_episodes = [t for t in tasks if t.status == TaskStatus.PENDING]
                    
                    # Sort pending by episode name/number if possible? 
                    # Usually added in order, so created_at is fine.
                    pending_episodes.sort(key=lambda t: t.created_at)
                    
                    slots_available = max_episodes - running_episodes
                    
                    for task in pending_episodes:
                        if slots_available > 0:
                            task.start()
                            slots_available -= 1
                        else:
                            break
            
            # Update speeds for running tasks
            for task in self.tasks.values():
                if task.status == TaskStatus.RUNNING:
                    task.calculate_speed()
                else:
                    task.speed = "" # Clear speed if not running
                    task.speed_bps = 0

    def get_task(self, task_id):
        with self.lock:
            return self.tasks.get(task_id)

    def get_all_tasks(self):
        with self.lock:
            # Return list sorted by status (running first) then creation time (newest first)
            tasks_list = []
            for task in self.tasks.values():
                d = task.to_dict()
                d['speed_bps'] = getattr(task, 'speed_bps', 0)
                tasks_list.append(d)
            
            # Sort: Running tasks first, then others. Within each group, sort by creation time (desc)
            def sort_key(x):
                is_running = x['status'] == 'running'
                return (is_running, x['created_at'])
            
            return sorted(tasks_list, key=sort_key, reverse=True)

    def pause_task(self, task_id):
        task = self.get_task(task_id)
        if task:
            task.pause()
            return True
        return False

    def resume_task(self, task_id):
        task = self.get_task(task_id)
        if task:
            task.resume()
            return True
        return False

    def delete_task(self, task_id):
        anime_name = None
        task = None
        
        with self.lock:
            if task_id in self.tasks:
                task = self.tasks[task_id]
                anime_name = task.anime_name
                task.stop()
                del self.tasks[task_id]
        
        if task:
            # Wait briefly for thread to finish cleanup (if any)
            if task.thread and task.thread.is_alive():
                task.thread.join(timeout=2.0)
            
            # Check if we should delete empty anime folder
            if anime_name:
                self._try_delete_anime_folder(anime_name)
            
            return True
        return False

    def _try_delete_anime_folder(self, anime_name):
        """If no active tasks and directory is empty (no videos), delete it"""
        # 1. Check if there are other active tasks for this anime
        with self.lock:
            for task in self.tasks.values():
                if task.anime_name == anime_name:
                    # Found another task for this anime
                    # Even if it's completed/stopped, it might mean the user wants to keep the folder?
                    # User requirement: "no other episode downloading"
                    # If status is RUNNING/PENDING, it is downloading.
                    if task.status in [TaskStatus.RUNNING, TaskStatus.PENDING, TaskStatus.PAUSED]:
                         return
                    # If there are stopped/failed/completed tasks in the list, 
                    # do we delete the folder? 
                    # If completed, the file exists, so folder not empty -> handled by file check.
                    # If failed/stopped, file might not exist. 
                    # But if the task entry is still in the list, maybe we shouldn't delete the folder?
                    # But user said: "if this anime directory has no episode downloaded well ... and no other episode downloading"
                    # This implies we should check disk content primarily.
                    pass

        try:
            import re
            download_folder = self.settings.get("download_folder", "downloads")
            safe_anime_name = re.sub(r'[\\/*?:"<>|]', '', anime_name)
            anime_path = os.path.join(download_folder, safe_anime_name)
            
            if os.path.exists(anime_path):
                # Check for video files
                has_videos = False
                for entry in os.scandir(anime_path):
                    if entry.is_file() and entry.name.endswith(('.mp4', '.mkv', '.avi')):
                        # Check size to ensure it's not a 0-byte placeholder?
                        if entry.stat().st_size > 0:
                            has_videos = True
                            break
                
                if not has_videos:
                    # Double check task status again just in case a new task was added concurrently?
                    # We hold no lock here.
                    # But if a new task was added, it would create the folder if missing.
                    # If we delete it now, the new task might fail or recreate it.
                    # Given the low concurrency of user actions, it's likely fine.
                    
                    # Also check if any temp folder exists and is being used?
                    # The source downloaders use 'temp' subfolder.
                    # If we delete recursively, we kill temp too.
                    # If no active tasks, temp folder shouldn't be active.
                    
                    print(f"Cleaning up empty anime folder: {anime_path}")
                    shutil.rmtree(anime_path, ignore_errors=True)
        except Exception as e:
            print(f"Error checking/cleaning anime folder: {e}")

    def clear_completed(self):
        with self.lock:
            to_remove = [tid for tid, task in self.tasks.items() if task.status in [TaskStatus.COMPLETED, TaskStatus.STOPPED]]
            for tid in to_remove:
                del self.tasks[tid]
            return len(to_remove)

    def delete_all_tasks(self):
        with self.lock:
            count = len(self.tasks)
            # Stop all running tasks first
            for task in self.tasks.values():
                task.stop()
            
            # Clear all tasks
            self.tasks.clear()
            return count
