import json
import os
import requests
import zipfile
import shutil
import logging
import time
import threading

class ProgramUpdateManager:
    def __init__(self, settings_manager):
        self.settings_manager = settings_manager
        self.version_file = "version.json"
        self.default_version_url = "https://xxla.iepose.cn/FTP/%E6%B5%8B%E8%AF%95/1/version.json"
        self.default_zip_url = "https://xxla.iepose.cn/FTP/%E6%B5%8B%E8%AF%95/1/xiaomo-anime-deploy.zip"
        self.ignored_files = [
            "settings.json",
            "shopping_cart.json",
            "auto_update_list.json",
            "download_history.json",
            "logs",
            "downloads",
            "temp",
            ".git",
            ".venv",
            "__pycache__",
            "docker-compose.yml" # Usually don't want to overwrite custom compose
        ]

    def get_current_version(self):
        if os.path.exists(self.version_file):
            try:
                with open(self.version_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get("version", "1.0.0")
            except:
                return "1.0.0"
        return "1.0.0"

    def set_current_version(self, version):
        with open(self.version_file, 'w', encoding='utf-8') as f:
            json.dump({"version": version}, f, ensure_ascii=False, indent=2)

    def check_for_update(self):
        """
        Check if a newer version is available.
        Returns: (has_update, latest_version, download_url, message)
        """
        try:
            version_url = self.settings_manager.get("update_version_url", self.default_version_url)
            # print(f"Checking for updates from: {version_url}")
            
            resp = requests.get(version_url, timeout=10)
            if resp.status_code != 200:
                return False, None, None, f"Failed to fetch version info: {resp.status_code}"
            
            data = resp.json()
            latest_version = data.get("version")
            zip_url = data.get("zip_url", self.default_zip_url)
            
            if not latest_version:
                return False, None, None, "Invalid version info from server"
            
            current_version = self.get_current_version()
            
            if self._compare_versions(latest_version, current_version) > 0:
                return True, latest_version, zip_url, f"New version {latest_version} available"
            else:
                return False, current_version, None, "Already on latest version"
                
        except Exception as e:
            print(f"Update check failed: {e}")
            return False, None, None, str(e)

    def perform_update(self, zip_url):
        """
        Download and extract update, preserving data files.
        """
        try:
            print(f"Downloading update from: {zip_url}")
            
            # 1. Download Zip
            r = requests.get(zip_url, stream=True, timeout=60)
            r.raise_for_status()
            
            update_zip = "update_pkg.zip"
            with open(update_zip, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            print("Download completed. Extracting...")
            
            # 2. Extract to temp dir
            temp_extract_dir = "update_temp_extract"
            if os.path.exists(temp_extract_dir):
                shutil.rmtree(temp_extract_dir)
            os.makedirs(temp_extract_dir)
            
            with zipfile.ZipFile(update_zip, 'r') as zip_ref:
                zip_ref.extractall(temp_extract_dir)
            
            # 3. Copy files to root, respecting ignore list
            # Handle potential nested folder in zip (e.g. if zip contains folder 'app/...')
            # Logic: If temp dir contains only one folder, assume it's the root
            items = os.listdir(temp_extract_dir)
            source_dir = temp_extract_dir
            if len(items) == 1 and os.path.isdir(os.path.join(temp_extract_dir, items[0])):
                source_dir = os.path.join(temp_extract_dir, items[0])
            
            print(f"Updating files from {source_dir}...")
            
            for root, dirs, files in os.walk(source_dir):
                # Calculate relative path
                rel_path = os.path.relpath(root, source_dir)
                if rel_path == ".":
                    target_dir = "."
                else:
                    target_dir = rel_path
                    if not os.path.exists(target_dir):
                        os.makedirs(target_dir)
                
                for file in files:
                    src_file = os.path.join(root, file)
                    dst_file = os.path.join(target_dir, file)
                    
                    # Check ignore list
                    # Simple check: if file name or any part of path is in ignored list
                    # But specific files like settings.json are at root
                    
                    # Path-based check
                    file_rel_path = os.path.join(rel_path, file)
                    if file_rel_path.startswith("./"): file_rel_path = file_rel_path[2:]
                    
                    should_skip = False
                    for ignored in self.ignored_files:
                        # Exact match or subdirectory match
                        if file_rel_path == ignored or file_rel_path.startswith(ignored + os.sep) or file_rel_path.startswith(ignored + "/"):
                            should_skip = True
                            break
                    
                    if should_skip:
                        print(f"Skipping preserved file: {file_rel_path}")
                        continue
                        
                    # Perform copy
                    try:
                        shutil.copy2(src_file, dst_file)
                    except Exception as e:
                        print(f"Failed to update {dst_file}: {e}")
            
            # 4. Cleanup
            try:
                os.remove(update_zip)
                shutil.rmtree(temp_extract_dir)
            except:
                pass
            
            # 5. Update local version file
            # If the zip contained version.json, it might have been copied (unless ignored, but version.json is not in ignored list)
            # But let's verify
            
            return True, "Update completed successfully. Please restart the application."
            
        except Exception as e:
            print(f"Update failed: {e}")
            import traceback
            traceback.print_exc()
            return False, str(e)

    def start_auto_update_thread(self):
        """Start a background thread to check for updates every 24 hours."""
        def run():
            while True:
                # Wait 24 hours (24 * 3600 seconds)
                # Initial wait to let app start up properly (e.g. 1 minute)
                time.sleep(60) 
                
                try:
                    print("Running scheduled program update check...")
                    has_update, version, url, msg = self.check_for_update()
                    if has_update and url:
                        print(f"Auto-update found: {version}. Performing update...")
                        success, update_msg = self.perform_update(url)
                        if success:
                            print("Auto-update successful. Restarting application...")
                            # Restart the application
                            import sys
                            os.execv(sys.executable, ['python'] + sys.argv)
                        else:
                            print(f"Auto-update failed: {update_msg}")
                except Exception as e:
                    print(f"Error in auto-update thread: {e}")
                
                # Sleep for 24 hours
                time.sleep(24 * 3600)

        t = threading.Thread(target=run, daemon=True)
        t.start()

    def _compare_versions(self, v1, v2):
        """
        Compare two version strings (v1 vs v2).
        Returns 1 if v1 > v2, -1 if v1 < v2, 0 if equal.
        """
        def parse(v):
            return [int(x) for x in v.split('.')]
        
        try:
            p1 = parse(v1)
            p2 = parse(v2)
            if p1 > p2: return 1
            if p1 < p2: return -1
            return 0
        except:
            return 0
