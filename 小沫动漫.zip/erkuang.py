import requests
from bs4 import BeautifulSoup
import re
from urllib.parse import quote, urljoin
import os
import time
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import warnings
from naming_rules import build_download_path, ensure_parent_dir, history_key, possible_legacy_history_keys

warnings.filterwarnings('ignore')

class ErkuangSource:
    def __init__(self, log_callback=None, progress_callback=None):
        self.base_url = "https://www.2rk.cc"
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': self.base_url
        }
        self.download_folder = "downloads"
        self.log_folder = "logs"
        self.download_history_file = os.path.join(self.log_folder, "download_history.json")
        
        self.log_callback = log_callback
        self.progress_callback = progress_callback
        self.max_threads = 10
        self.session = requests.Session()
        
        # Ensure directories exist
        if not os.path.exists(self.download_folder):
            os.makedirs(self.download_folder)
        if not os.path.exists(self.log_folder):
            os.makedirs(self.log_folder)
            
        self.download_history = self.load_download_history()

    def log(self, message):
        print(message)
        if self.log_callback:
            self.log_callback(message)

    def update_progress(self, current, total, desc=""):
        if self.progress_callback:
            self.progress_callback(current, total, desc)
            
    def load_download_history(self):
        if os.path.exists(self.download_history_file):
            try:
                with open(self.download_history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
        
    def save_download_history(self):
        with open(self.download_history_file, 'w', encoding='utf-8') as f:
            json.dump(self.download_history, f, ensure_ascii=False, indent=2)
            
    def is_downloaded(self, anime_name, episode_name):
        for key in possible_legacy_history_keys(anime_name, episode_name):
            if key not in self.download_history:
                continue
            record = self.download_history.get(key) or {}
            if isinstance(record, dict) and record.get('path') and os.path.exists(record['path']):
                return True
            try:
                del self.download_history[key]
            except:
                pass
            self.save_download_history()

        schemes = []
        current_scheme = getattr(self, "naming_scheme", "simple") or "simple"
        schemes.append(current_scheme)
        schemes.extend(["simple", "jellyfin", "emby", "fnos"])
        schemes = list(dict.fromkeys([str(s).lower() for s in schemes]))
        default_season = int(getattr(self, "default_season_number", 1) or 1)
        for scheme in schemes:
            for ext in ["mp4", "mkv", "avi"]:
                expected, _ = build_download_path(
                    self.download_folder, anime_name, episode_name,
                    scheme=scheme, ext=ext, default_season=default_season
                )
                if os.path.exists(expected):
                    self.download_history[history_key(anime_name, episode_name)] = {
                        "path": expected,
                        "time": time.strftime("%Y-%m-%d %H:%M:%S")
                    }
                    self.save_download_history()
                    return True
        return False

    def search_anime(self, keyword):
        url = f'{self.base_url}/search?w={quote(keyword)}'
        try:
            resp = self.session.get(url, headers=self.headers, timeout=10)
            resp.raise_for_status()
        except Exception as e:
            self.log(f"搜索失败: {e}")
            return []
        
        soup = BeautifulSoup(resp.text, 'html.parser')
        results = []
        
        for article in soup.find_all('article', class_='z'):
            # Title usually in h2
            title_tag = article.find('h2')
            title = ""
            link = None
            
            if title_tag:
                title = title_tag.get_text(strip=True)
                link = title_tag.find('a', href=True)
            
            # Fallback if h2 not found or empty
            if not title or not link:
                link = article.find('a', href=True)
                if link:
                    title = link.get('title') or link.get_text(strip=True)
            
            if not link:
                continue
                
            href = urljoin(self.base_url, link['href'])
            
            # Cover image
            cover = ""
            img = article.find('img')
            if img:
                cover = img.get('src') or img.get('data-src') or ""
                if cover and not cover.startswith('http'):
                    cover = urljoin(self.base_url, cover)
            
            # Update info
            update_info = ""
            info_span = article.find('span', style="color:#f31")
            if info_span:
                update_info = info_span.get_text(strip=True)
            
            results.append({
                'name': title,
                'url': href,
                'source': 'erkuang',
                'cover': cover,
                'update_info': update_info
            })
            
        return results

    def get_episodes(self, anime_url):
        try:
            resp = self.session.get(anime_url, headers=self.headers, timeout=10)
            resp.raise_for_status()
        except Exception as e:
            self.log(f"获取剧集失败: {e}")
            return []
        
        soup = BeautifulSoup(resp.text, 'html.parser')
        episodes = []
        
        # 2rk.cc episode list seems to be in article.af
        ep_list = soup.find('article', class_='af')
        if ep_list:
            for li in ep_list.find_all('li'):
                a = li.find('a', href=True)
                if a:
                    ep_url = urljoin(self.base_url, a['href'])
                    ep_title = a.get('title') or a.get_text(strip=True)
                    
                    # Try to extract episode number
                    ep_num = 0
                    match = re.search(r'\?id=(\d+)', ep_url)
                    if match:
                        ep_num = int(match.group(1))
                    
                    # Use a clean name for display
                    name = ep_title
                    # Ensure "第X集" format if it's just a number
                    if name.isdigit():
                        name = f"第{name}集"
                    elif "第" not in name and "集" not in name and ep_num > 0:
                        name = f"第{ep_num}集 {name}"
                    
                    episodes.append({
                        'name': name,
                        'url': ep_url,
                        'episode': ep_num
                    })
        
        # Sort by episode number
        episodes.sort(key=lambda x: x.get('episode', 0))
        return episodes

    def get_video_url(self, episode_url):
        try:
            resp = self.session.get(episode_url, headers=self.headers, timeout=10)
            resp.raise_for_status()
        except Exception as e:
            self.log(f"获取视频地址失败: {e}")
            return None
        
        # 1. Regex for loadSource
        pattern = r'loadSource\("([^"]+)"\)'
        match = re.search(pattern, resp.text)
        if match:
            return match.group(1)
        
        # 2. Regex for .m3u8
        m3u8_pattern = r'https?://[^"\']+\.m3u8[^"\']*'
        matches = re.findall(m3u8_pattern, resp.text)
        if matches:
            return matches[0]
            
        return None

    def download_m3u8_with_task_control(self, m3u8_url, anime_name, episode_name, task=None):
        current_scheme = getattr(self, "naming_scheme", "simple") or "simple"
        default_season = int(getattr(self, "default_season_number", 1) or 1)
        output_path, normalized_episode = build_download_path(
            self.download_folder, anime_name, episode_name,
            scheme=current_scheme, ext="mp4", default_season=default_season
        )
        ensure_parent_dir(output_path)
        formatted_episode = normalized_episode
        
        if self.is_downloaded(anime_name, normalized_episode):
            return output_path
            
        if os.path.exists(output_path) and os.path.getsize(output_path) > 1024:
            self.download_history[history_key(anime_name, normalized_episode)] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            return output_path
        
        import m3u8
        try:
            self.log(f"Fetching m3u8: {m3u8_url}")
            # Ensure headers are passed
            response = self.session.get(m3u8_url, headers=self.headers, timeout=30, verify=False)
            response.raise_for_status()
            
            playlist = m3u8.loads(response.text, uri=m3u8_url)
            segments = playlist.segments
            
            if not segments:
                raise Exception("No segments found")
                
        except Exception as e:
            self.log(f"Parse m3u8 failed: {e}")
            return None
            
        safe_anime_name = re.sub(r'[\\/*?:"<>|\s]', '_', anime_name)
        safe_episode = re.sub(r'[\\/*?:"<>|\s]', '_', formatted_episode)
        temp_dir = os.path.join(self.download_folder, "temp", f"{safe_anime_name}_{safe_episode}")
        os.makedirs(temp_dir, exist_ok=True)
        
        total_segments = len(segments)
        if task:
            task.total = total_segments
            task.message = f"Starting download: {total_segments} segments"
            
        def download_segment(args):
            idx, segment = args
            if task:
                task.pause_event.wait()
                if task.stop_event.is_set(): return False
                
            seg_url = segment.absolute_uri
            seg_path = os.path.join(temp_dir, f"segment_{idx:04d}.ts")
            
            if os.path.exists(seg_path) and os.path.getsize(seg_path) > 0:
                return True
                
            for attempt in range(5):
                if task and task.stop_event.is_set(): return False
                try:
                    r = self.session.get(seg_url, headers=self.headers, stream=True, timeout=30, verify=False)
                    r.raise_for_status()
                    
                    with open(seg_path, 'wb') as f:
                        for chunk in r.iter_content(chunk_size=8192):
                            if task and task.stop_event.is_set(): return False
                            if chunk:
                                f.write(chunk)
                                if task: task.update_bytes(len(chunk))
                    return True
                except:
                    time.sleep(1)
            return False

        downloaded_count = 0
        with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            seg_args = [(i, seg) for i, seg in enumerate(segments)]
            futures = {executor.submit(download_segment, arg): arg for arg in seg_args}
            
            for future in as_completed(futures):
                if task and task.stop_event.is_set(): break
                try:
                    if future.result():
                        downloaded_count += 1
                except: pass
                finally:
                    if task:
                        task.progress = (downloaded_count / total_segments) * 90
                        task.message = f"Downloading: {downloaded_count}/{total_segments}"
        
        if downloaded_count < total_segments:
            self.log(f"Download incomplete: {downloaded_count}/{total_segments}")
            return None
            
        # Merge
        if task: task.message = "Merging..."
        try:
            segment_list = os.path.join(temp_dir, "file_list.txt")
            with open(segment_list, 'w', encoding='utf-8') as f:
                for i in range(total_segments):
                    seg_path = os.path.abspath(os.path.join(temp_dir, f"segment_{i:04d}.ts")).replace('\\', '/')
                    f.write(f"file '{seg_path}'\n")
                    
            abs_output = os.path.abspath(output_path)
            cmd = [
                "ffmpeg", "-y", "-f", "concat", "-safe", "0",
                "-i", os.path.abspath(segment_list), "-c", "copy", abs_output
            ]
            
            subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            
            shutil.rmtree(temp_dir, ignore_errors=True)
            
            self.download_history[history_key(anime_name, normalized_episode)] = {
                "path": output_path,
                "time": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_download_history()
            
            if task: task.progress = 100
            return output_path
            
        except Exception as e:
            self.log(f"Merge failed: {e}")
            return None
