const fs = require('fs');
const path = require('path');
const CryptoJS = require('./crypto-js.min.js');

const args = process.argv.slice(2);
if (args.length < 3) {
    console.error("Usage: node node_decrypt.js <encrypted_url> <viewport_id> <charset_id>");
    process.exit(1);
}

const encrypted_url = args[0];
const viewport_id = args[1];
const charset_id = args[2];

// Mock browser environment
global.window = {
    location: {
        href: 'https://player.cycanime.com/',
        search: ''
    },
    navigator: {
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        appVersion: '5.0 (Windows)'
    },
    screen: { width: 1920, height: 1080 }
};
global.document = {
    createElement: () => ({
        style: {},
        appendChild: () => {},
        setAttribute: () => {}
    }),
    location: global.window.location,
    referrer: 'https://www.cycani.org/',
    cookie: '',
    getElementById: () => null,
    getElementsByTagName: () => []
};
global.navigator = global.window.navigator;
global.location = global.window.location;
global.screen = global.window.screen;

// Mock jQuery
global.jQuery = function(selector) {
    return {
        ready: (fn) => fn && fn(),
        click: () => {},
        on: () => {},
        attr: (name) => {
            if (name === 'id') {
                if (selector === 'meta[name="viewport"]') return viewport_id;
                if (selector === 'meta[charset="UTF-8"]') return charset_id;
            }
            return "";
        },
        val: () => {},
        html: () => {},
        text: () => {},
        css: () => {},
        show: () => {},
        hide: () => {},
        remove: () => {}
    };
};
global.$ = global.jQuery;
global.CryptoJS = CryptoJS;

// Read the logic
try {
    const logicPath = path.join(__dirname, 'cycani_player_logic.js');
    const logic = fs.readFileSync(logicPath, 'utf8');
    eval(logic);
    
    // Call decrypt
    if (typeof decrypt === 'function') {
        const result = decrypt(encrypted_url);
        console.log("DECRYPTED_URL:" + result);
    } else {
        console.error("Decrypt function not found");
        process.exit(1);
    }
} catch (e) {
    console.error("Error:", e);
    process.exit(1);
}
