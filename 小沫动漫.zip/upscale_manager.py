import os
import threading
import time
import subprocess
import shutil
import json
import requests
import platform
import zipfile

class ModelManager:
    def __init__(self, settings_manager):
        self.settings = settings_manager
        # List of available models with their descriptions
        self.available_models = [
            {"name": "realesr-animevideov3", "desc": "针对动漫视频优化 (推荐)", "files": ["realesr-animevideov3.bin", "realesr-animevideov3.param"]},
            {"name": "realesrgan-x4plus", "desc": "通用模型 (4x, 效果好但慢)", "files": ["realesrgan-x4plus.bin", "realesrgan-x4plus.param"]},
            {"name": "realesrgan-x4plus-anime", "desc": "动漫图像 (4x, 针对插画)", "files": ["realesrgan-x4plus-anime.bin", "realesrgan-x4plus-anime.param"]},
            {"name": "realesrnet-x4plus", "desc": "通用模型 (4x, 只有网络)", "files": ["realesrnet-x4plus.bin", "realesrnet-x4plus.param"]},
        ]
        self.base_url = "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0"
        
        # Download status tracking: { 'model_name': { 'status': 'downloading'/'completed'/'failed', 'progress': 0-100, 'message': '' } }
        self.download_status = {}
        self.lock = threading.Lock()

    def get_models_dir(self):
        exe_path = self.settings.get("realesrgan_path")
        if exe_path and os.path.exists(exe_path):
            # Models should be in 'models' folder next to executable
            return os.path.join(os.path.dirname(exe_path), "models")
        # Fallback to local 'models' folder
        local_models = os.path.join(os.getcwd(), "models")
        if not os.path.exists(local_models):
            os.makedirs(local_models)
        return local_models

    def get_executable_path(self):
        # Check settings first
        exe_path = self.settings.get("realesrgan_path")
        if exe_path and os.path.exists(exe_path):
            return exe_path
            
        # Determine default name
        system = platform.system()
        if system == 'Windows':
            default_name = 'realesrgan-ncnn-vulkan.exe'
        else:
            default_name = 'realesrgan-ncnn-vulkan'
            
        # Check current dir
        if os.path.exists(default_name):
            return os.path.abspath(default_name)
            
        # Check models dir (as fallback location)
        models_dir = self.get_models_dir()
        path_in_models = os.path.join(models_dir, default_name)
        if os.path.exists(path_in_models):
            return path_in_models
            
        return None

    def list_models(self):
        models_dir = self.get_models_dir()
        installed = []
        if os.path.exists(models_dir):
            files = os.listdir(models_dir)
            for m in self.available_models:
                name = m['name']
                # Check if all required files exist
                is_installed = True
                for f in m['files']:
                    if f not in files:
                        is_installed = False
                        break
                if is_installed:
                    installed.append(name)
        
        # Check executable status
        executable = self.get_executable_path()
        
        return {
            "installed": installed,
            "available": self.available_models,
            "models_dir": models_dir,
            "downloads": self.download_status,
            "engine_installed": bool(executable),
            "engine_path": executable or ""
        }
        
    def download_engine(self):
        with self.lock:
            if 'engine' in self.download_status and self.download_status['engine']['status'] == 'downloading':
                return True, "引擎下载中"
                
            self.download_status['engine'] = {
                'status': 'downloading',
                'progress': 0,
                'message': '准备下载引擎...'
            }
            threading.Thread(target=self._download_engine_worker, daemon=True).start()
            return True, "开始下载引擎"

    def delete_model(self, model_name):
        """Delete a model and its associated files."""
        # Find model info
        model_info = next((m for m in self.available_models if m['name'] == model_name), None)
        if not model_info:
            return False, f"未找到模型: {model_name}"

        models_dir = self.get_models_dir()
        if not os.path.exists(models_dir):
            return False, "模型目录不存在"

        deleted_files = []
        errors = []

        for filename in model_info['files']:
            file_path = os.path.join(models_dir, filename)
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                    deleted_files.append(filename)
                except Exception as e:
                    errors.append(f"{filename}: {str(e)}")
        
        if errors:
            return False, f"删除部分文件失败: {'; '.join(errors)}"
        
        if not deleted_files:
            return True, "未找到需要删除的文件" # Technically success if already gone
            
        return True, f"成功删除模型 {model_name}"

    def delete_engine(self):
        """Delete the engine executable and associated files."""
        exe_path = self.get_executable_path()
        if not exe_path:
            return False, "未找到引擎文件"
            
        try:
            # Delete exe
            os.remove(exe_path)
            
            # Delete DLLs if present in same dir (vcomp140.dll, vcomp140d.dll, glslangValidator.exe)
            dir_path = os.path.dirname(exe_path)
            for f in ['vcomp140.dll', 'vcomp140d.dll', 'glslangValidator.exe']:
                fp = os.path.join(dir_path, f)
                if os.path.exists(fp):
                    try:
                        os.remove(fp)
                    except: pass
                    
            return True, "引擎已删除"
        except Exception as e:
            return False, f"删除失败: {e}"
             
    def _download_engine_worker(self):
        try:
            system = platform.system()
            if system == 'Windows':
                filename = 'realesrgan-ncnn-vulkan-20220424-windows.zip'
            elif system == 'Linux':
                filename = 'realesrgan-ncnn-vulkan-20220424-ubuntu.zip'
            elif system == 'Darwin': # MacOS
                filename = 'realesrgan-ncnn-vulkan-20220424-macos.zip'
            else:
                raise Exception(f"不支持的系统: {system}")
                
            url = f"{self.base_url}/{filename}"
            # For Linux/Mac, use original URL as ghproxy might be unstable for some
            download_url = f"https://ghproxy.com/{url}"
            
            # Retry with different proxies
            proxies = [
                "https://gh.llkk.cc/",
                "https://gh.ddlc.top/",
                "https://gh.api.99988866.xyz/",
                "https://ghproxy.com/",
                "https://mirror.ghproxy.com/",
                "https://gh-proxy.com/",
                "" # Direct
            ]
            
            # Download to temp
            temp_zip = "engine_temp.zip"
            
            success = False
            last_error = None
            
            for proxy in proxies:
                try:
                    current_url = f"{proxy}{url}" if proxy else url
                    
                    with self.lock:
                        self.download_status['engine']['message'] = f"正在下载 (尝试 {proxy or '直连'})..."
                    
                    response = requests.get(current_url, stream=True, timeout=60)
                    response.raise_for_status()
                    
                    # Check content type if possible, but github releases redirect
                    
                    total_length = int(response.headers.get('content-length', 0))
                    downloaded = 0
                    
                    with open(temp_zip, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                                downloaded += len(chunk)
                                if total_length > 0:
                                    progress = (downloaded / total_length) * 100
                                    with self.lock:
                                        self.download_status['engine']['progress'] = min(90, progress)
                    
                    # Verify zip
                    if not zipfile.is_zipfile(temp_zip):
                        # Read first few bytes to debug
                        with open(temp_zip, 'rb') as f:
                            head = f.read(100)
                        print(f"Downloaded file is not a zip. Head: {head}")
                        raise Exception("下载的文件不是有效的ZIP文件")
                        
                    success = True
                    break
                except Exception as e:
                    print(f"Proxy {proxy} failed: {e}")
                    last_error = e
                    continue
            
            if not success:
                raise last_error or Exception("所有镜像源均失败")
                                
            # Extract
            with self.lock:
                self.download_status['engine']['message'] = "正在解压..."
                
            with zipfile.ZipFile(temp_zip, 'r') as zip_ref:
                # Extract to temp folder first
                zip_ref.extractall("engine_temp_extract")
                
            # Move executable
            exe_name = 'realesrgan-ncnn-vulkan.exe' if system == 'Windows' else 'realesrgan-ncnn-vulkan'
            
            # Find exe in extracted folder
            found_exe = None
            for root, dirs, files in os.walk("engine_temp_extract"):
                if exe_name in files:
                    found_exe = os.path.join(root, exe_name)
                    break
            
            if found_exe:
                # Move all files from the folder containing the exe to current dir
                source_dir = os.path.dirname(found_exe)
                target_dir = os.getcwd()
                
                # Check execution permissions for Linux/Mac
                if system != 'Windows':
                    try:
                        # Add execution permission
                        st = os.stat(found_exe)
                        os.chmod(found_exe, st.st_mode | 0o111)
                    except Exception as e:
                        print(f"Failed to set executable permission: {e}")

                for filename in os.listdir(source_dir):
                    source_file = os.path.join(source_dir, filename)
                    target_file = os.path.join(target_dir, filename)
                    
                    if os.path.isfile(source_file):
                        if os.path.exists(target_file):
                            try:
                                os.remove(target_file)
                            except: pass
                        shutil.move(source_file, target_file)
                        
                        # Re-apply permission if it was the exe and moved
                        if filename == exe_name and system != 'Windows':
                             try:
                                 os.chmod(target_file, 0o755)
                             except: pass
                             
                    elif os.path.isdir(source_file):
                        # Move directory (e.g. "models")
                        if os.path.exists(target_file):
                            try:
                                shutil.rmtree(target_file)
                            except: pass
                        shutil.move(source_file, target_file)

                # Update settings? Maybe just let auto-discovery find it.
                
                with self.lock:
                    self.download_status['engine']['status'] = 'completed'
                    self.download_status['engine']['progress'] = 100
                    self.download_status['engine']['message'] = "引擎安装完成"
            else:
                raise Exception("解压后未找到可执行文件")
                
        except Exception as e:
            print(f"Engine download error: {e}")
            with self.lock:
                self.download_status['engine']['status'] = 'failed'
                self.download_status['engine']['message'] = f"错误: {str(e)}"
        finally:
            # Cleanup
            if os.path.exists("engine_temp.zip"):
                os.remove("engine_temp.zip")
            if os.path.exists("engine_temp_extract"):
                shutil.rmtree("engine_temp_extract")

    def download_model(self, model_name):
        with self.lock:
            # Check if already downloading
            if model_name in self.download_status and self.download_status[model_name]['status'] == 'downloading':
                return True, "下载已在进行中"
            
            # Check if valid model
            model_info = next((m for m in self.available_models if m['name'] == model_name), None)
            if not model_info:
                return False, "未知模型"
            
            # Start background download
            self.download_status[model_name] = {
                'status': 'downloading',
                'progress': 0,
                'message': '准备下载...'
            }
            
            threading.Thread(target=self._download_worker, args=(model_name, model_info), daemon=True).start()
            return True, "开始下载"

    def _download_worker(self, model_name, model_info):
        try:
            models_dir = self.get_models_dir()
            if not os.path.exists(models_dir):
                os.makedirs(models_dir)
            
            total_files = len(model_info['files'])
            
            for i, filename in enumerate(model_info['files']):
                url = f"{self.base_url}/{filename}"
                download_url = f"https://ghproxy.com/{url}"
                dest_path = os.path.join(models_dir, filename)
                temp_path = dest_path + ".part"
                
                # Update status
                with self.lock:
                    self.download_status[model_name]['message'] = f"正在下载 {filename} ({i+1}/{total_files})..."
                
                # Stream download with progress
                try:
                    response = requests.get(download_url, stream=True, timeout=30)
                    response.raise_for_status()
                    
                    total_length = int(response.headers.get('content-length', 0))
                    downloaded = 0
                    
                    with open(temp_path, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                                downloaded += len(chunk)
                                
                                # Calculate progress for current file
                                if total_length > 0:
                                    current_percent = (downloaded / total_length) * 100
                                    overall_progress = ((i * 100) + current_percent) / total_files
                                    
                                    with self.lock:
                                        self.download_status[model_name]['progress'] = min(99, overall_progress)
                    
                    # Rename temp file to final file
                    if os.path.exists(dest_path):
                        os.remove(dest_path)
                    os.rename(temp_path, dest_path)
                    
                except Exception as e:
                    if os.path.exists(temp_path):
                        os.remove(temp_path)
                    raise e
            
            # Verify installation
            installed = False
            if os.path.exists(models_dir):
                files = os.listdir(models_dir)
                is_installed = True
                for f in model_info['files']:
                    if f not in files:
                        is_installed = False
                        break
                if is_installed:
                    installed = True
            
            with self.lock:
                if installed:
                    self.download_status[model_name]['status'] = 'completed'
                    self.download_status[model_name]['progress'] = 100
                    self.download_status[model_name]['message'] = '下载完成'
                    # Optional: Remove from status after a while? 
                    # Let's keep it so user sees "Completed" until they refresh or we clean it up manually
                else:
                    self.download_status[model_name]['status'] = 'failed'
                    self.download_status[model_name]['message'] = '验证失败'

        except Exception as e:
            print(f"Model download error: {e}")
            with self.lock:
                self.download_status[model_name]['status'] = 'failed'
                self.download_status[model_name]['message'] = f"错误: {str(e)}"

class UpscaleManager:
    def __init__(self, settings_manager, library_manager):
        self.settings = settings_manager
        self.library = library_manager
        self.model_manager = ModelManager(settings_manager)
        self.tasks = [] # List of task dicts
        self.lock = threading.Lock()
        self.active_task = None
        self.current_process = None # Track current active process
        self.stop_event = threading.Event()
        self.thread = None
        
        # Load tasks from file if exists (persistence)
        self.tasks_file = "upscale_tasks.json"
        self.load_tasks()
        
        # Cleanup any orphan processes from previous runs
        self.cleanup_orphans()
        
        # Start worker
        self.start_worker()

    def cleanup_orphans(self):
        """Kill any realesrgan/ffmpeg processes that are not currently tracked."""
        try:
            # We only want to kill processes that look like our workers
            targets = ['realesrgan-ncnn-vulkan.exe', 'realesrgan-ncnn-vulkan']
            current_pid = self.current_process.pid if self.current_process else None
            
            system = platform.system()
            
            if system == 'Windows':
                # Use tasklist to find and taskkill to kill
                output = subprocess.check_output('tasklist /FO CSV /NH', shell=True).decode('utf-8', errors='ignore')
                for line in output.splitlines():
                    if not line.strip(): continue
                    parts = line.split(',')
                    if len(parts) < 2: continue
                    pname = parts[0].strip('"')
                    pid_str = parts[1].strip('"')
                    
                    if pname in targets:
                        try:
                            pid = int(pid_str)
                            if pid != current_pid:
                                print(f"Cleaning orphan process (Windows): {pname} (PID: {pid})")
                                subprocess.run(f'taskkill /F /PID {pid}', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        except: pass
                        
            else:
                # Unix/Linux - use pgrep/pkill or iterate /proc
                # Simple pkill for name
                for target in targets:
                    try:
                         # This might kill current process if names match exactly and we can't filter by PID easily with simple pkill
                         # So let's use pgrep to list first
                         pids = subprocess.check_output(['pgrep', '-f', target]).decode().split()
                         for pid_str in pids:
                             pid = int(pid_str)
                             if pid != current_pid and pid != os.getpid():
                                 print(f"Cleaning orphan process (Unix): {target} (PID: {pid})")
                                 os.kill(pid, signal.SIGKILL)
                    except: pass
                    
        except Exception as e:
            print(f"Error cleaning orphans: {e}")
            
    def cleanup_temp_files(self):
        """Clean up temp frames folders for tasks that are not running."""
        try:
            # Get list of running session_ids
            running_sessions = []
            with self.lock:
                for task in self.tasks:
                    if task['status'] in ['processing', 'paused'] and 'session_id' in task:
                        running_sessions.append(task['session_id'])
            
            # Scan current directory for temp_frames_*
            cwd = os.getcwd()
            count = 0
            for name in os.listdir(cwd):
                if name.startswith('temp_frames_in_') or name.startswith('temp_frames_out_'):
                    # Extract session_id
                    # Format: temp_frames_in_SESSIONID
                    parts = name.split('_')
                    if len(parts) >= 4:
                        session_id = parts[3]
                        if session_id not in running_sessions:
                            # It's an orphan folder
                            path = os.path.join(cwd, name)
                            print(f"Cleaning orphan temp folder: {path}")
                            try:
                                shutil.rmtree(path)
                                count += 1
                            except Exception as e:
                                print(f"Failed to delete {path}: {e}")
            return count
        except Exception as e:
            print(f"Error cleaning temp files: {e}")
            return 0

    def load_tasks(self):
        if os.path.exists(self.tasks_file):
            try:
                with open(self.tasks_file, 'r', encoding='utf-8') as f:
                    self.tasks = json.load(f)
                    # Reset 'processing' tasks to 'pending' on restart
                    for task in self.tasks:
                        if task['status'] == 'processing':
                            task['status'] = 'pending'
            except:
                self.tasks = []

    def save_tasks(self):
        try:
            with open(self.tasks_file, 'w', encoding='utf-8') as f:
                json.dump(self.tasks, f, ensure_ascii=False, indent=2)
        except:
            pass

    def start_worker(self):
        if self.thread is None or not self.thread.is_alive():
            self.stop_event.clear()
            self.thread = threading.Thread(target=self._worker_loop, daemon=True)
            self.thread.start()

    def get_upscale_files(self, page=1, limit=10, filter_type='all', search=''):
        """
        Get files with pagination, filtering, and upscaled status
        filter_type: 'all', 'upscaled', 'todo'
        """
        all_anime = self.library.get_anime_list()
        
        # Flatten structure: Anime -> Episodes
        flat_list = []
        for anime in all_anime:
            anime_name = anime['name']
            
            # Filter by search
            if search and search.lower() not in anime_name.lower():
                continue
                
            # We need to list episodes to check status
            # This might be slow if many files, but for local library it's usually fine
            episodes = self.library.get_episodes(anime_name)
            
            for ep in episodes:
                # Skip upscaled files themselves
                if ep['name'].endswith('_upscaled') or '_upscaled.' in ep['path']:
                    continue

                is_upscaled = False
                # Check if _upscaled exists
                # Assuming standard naming: name.ext -> name_upscaled.ext
                base, ext = os.path.splitext(ep['path'])
                upscaled_path = f"{base}_upscaled{ext}"
                if os.path.exists(upscaled_path):
                    is_upscaled = True
                
                # Filter logic
                if filter_type == 'upscaled' and not is_upscaled:
                    continue
                if filter_type == 'todo' and is_upscaled:
                    continue
                
                flat_list.append({
                    'anime_name': anime_name,
                    'episode_name': ep['name'],
                    'path': ep['path'],
                    'size': ep['size'],
                    'is_upscaled': is_upscaled,
                    'upscaled_path': upscaled_path if is_upscaled else ''
                })
        
        # Sort by name
        flat_list.sort(key=lambda x: (x['anime_name'], x['episode_name']))
        
        # Pagination
        total = len(flat_list)
        start = (page - 1) * limit
        end = start + limit
        paginated = flat_list[start:end]
        
        return {
            'items': paginated,
            'total': total,
            'page': page,
            'limit': limit,
            'total_pages': (total + limit - 1) // limit
        }

    def add_task(self, anime_name, episode_name, input_path, model_name=None):
        with self.lock:
            # Check duplicates
            for task in self.tasks:
                if task['input_path'] == input_path and task['status'] in ['pending', 'processing']:
                    return False, "任务已存在"
            
            task_id = int(time.time() * 1000)
            
            # Default model if not provided
            if not model_name:
                model_name = self.settings.get("upscale_model", "realesr-animevideov3")
                
            self.tasks.append({
                'id': task_id,
                'anime_name': anime_name,
                'episode_name': episode_name,
                'input_path': input_path,
                'status': 'pending', # pending, processing, completed, failed
                'progress': 0,
                'message': '等待中...',
                'added_at': time.time(),
                'output_path': '',
                'model': model_name
            })
            self.save_tasks()
            return True, "已添加任务"

    def get_tasks(self, page=1, limit=10, status_filter='all'):
        with self.lock:
            # Filter
            filtered = []
            for t in self.tasks:
                if status_filter == 'all':
                    filtered.append(t)
                elif status_filter == 'processing':
                    if t['status'] in ['pending', 'processing', 'paused']:
                        filtered.append(t)
                elif status_filter == 'completed':
                    if t['status'] == 'completed':
                        filtered.append(t)
                elif status_filter == 'failed':
                    if t['status'] == 'failed':
                        filtered.append(t)
            
            # Sort
            filtered.sort(key=lambda x: x['added_at'], reverse=True)
            
            # Pagination
            total = len(filtered)
            if limit > 0:
                start = (page - 1) * limit
                end = start + limit
                items = filtered[start:end]
                total_pages = (total + limit - 1) // limit
            else:
                items = filtered
                total_pages = 1
                
            return {
                'items': items,
                'total': total,
                'page': page,
                'limit': limit,
                'total_pages': total_pages
            }

    def clear_tasks(self, status_filter='all'):
        with self.lock:
            to_remove = []
            for t in self.tasks:
                should_remove = False
                if status_filter == 'all':
                    should_remove = True
                elif status_filter == 'processing':
                    if t['status'] in ['pending', 'processing', 'paused']:
                        should_remove = True
                elif status_filter == 'completed':
                    if t['status'] == 'completed':
                        should_remove = True
                elif status_filter == 'failed':
                    if t['status'] == 'failed':
                        should_remove = True
                
                if should_remove:
                    to_remove.append(t['id'])
            
            if not to_remove:
                return 0
                
            # If removing active task, stop it
            if self.active_task and self.active_task['id'] in to_remove:
                self.stop_event.set()
            
            # Cleanup temp folders for removed tasks
            for task_id in to_remove:
                task = next((t for t in self.tasks if t['id'] == task_id), None)
                if task and 'session_id' in task:
                    session_id = task['session_id']
                    temp_dir_in = os.path.join(os.getcwd(), f"temp_frames_in_{session_id}")
                    temp_dir_out = os.path.join(os.getcwd(), f"temp_frames_out_{session_id}")
                    try:
                        if os.path.exists(temp_dir_in): shutil.rmtree(temp_dir_in)
                        if os.path.exists(temp_dir_out): shutil.rmtree(temp_dir_out)
                    except: pass

            self.tasks = [t for t in self.tasks if t['id'] not in to_remove]
            self.save_tasks()
            return len(to_remove)

    def remove_task(self, task_id):
        with self.lock:
            # If removing active task, stop it
            if self.active_task and self.active_task['id'] == task_id:
                self.stop_event.set() # Signal worker to stop
            
            # Cleanup temp folders if they exist
            task = next((t for t in self.tasks if t['id'] == task_id), None)
            if task and 'session_id' in task:
                session_id = task['session_id']
                temp_dir_in = os.path.join(os.getcwd(), f"temp_frames_in_{session_id}")
                temp_dir_out = os.path.join(os.getcwd(), f"temp_frames_out_{session_id}")
                try:
                    if os.path.exists(temp_dir_in): shutil.rmtree(temp_dir_in)
                    if os.path.exists(temp_dir_out): shutil.rmtree(temp_dir_out)
                except: pass

            self.tasks = [t for t in self.tasks if t['id'] != task_id]
            self.save_tasks()
            return True

    def pause_task(self, task_id):
        with self.lock:
            task = next((t for t in self.tasks if t['id'] == task_id), None)
            if not task:
                return False, "未找到任务"
            
            if task['status'] != 'processing':
                return False, "任务未在运行"
            
            # Mark as paused requested
            task['status'] = 'paused'
            self.stop_event.set() # Force stop current process
            self.save_tasks()
            return True, "任务已暂停"

    def resume_task(self, task_id):
        with self.lock:
            task = next((t for t in self.tasks if t['id'] == task_id), None)
            if not task:
                return False, "未找到任务"
            
            if task['status'] != 'paused':
                return False, "任务未暂停"
            
            # Reset to pending/processing
            task['status'] = 'pending'
            task['message'] = '准备继续...'
            self.save_tasks()
            return True, "任务已继续"

    def _worker_loop(self):
        while True:
            task = None
            with self.lock:
                # Find next pending task
                pending = [t for t in self.tasks if t['status'] == 'pending']
                if pending:
                    task = pending[0]
                    task['status'] = 'processing'
                    self.active_task = task
                    self.save_tasks()
            
            if task:
                self._process_task(task)
                with self.lock:
                    self.active_task = None
                    self.stop_event.clear() # Reset stop event
                    self.save_tasks()
            else:
                time.sleep(2)

    def _process_task(self, task):
        try:
            input_path = task['input_path']
            # Ensure absolute path to avoid issues
            if not os.path.isabs(input_path):
                input_path = os.path.abspath(input_path)
                
            if not os.path.exists(input_path):
                raise Exception(f"输入文件不存在: {input_path}")

            # Determine output path
            dir_name = os.path.dirname(input_path)
            file_name = os.path.basename(input_path)
            name_part, ext = os.path.splitext(file_name)
            output_name = f"{name_part}_upscaled{ext}"
            output_path = os.path.join(dir_name, output_name)
            task['output_path'] = output_path

            # Get configuration
            executable = self.model_manager.get_executable_path()
            # Use task-specific model or global default
            model = task.get('model') or self.settings.get("upscale_model", "realesr-animevideov3")
            scale = self.settings.get("upscale_ratio", 2)
            threads = self.settings.get("upscale_threads", 2)
            
            # If no executable, use fallback
            if not executable or not os.path.exists(executable):
                if shutil.which("ffmpeg"):
                    # Use FFmpeg for simple scaling
                    self._run_ffmpeg_upscale(task, input_path, output_path, scale)
                else:
                    raise Exception("未配置超分工具且未找到FFmpeg")
            else:
                # Run Real-ESRGAN
                self._run_realesrgan(task, executable, input_path, output_path, model, scale)

            # Check if task was paused or failed during execution
            if task['status'] in ['paused', 'failed']:
                return

            task['status'] = 'completed'
            task['progress'] = 100
            task['message'] = '处理完成'

        except Exception as e:
            print(f"Upscale failed: {e}")
            task['status'] = 'failed'
            task['message'] = str(e)

    def _run_ffmpeg_upscale(self, task, input_path, output_path, scale):
        task['message'] = '正在使用FFmpeg处理 (非AI模式)...'
        
        # Get duration for progress
        duration = self._get_video_duration(input_path)
        
        cmd = [
            'ffmpeg', '-y', '-i', input_path,
            '-vf', f'scale=iw*{scale}:ih*{scale}:flags=lanczos',
            '-c:a', 'copy',
            output_path
        ]
        
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            encoding='utf-8' # Ensure encoding
        )
        self.current_process = process
        
        self._monitor_process(process, task, duration)

    def _run_realesrgan(self, task, executable, input_path, output_path, model, scale):
        # Check if input is video
        is_video = any(input_path.lower().endswith(ext) for ext in ['.mp4', '.mkv', '.avi', '.mov', '.flv', '.webm'])
        
        if is_video:
            self._run_realesrgan_video(task, executable, input_path, output_path, model, scale)
            return

        task['message'] = f'正在使用AI模型 {model} 处理 (GPU)...'
        
        # Verify executable first
        try:
            # Capture output to see why it failed (e.g. missing DLL)
            # check=False to manually handle return code
            result = subprocess.run([executable, '-h'], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='utf-8', errors='replace')
            
            # Allow non-zero exit code if help text is present (some builds return -1 on help)
            output = (result.stdout or "") + (result.stderr or "")
            if result.returncode != 0:
                if "Usage:" not in output and "realesrgan-ncnn-vulkan" not in output:
                     error_msg = f"Exit code {result.returncode}"
                     if result.stderr:
                         error_msg += f"\nStderr: {result.stderr.strip()}"
                     if result.stdout:
                         error_msg += f"\nStdout: {result.stdout.strip()}"
                     raise Exception(f"引擎无法执行: {error_msg}")
                     
        except Exception as e:
            raise Exception(f"引擎检查失败: {e}")

        # Command structure: ./realesrgan-ncnn-vulkan -i input.mp4 -o output.mp4 -n model -s scale
        # -g gpu_id (default auto)
        
        # Get threads setting
        threads = self.settings.get("upscale_threads", 2)
        # load:proc:save = 1:2:2 is default. We can adjust based on threads.
        # -j load:proc:save
        # Let's just set the main thread count if possible, but ncnn uses -j for load:proc:save
        # If user selects 2, maybe we use 1:2:2. If 4, maybe 2:4:2?
        # To simplify, we can just pass a single number for OpenMP threads if supported, 
        # BUT realesrgan-ncnn-vulkan uses -j for pipeline threads.
        # Format: -j 1:2:2
        # Let's map user choice (1-4) to this.
        # 1 -> 1:1:1
        # 2 -> 1:2:2 (Default)
        # 3 -> 2:3:2
        # 4 -> 2:4:2
        
        j_param = "1:2:2"
        try:
            t = int(threads)
            if t == 1: j_param = "1:1:1"
            elif t == 2: j_param = "1:2:2"
            elif t == 3: j_param = "2:3:2"
            elif t >= 4: j_param = "2:4:2"
        except: pass

        cmd = [
            executable,
            '-i', input_path,
            '-o', output_path,
            '-n', model,
            '-s', str(scale),
            '-j', j_param
        ]
        
        # GPU support is automatic in ncnn-vulkan usually, but we can enforce it if needed.
        # Assuming standard usage.
        
        print(f"Running command: {cmd}") # Debug log
        
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            encoding='utf-8',
            errors='replace'
        )
        self.current_process = process
        
        self._monitor_process(process, task, None, is_realesrgan=True)

    def _run_realesrgan_video(self, task, executable, input_path, output_path, model, scale):
        """
        Handle video upscale by:
        1. Extract frames to temp dir
        2. Upscale frames
        3. Merge frames and copy audio
        """
        import shutil
        import uuid
        
        # Check disk space (Need roughly 5GB per minute of video for PNG, or less for JPG)
        # Just check for a safe minimum like 10GB for short clips
        try:
            total, used, free = shutil.disk_usage(os.getcwd())
            if free < 2 * 1024 * 1024 * 1024: # 2GB
                raise Exception(f"磁盘空间极低 ({free/1024/1024:.0f}MB)，无法进行超分处理。请清理至少 10GB 空间。")
        except Exception as e:
            if "磁盘空间" in str(e): raise e
            print(f"Warning: Could not check disk space: {e}")

        # Create or reuse temp dirs
        if 'session_id' not in task:
            task['session_id'] = str(uuid.uuid4())[:8]
            self.save_tasks()
            
        session_id = task['session_id']
        temp_dir_in = os.path.join(os.getcwd(), f"temp_frames_in_{session_id}")
        temp_dir_out = os.path.join(os.getcwd(), f"temp_frames_out_{session_id}")
        
        # If folders don't exist, create them. If they exist, it's a resume.
        is_resume = os.path.exists(temp_dir_in) and os.path.exists(temp_dir_out)
        
        if not is_resume:
            if os.path.exists(temp_dir_in): shutil.rmtree(temp_dir_in)
            if os.path.exists(temp_dir_out): shutil.rmtree(temp_dir_out)
            os.makedirs(temp_dir_in)
            os.makedirs(temp_dir_out)
        
        try:
            # 1. Extract Frames (Skip if resume)
            if not is_resume:
                task['message'] = '正在提取视频帧...'
                task['progress'] = 0
                
                # Use jpeg instead of png for speed? PNG is better quality.
                # q:v 2 is high quality for jpg. But let's use png for lossless intermediate.
                extract_cmd = [
                    'ffmpeg', '-i', input_path, 
                    os.path.join(temp_dir_in, 'frame_%08d.png')
                ]
                
                print(f"Executing FFmpeg extract: {extract_cmd}")
                
                # Run extract with error capturing
                result = subprocess.run(
                    extract_cmd, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE,
                    encoding='utf-8',
                    errors='replace'
                )
                
                if result.returncode != 0:
                    # Get last few lines of error to avoid spamming with banner
                    lines = result.stderr.strip().split('\n')
                    error_msg = "\n".join(lines[-10:]) if len(lines) > 10 else result.stderr
                    
                    if "No space left on device" in error_msg or "No space left on device" in result.stderr:
                        raise Exception("磁盘空间不足，无法提取视频帧。请清理磁盘空间 (需要 10GB+)。")
                        
                    raise Exception(f"视频帧提取失败 (FFmpeg): {error_msg}")
            
            # Count frames
            frames = os.listdir(temp_dir_in)
            total_frames = len(frames)
            
            if total_frames == 0:
                raise Exception("无法提取视频帧")
                
            # If resume, cleanup input frames that are already done
            if is_resume:
                task['message'] = '正在检查断点...'
                done_frames = os.listdir(temp_dir_out)
                # Ensure we don't have partial files.
                # Real-ESRGAN writes to temp file then renames? No.
                # But if we killed it, the last file might be corrupt.
                # Let's delete the last file in output just in case?
                # Or just match names.
                # Input: frame_00000001.png -> Output: frame_00000001.png (if using -o dir)
                
                count_removed = 0
                for f in done_frames:
                    in_f = os.path.join(temp_dir_in, f)
                    if os.path.exists(in_f):
                        os.remove(in_f)
                        count_removed += 1
                
                # Update total frames logic?
                # total_frames is still the original total count from 'frames' list above?
                # Wait, 'frames' = os.listdir(temp_dir_in).
                # If we are resuming, 'temp_dir_in' might already have some files removed if we implemented "delete input after done" previously.
                # But currently we don't delete input after done.
                # So 'temp_dir_in' has ALL frames initially.
                # Now we remove the ones that are in 'temp_dir_out'.
                # So 'frames' list needs to be refreshed.
                frames = os.listdir(temp_dir_in)
                remaining_frames = len(frames)
                
                # total_frames for progress calculation should be "total original frames".
                # We can estimate it: remaining + done.
                total_frames = remaining_frames + len(done_frames)
            
            # 2. Upscale Frames
            # If nothing left to upscale, skip
            if len(frames) > 0:
                task['message'] = f'正在AI超分 (0/{total_frames} 帧)...'
                
                # Use settings for threads
                threads = self.settings.get("upscale_threads", 2)
                j_param = "1:2:2"
                try:
                    t = int(threads)
                    if t == 1: j_param = "1:1:1"
                    elif t == 2: j_param = "1:2:2"
                    elif t == 3: j_param = "2:3:2"
                    elif t >= 4: j_param = "2:4:2"
                except: pass
                
                upscale_cmd = [
                    executable,
                    '-i', temp_dir_in,
                    '-o', temp_dir_out,
                    '-n', model,
                    '-s', str(scale),
                    '-j', j_param,
                    '-f', 'png' # Force png output
                ]
                
                print(f"Running video upscale: {upscale_cmd}")
                
                process = subprocess.Popen(
                    upscale_cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    universal_newlines=True,
                    encoding='utf-8',
                    errors='replace'
                )
                self.current_process = process
                
                # Monitor progress using file counting
                start_time = time.time()
                last_lines = []
                
                while True:
                    if self.stop_event.is_set():
                        self._kill_process_tree(process.pid)
                        # If paused, don't raise exception, just return
                        if task['status'] == 'paused':
                            return
                        
                        task['status'] = 'failed'
                        task['message'] = '用户取消'
                        
                        # Cleanup temp files on cancel
                        try:
                            if os.path.exists(temp_dir_in): shutil.rmtree(temp_dir_in)
                            if os.path.exists(temp_dir_out): shutil.rmtree(temp_dir_out)
                        except: pass
                        
                        return
    
                    # Check process status
                    if process.poll() is not None:
                        # Drain output
                        for line in process.stdout:
                            last_lines.append(line.strip())
                            if len(last_lines) > 5: last_lines.pop(0)
                        break
                        
                    # Check output files count
                    try:
                        processed_frames = len(os.listdir(temp_dir_out))
                        progress = (processed_frames / total_frames) * 100
                        task['progress'] = min(95, progress) # Reserve 5% for merging
                        task['message'] = f'正在AI超分 ({processed_frames}/{total_frames} 帧)...'
                    except: pass
                    
                    line = process.stdout.readline()
                    if line:
                        last_lines.append(line.strip())
                        if len(last_lines) > 5: last_lines.pop(0)
                    
                if process.returncode != 0 and not self.stop_event.is_set():
                     # Check if it's the "Usage:" issue again (help text on error)
                     error_details = "\n".join(last_lines)
                     if "Usage:" not in error_details and "realesrgan-ncnn-vulkan" not in error_details:
                         raise Exception(f"Process exited with code {process.returncode}. Last output:\n{error_details}")
            
            # 3. Merge Frames
            task['message'] = '正在合并视频...'
            task['progress'] = 98
            
            # Get framerate
            fps = self._get_video_fps(input_path)
            if not fps: fps = 23.976 # Default fallback
            
            merge_cmd = [
                'ffmpeg', '-y', 
                '-framerate', str(fps),
                '-i', os.path.join(temp_dir_out, 'frame_%08d.png'),
                '-i', input_path, # For audio
                '-map', '0:v:0',
                '-map', '1:a:0?', # Map audio if exists
                '-c:a', 'copy',
                '-c:v', 'libx264',
                '-pix_fmt', 'yuv420p',
                '-crf', '18', # High quality
                output_path
            ]
            
            # Run merge with error capturing
            result = subprocess.run(
                merge_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                encoding='utf-8',
                errors='replace'
            )
            
            if result.returncode != 0:
                lines = result.stderr.strip().split('\n')
                error_msg = "\n".join(lines[-10:]) if len(lines) > 10 else result.stderr
                raise Exception(f"视频合并失败 (FFmpeg): {error_msg}")
            
            # Cleanup only on success
            try:
                if os.path.exists(temp_dir_in): shutil.rmtree(temp_dir_in)
                if os.path.exists(temp_dir_out): shutil.rmtree(temp_dir_out)
            except: pass
            
        except Exception as e:
            # If paused, we might have raised exception if stop_event set?
            # No, we handled paused above.
            
            # Clean up temp files if task failed (and not paused)
            if task.get('status') != 'paused':
                try:
                    if os.path.exists(temp_dir_in): shutil.rmtree(temp_dir_in)
                    if os.path.exists(temp_dir_out): shutil.rmtree(temp_dir_out)
                except: pass
            
            # If exception, re-raise to fail task
            raise e
            
    def _get_video_fps(self, path):
        try:
            cmd = ['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=r_frame_rate', '-of', 'default=noprint_wrappers=1:nokey=1', path]
            output = subprocess.check_output(cmd).decode().strip()
            # output is like "24000/1001"
            if '/' in output:
                num, den = output.split('/')
                return float(num) / float(den)
            return float(output)
        except:
            return 0


    def _kill_process_tree(self, pid):
        import signal
        try:
            if platform.system() == 'Windows':
                # Windows: taskkill /F /T /PID <pid> kills tree
                subprocess.run(f'taskkill /F /T /PID {pid}', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                # Unix: kill process group if possible, or just the pid
                # We can try killing pgid
                try:
                    os.killpg(os.getpgid(pid), signal.SIGKILL)
                except:
                    # Fallback to simple kill
                    os.kill(pid, signal.SIGKILL)
        except:
            pass

    def _monitor_process(self, process, task, total_duration, is_realesrgan=False):
        start_time = time.time()
        last_lines = []
        
        while True:
            if self.stop_event.is_set():
                self._kill_process_tree(process.pid)
                # If it's a pause, status is already set to paused in pause_task
                if task['status'] == 'paused':
                    return
                
                task['status'] = 'failed'
                task['message'] = '用户取消'
                return

            # Non-blocking read using peek/poll workaround not available in standard subprocess
            # We use a timeout approach or just rely on poll if no output
            # But process.stdout.readline() blocks.
            # To fix blocking, we can use a separate thread or just check poll() before reading?
            # No, because pipe buffer might be full.
            
            # Better approach for Windows: use a thread to read output and put into queue
            # But here we want simple fix. 
            # Real-ESRGAN outputs frequently enough? 
            # If not, we might hang.
            # Let's assume for now the issue was process.terminate() not killing tree.
            
            output = process.stdout.readline()
            
            if output == '' and process.poll() is not None:
                break
            
            if output:
                output = output.strip()
                # print(f"Upscale output: {output}")
                
                # Keep last 5 lines for error reporting
                last_lines.append(output)
                if len(last_lines) > 5:
                    last_lines.pop(0)
                
                if is_realesrgan:
                    # Try to parse percentage "12.34%"
                    import re
                    match = re.search(r'(\d+\.?\d*)%', output)
                    if match:
                        try:
                            val = float(match.group(1))
                            task['progress'] = val
                        except: pass
                elif total_duration:
                    # Parse FFmpeg time "time=00:00:05.20"
                    import re
                    match = re.search(r'time=(\d{2}):(\d{2}):(\d{2}\.\d+)', output)
                    if match:
                        try:
                            h, m, s = map(float, match.groups())
                            current_sec = h*3600 + m*60 + s
                            if total_duration > 0:
                                percent = (current_sec / total_duration) * 100
                                task['progress'] = min(99, percent)
                        except: pass
                        
        if process.returncode != 0 and not self.stop_event.is_set():
            error_details = "\n".join(last_lines)
            raise Exception(f"Process exited with code {process.returncode}. Last output:\n{error_details}")

    def _get_video_duration(self, path):
        try:
            cmd = ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', path]
            output = subprocess.check_output(cmd).decode().strip()
            return float(output)
        except:
            return 0
